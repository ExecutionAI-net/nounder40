(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/school/reports/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SchoolReportsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
// ── CSV helpers ───────────────────────────────────────────────────────────────
function downloadCSV(rows, filename) {
    if (!rows.length) return;
    const headers = Object.keys(rows[0]);
    const lines = rows.map((r)=>headers.map((h)=>{
            const val = r[h];
            const str = val === null || val === undefined ? '' : String(val);
            return str.includes(',') ? '"'.concat(str, '"') : str;
        }).join(','));
    const blob = new Blob([
        [
            headers.join(','),
            ...lines
        ].join('\n')
    ], {
        type: 'text/csv'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}
function SortTh(param) {
    let { label, col, sortCol, sortDir, onSort, right } = param;
    const active = sortCol === col;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
        onClick: ()=>onSort(col),
        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide cursor-pointer select-none whitespace-nowrap ".concat(right ? 'text-right' : 'text-left', " ").concat(active ? 'text-gray-700' : 'text-gray-400', " hover:text-gray-600"),
        children: [
            label,
            " ",
            active ? sortDir === 'asc' ? '↑' : '↓' : '↕'
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
        lineNumber: 116,
        columnNumber: 5
    }, this);
}
_c = SortTh;
function Tooltip(param) {
    let { text, children } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative group/tip inline-block",
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pointer-events-none absolute bottom-full right-0 mb-1.5 hidden group-hover/tip:block z-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-gray-800 text-white text-xs rounded-md px-2.5 py-1.5 whitespace-nowrap shadow-lg",
                    children: [
                        text,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute top-full right-3 border-4 border-transparent border-t-gray-800"
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                            lineNumber: 132,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                    lineNumber: 130,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                lineNumber: 129,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
        lineNumber: 127,
        columnNumber: 5
    }, this);
}
_c1 = Tooltip;
function SchoolReportsPage() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('school.reports');
    const TABS = [
        {
            id: 'lessons',
            label: t('tabLessons')
        },
        {
            id: 'students',
            label: t('tabStudents')
        },
        {
            id: 'student-classes',
            label: t('tabStudentClasses')
        },
        {
            id: 'teachers',
            label: t('tabTeachers')
        }
    ];
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('lessons');
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Student Classes data (lazy loaded)
    const [scData, setScData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [scLoading, setScLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [scError, setScError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Lesson filters
    const [filterFrom, setFilterFrom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterTo, setFilterTo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterTeacher, setFilterTeacher] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterLocation, setFilterLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterRoom, setFilterRoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterCompPlan, setFilterCompPlan] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Student filters
    const [sFilterFrom, setSFilterFrom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [sFilterTo, setSFilterTo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [sFilterTeacher, setSFilterTeacher] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [sFilterLocation, setSFilterLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [sFilterRoom, setSFilterRoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Student Classes filters
    const [scFilterStudent, setScFilterStudent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scFilterFrom, setScFilterFrom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scFilterTo, setScFilterTo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scFilterTeacher, setScFilterTeacher] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scFilterLocation, setScFilterLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scFilterRoom, setScFilterRoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scExpandedStudent, setScExpandedStudent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Lesson sort
    const [lessonSortCol, setLessonSortCol] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('date');
    const [lessonSortDir, setLessonSortDir] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('desc');
    // Student sort
    const [studentSortCol, setStudentSortCol] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('name');
    const [studentSortDir, setStudentSortDir] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('asc');
    // Teacher sort
    const [teacherSortCol, setTeacherSortCol] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('name');
    const [teacherSortDir, setTeacherSortDir] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('asc');
    const load = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SchoolReportsPage.useCallback[load]": async ()=>{
            try {
                const res = await fetch('/api/school/reports');
                if (!res.ok) {
                    setError(t('error'));
                    return;
                }
                setData(await res.json());
            } catch (e) {
                setError(t('error'));
            } finally{
                setLoading(false);
            }
        }
    }["SchoolReportsPage.useCallback[load]"], [
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SchoolReportsPage.useEffect": ()=>{
            load();
        }
    }["SchoolReportsPage.useEffect"], [
        load
    ]);
    // Lazy load student-classes tab
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SchoolReportsPage.useEffect": ()=>{
            if (activeTab !== 'student-classes' || scData || scLoading) return;
            setScLoading(true);
            fetch('/api/school/reports/student-classes').then({
                "SchoolReportsPage.useEffect": (r)=>r.json()
            }["SchoolReportsPage.useEffect"]).then({
                "SchoolReportsPage.useEffect": (d)=>setScData(d)
            }["SchoolReportsPage.useEffect"]).catch({
                "SchoolReportsPage.useEffect": ()=>setScError(t('error'))
            }["SchoolReportsPage.useEffect"]).finally({
                "SchoolReportsPage.useEffect": ()=>setScLoading(false)
            }["SchoolReportsPage.useEffect"]);
        }
    }["SchoolReportsPage.useEffect"], [
        activeTab,
        scData,
        scLoading,
        t
    ]);
    // ── Derived filter options from lessons ──────────────────────────────────────
    const teachers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[teachers]": ()=>{
            if (!data) return [];
            const seen = new Set();
            return data.lessons.rows.filter({
                "SchoolReportsPage.useMemo[teachers]": (r)=>r.teacher !== '—' && r.teacher_id && !seen.has(r.teacher_id) && seen.add(r.teacher_id)
            }["SchoolReportsPage.useMemo[teachers]"]).map({
                "SchoolReportsPage.useMemo[teachers]": (r)=>({
                        id: r.teacher_id,
                        name: r.teacher
                    })
            }["SchoolReportsPage.useMemo[teachers]"]);
        }
    }["SchoolReportsPage.useMemo[teachers]"], [
        data
    ]);
    const locations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[locations]": ()=>{
            if (!data) return [];
            const seen = new Set();
            return data.lessons.rows.filter({
                "SchoolReportsPage.useMemo[locations]": (r)=>r.location !== '—' && r.location_id && !seen.has(r.location_id) && seen.add(r.location_id)
            }["SchoolReportsPage.useMemo[locations]"]).map({
                "SchoolReportsPage.useMemo[locations]": (r)=>({
                        id: r.location_id,
                        name: r.location
                    })
            }["SchoolReportsPage.useMemo[locations]"]);
        }
    }["SchoolReportsPage.useMemo[locations]"], [
        data
    ]);
    const rooms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[rooms]": ()=>{
            if (!data) return [];
            const seen = new Set();
            return data.lessons.rows.filter({
                "SchoolReportsPage.useMemo[rooms]": (r)=>r.room !== '—' && r.room_id && (!filterLocation || r.location_id === filterLocation) && !seen.has(r.room_id) && seen.add(r.room_id)
            }["SchoolReportsPage.useMemo[rooms]"]).map({
                "SchoolReportsPage.useMemo[rooms]": (r)=>({
                        id: r.room_id,
                        name: r.room
                    })
            }["SchoolReportsPage.useMemo[rooms]"]);
        }
    }["SchoolReportsPage.useMemo[rooms]"], [
        data,
        filterLocation
    ]);
    const compensationPlans = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[compensationPlans]": ()=>{
            if (!data) return [];
            const seen = new Set();
            return data.lessons.rows.filter({
                "SchoolReportsPage.useMemo[compensationPlans]": (r)=>r.compensation_plan !== '—' && r.compensation_plan_id && !seen.has(r.compensation_plan_id) && seen.add(r.compensation_plan_id)
            }["SchoolReportsPage.useMemo[compensationPlans]"]).map({
                "SchoolReportsPage.useMemo[compensationPlans]": (r)=>({
                        id: r.compensation_plan_id,
                        name: r.compensation_plan
                    })
            }["SchoolReportsPage.useMemo[compensationPlans]"]);
        }
    }["SchoolReportsPage.useMemo[compensationPlans]"], [
        data
    ]);
    // ── Derived filter options for students tab (from attendance data) ──────────
    const sTeachers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[sTeachers]": ()=>{
            if (!scData) return teachers // fallback to lesson teachers
            ;
            const seen = new Set();
            const result = [];
            for (const s of scData.rows){
                for (const a of s.attendance){
                    if (a.teacher_id && !seen.has(a.teacher_id)) {
                        seen.add(a.teacher_id);
                        result.push({
                            id: a.teacher_id,
                            name: a.teacher_name
                        });
                    }
                }
            }
            return result;
        }
    }["SchoolReportsPage.useMemo[sTeachers]"], [
        scData,
        teachers
    ]);
    const sLocations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[sLocations]": ()=>{
            if (!scData) return locations;
            const seen = new Set();
            const result = [];
            for (const s of scData.rows){
                for (const a of s.attendance){
                    if (a.location_id && !seen.has(a.location_id)) {
                        seen.add(a.location_id);
                        result.push({
                            id: a.location_id,
                            name: a.location_name
                        });
                    }
                }
            }
            return result;
        }
    }["SchoolReportsPage.useMemo[sLocations]"], [
        scData,
        locations
    ]);
    const sRooms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[sRooms]": ()=>{
            if (!scData) return rooms;
            const seen = new Set();
            const result = [];
            for (const s of scData.rows){
                for (const a of s.attendance){
                    if (a.room_id && (!sFilterLocation || a.location_id === sFilterLocation) && !seen.has(a.room_id)) {
                        seen.add(a.room_id);
                        result.push({
                            id: a.room_id,
                            name: a.room_name
                        });
                    }
                }
            }
            return result;
        }
    }["SchoolReportsPage.useMemo[sRooms]"], [
        scData,
        rooms,
        sFilterLocation
    ]);
    // ── Filtered + sorted lessons ───────────────────────────────────────────────
    const filteredLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[filteredLessons]": ()=>{
            if (!data) return [];
            let rows = data.lessons.rows;
            if (filterFrom) rows = rows.filter({
                "SchoolReportsPage.useMemo[filteredLessons]": (r)=>r.date >= filterFrom
            }["SchoolReportsPage.useMemo[filteredLessons]"]);
            if (filterTo) rows = rows.filter({
                "SchoolReportsPage.useMemo[filteredLessons]": (r)=>r.date <= filterTo
            }["SchoolReportsPage.useMemo[filteredLessons]"]);
            if (filterTeacher) rows = rows.filter({
                "SchoolReportsPage.useMemo[filteredLessons]": (r)=>r.teacher_id === filterTeacher
            }["SchoolReportsPage.useMemo[filteredLessons]"]);
            if (filterLocation) rows = rows.filter({
                "SchoolReportsPage.useMemo[filteredLessons]": (r)=>r.location_id === filterLocation
            }["SchoolReportsPage.useMemo[filteredLessons]"]);
            if (filterRoom) rows = rows.filter({
                "SchoolReportsPage.useMemo[filteredLessons]": (r)=>r.room_id === filterRoom
            }["SchoolReportsPage.useMemo[filteredLessons]"]);
            if (filterCompPlan) rows = rows.filter({
                "SchoolReportsPage.useMemo[filteredLessons]": (r)=>r.compensation_plan_id === filterCompPlan
            }["SchoolReportsPage.useMemo[filteredLessons]"]);
            return [
                ...rows
            ].sort({
                "SchoolReportsPage.useMemo[filteredLessons]": (a, b)=>{
                    const av = a[lessonSortCol];
                    const bv = b[lessonSortCol];
                    if (av === null || av === undefined) return 1;
                    if (bv === null || bv === undefined) return -1;
                    const cmp = String(av).localeCompare(String(bv), undefined, {
                        numeric: true
                    });
                    return lessonSortDir === 'asc' ? cmp : -cmp;
                }
            }["SchoolReportsPage.useMemo[filteredLessons]"]);
        }
    }["SchoolReportsPage.useMemo[filteredLessons]"], [
        data,
        filterFrom,
        filterTo,
        filterTeacher,
        filterLocation,
        filterRoom,
        filterCompPlan,
        lessonSortCol,
        lessonSortDir
    ]);
    function handleLessonSort(col) {
        if (lessonSortCol === col) setLessonSortDir((d)=>d === 'asc' ? 'desc' : 'asc');
        else {
            setLessonSortCol(col);
            setLessonSortDir('asc');
        }
    }
    const lessonKpis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[lessonKpis]": ()=>{
            const rows = filteredLessons;
            const totalAttendance = rows.reduce({
                "SchoolReportsPage.useMemo[lessonKpis].totalAttendance": (s, r)=>s + r.attended
            }["SchoolReportsPage.useMemo[lessonKpis].totalAttendance"], 0);
            const totalNoShows = rows.reduce({
                "SchoolReportsPage.useMemo[lessonKpis].totalNoShows": (s, r)=>s + r.no_shows
            }["SchoolReportsPage.useMemo[lessonKpis].totalNoShows"], 0);
            const totalCancelled = rows.reduce({
                "SchoolReportsPage.useMemo[lessonKpis].totalCancelled": (s, r)=>s + r.cancelled
            }["SchoolReportsPage.useMemo[lessonKpis].totalCancelled"], 0);
            const totalBooked = rows.reduce({
                "SchoolReportsPage.useMemo[lessonKpis].totalBooked": (s, r)=>s + r.booked
            }["SchoolReportsPage.useMemo[lessonKpis].totalBooked"], 0);
            const noShowRate = totalBooked > 0 ? (totalNoShows / totalBooked * 100).toFixed(1) : '0.0';
            const cancellationRate = totalBooked > 0 ? (totalCancelled / (totalBooked + totalCancelled) * 100).toFixed(1) : '0.0';
            return {
                total: rows.length,
                totalAttendance,
                noShowRate,
                cancellationRate
            };
        }
    }["SchoolReportsPage.useMemo[lessonKpis]"], [
        filteredLessons
    ]);
    // ── Students tab: attendance-aware filtered students ────────────────────────
    // For student filters we need attendance data — use scData if loaded, else use basic sort only
    const filteredStudents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[filteredStudents]": ()=>{
            if (!data) return [];
            let rows = data.students.rows;
            // If scData loaded and student attendance filters active, filter based on attendance
            if (scData && (sFilterFrom || sFilterTo || sFilterTeacher || sFilterLocation || sFilterRoom)) {
                const matchingStudentIds = new Set();
                for (const sc of scData.rows){
                    const hasMatch = sc.attendance.some({
                        "SchoolReportsPage.useMemo[filteredStudents].hasMatch": (a)=>{
                            if (sFilterFrom && a.date < sFilterFrom) return false;
                            if (sFilterTo && a.date > sFilterTo) return false;
                            if (sFilterTeacher && a.teacher_id !== sFilterTeacher) return false;
                            if (sFilterLocation && a.location_id !== sFilterLocation) return false;
                            if (sFilterRoom && a.room_id !== sFilterRoom) return false;
                            return true;
                        }
                    }["SchoolReportsPage.useMemo[filteredStudents].hasMatch"]);
                    if (hasMatch) matchingStudentIds.add(sc.student_id);
                }
                rows = rows.filter({
                    "SchoolReportsPage.useMemo[filteredStudents]": (r)=>matchingStudentIds.has(r.id)
                }["SchoolReportsPage.useMemo[filteredStudents]"]);
            }
            return [
                ...rows
            ].sort({
                "SchoolReportsPage.useMemo[filteredStudents]": (a, b)=>{
                    const av = a[studentSortCol];
                    const bv = b[studentSortCol];
                    const cmp = String(av !== null && av !== void 0 ? av : '').localeCompare(String(bv !== null && bv !== void 0 ? bv : ''), undefined, {
                        numeric: true
                    });
                    return studentSortDir === 'asc' ? cmp : -cmp;
                }
            }["SchoolReportsPage.useMemo[filteredStudents]"]);
        }
    }["SchoolReportsPage.useMemo[filteredStudents]"], [
        data,
        scData,
        sFilterFrom,
        sFilterTo,
        sFilterTeacher,
        sFilterLocation,
        sFilterRoom,
        studentSortCol,
        studentSortDir
    ]);
    function handleStudentSort(col) {
        if (studentSortCol === col) setStudentSortDir((d)=>d === 'asc' ? 'desc' : 'asc');
        else {
            setStudentSortCol(col);
            setStudentSortDir('asc');
        }
    }
    const studentKpis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[studentKpis]": ()=>{
            if (!data) return {
                total: 0,
                avg_credits: '0',
                docs_expired: 0,
                total_burned: 0
            };
            const rows = filteredStudents;
            const total_burned = rows.reduce({
                "SchoolReportsPage.useMemo[studentKpis].total_burned": (s, r)=>s + r.credits_burned
            }["SchoolReportsPage.useMemo[studentKpis].total_burned"], 0);
            return {
                total: data.students.total,
                avg_credits: data.students.avg_credits,
                docs_expired: data.students.docs_expired,
                total_burned
            };
        }
    }["SchoolReportsPage.useMemo[studentKpis]"], [
        data,
        filteredStudents
    ]);
    // ── Student Classes tab ─────────────────────────────────────────────────────
    const scTeachers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[scTeachers]": ()=>{
            if (!scData) return [];
            const seen = new Set();
            const result = [];
            for (const s of scData.rows){
                for (const a of s.attendance){
                    if (a.teacher_id && !seen.has(a.teacher_id)) {
                        seen.add(a.teacher_id);
                        result.push({
                            id: a.teacher_id,
                            name: a.teacher_name
                        });
                    }
                }
            }
            return result;
        }
    }["SchoolReportsPage.useMemo[scTeachers]"], [
        scData
    ]);
    const scLocations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[scLocations]": ()=>{
            if (!scData) return [];
            const seen = new Set();
            const result = [];
            for (const s of scData.rows){
                for (const a of s.attendance){
                    if (a.location_id && !seen.has(a.location_id)) {
                        seen.add(a.location_id);
                        result.push({
                            id: a.location_id,
                            name: a.location_name
                        });
                    }
                }
            }
            return result;
        }
    }["SchoolReportsPage.useMemo[scLocations]"], [
        scData
    ]);
    const scRooms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[scRooms]": ()=>{
            if (!scData) return [];
            const seen = new Set();
            const result = [];
            for (const s of scData.rows){
                for (const a of s.attendance){
                    if (a.room_id && (!scFilterLocation || a.location_id === scFilterLocation) && !seen.has(a.room_id)) {
                        seen.add(a.room_id);
                        result.push({
                            id: a.room_id,
                            name: a.room_name
                        });
                    }
                }
            }
            return result;
        }
    }["SchoolReportsPage.useMemo[scRooms]"], [
        scData,
        scFilterLocation
    ]);
    const scStudentNames = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[scStudentNames]": ()=>{
            if (!scData) return [];
            return scData.rows.map({
                "SchoolReportsPage.useMemo[scStudentNames]": (r)=>({
                        id: r.student_id,
                        name: r.student_name
                    })
            }["SchoolReportsPage.useMemo[scStudentNames]"]);
        }
    }["SchoolReportsPage.useMemo[scStudentNames]"], [
        scData
    ]);
    const filteredScRows = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[filteredScRows]": ()=>{
            if (!scData) return [];
            let rows = scData.rows;
            if (scFilterStudent) rows = rows.filter({
                "SchoolReportsPage.useMemo[filteredScRows]": (r)=>r.student_id === scFilterStudent
            }["SchoolReportsPage.useMemo[filteredScRows]"]);
            rows = rows.map({
                "SchoolReportsPage.useMemo[filteredScRows]": (r)=>({
                        ...r,
                        attendance: r.attendance.filter({
                            "SchoolReportsPage.useMemo[filteredScRows]": (a)=>{
                                if (scFilterFrom && a.date < scFilterFrom) return false;
                                if (scFilterTo && a.date > scFilterTo) return false;
                                if (scFilterTeacher && a.teacher_id !== scFilterTeacher) return false;
                                if (scFilterLocation && a.location_id !== scFilterLocation) return false;
                                if (scFilterRoom && a.room_id !== scFilterRoom) return false;
                                return true;
                            }
                        }["SchoolReportsPage.useMemo[filteredScRows]"])
                    })
            }["SchoolReportsPage.useMemo[filteredScRows]"]).filter({
                "SchoolReportsPage.useMemo[filteredScRows]": (r)=>r.attendance.length > 0 || !scFilterStudent
            }["SchoolReportsPage.useMemo[filteredScRows]"]);
            return rows;
        }
    }["SchoolReportsPage.useMemo[filteredScRows]"], [
        scData,
        scFilterStudent,
        scFilterFrom,
        scFilterTo,
        scFilterTeacher,
        scFilterLocation,
        scFilterRoom
    ]);
    // ── Teachers ────────────────────────────────────────────────────────────────
    const filteredTeachers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SchoolReportsPage.useMemo[filteredTeachers]": ()=>{
            if (!data) return [];
            return [
                ...data.teachers.rows
            ].sort({
                "SchoolReportsPage.useMemo[filteredTeachers]": (a, b)=>{
                    const av = a[teacherSortCol];
                    const bv = b[teacherSortCol];
                    const cmp = String(av !== null && av !== void 0 ? av : '').localeCompare(String(bv !== null && bv !== void 0 ? bv : ''), undefined, {
                        numeric: true
                    });
                    return teacherSortDir === 'asc' ? cmp : -cmp;
                }
            }["SchoolReportsPage.useMemo[filteredTeachers]"]);
        }
    }["SchoolReportsPage.useMemo[filteredTeachers]"], [
        data,
        teacherSortCol,
        teacherSortDir
    ]);
    function handleTeacherSort(col) {
        if (teacherSortCol === col) setTeacherSortDir((d)=>d === 'asc' ? 'desc' : 'asc');
        else {
            setTeacherSortCol(col);
            setTeacherSortDir('asc');
        }
    }
    const inputCls = 'px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20';
    // Load scData when switching to students tab (needed for filters)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SchoolReportsPage.useEffect": ()=>{
            if (activeTab !== 'students' || scData || scLoading) return;
            setScLoading(true);
            fetch('/api/school/reports/student-classes').then({
                "SchoolReportsPage.useEffect": (r)=>r.json()
            }["SchoolReportsPage.useEffect"]).then({
                "SchoolReportsPage.useEffect": (d)=>setScData(d)
            }["SchoolReportsPage.useEffect"]).catch({
                "SchoolReportsPage.useEffect": ()=>{}
            }["SchoolReportsPage.useEffect"]).finally({
                "SchoolReportsPage.useEffect": ()=>setScLoading(false)
            }["SchoolReportsPage.useEffect"]);
        }
    }["SchoolReportsPage.useEffect"], [
        activeTab,
        scData,
        scLoading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-bold text-gray-900",
                    children: t('title')
                }, void 0, false, {
                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                    lineNumber: 491,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                lineNumber: 490,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-1 mb-6 bg-gray-100 rounded-xl p-1 w-fit",
                children: TABS.map((tab)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setActiveTab(tab.id),
                        className: "px-5 py-2 rounded-lg text-sm font-medium transition ".concat(activeTab === tab.id ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'),
                        children: tab.label
                    }, tab.id, false, {
                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                        lineNumber: 497,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                lineNumber: 495,
                columnNumber: 7
            }, this),
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 p-8 text-center text-gray-400 text-sm",
                children: t('loading')
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                lineNumber: 506,
                columnNumber: 19
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-red-50 border border-red-200 rounded-xl p-5 text-sm text-red-700",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                lineNumber: 507,
                columnNumber: 17
            }, this),
            !loading && !error && data && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    activeTab === 'lessons' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 lg:grid-cols-4 gap-4",
                                children: [
                                    {
                                        label: t('kpiTotalLessons'),
                                        value: lessonKpis.total
                                    },
                                    {
                                        label: t('kpiTotalAttendance'),
                                        value: lessonKpis.totalAttendance
                                    },
                                    {
                                        label: t('kpiNoShowRate'),
                                        value: "".concat(lessonKpis.noShowRate, "%")
                                    },
                                    {
                                        label: t('kpiCancellationRate'),
                                        value: "".concat(lessonKpis.cancellationRate, "%")
                                    }
                                ].map((kpi)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-xl border border-gray-100 p-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-400 font-medium uppercase tracking-wide",
                                                children: kpi.label
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 522,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-2xl font-bold text-gray-900 mt-1",
                                                children: kpi.value
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 523,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, kpi.label, true, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 521,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 514,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 px-5 py-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap gap-3 items-end",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterFrom')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 531,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "date",
                                                    value: filterFrom,
                                                    onChange: (e)=>setFilterFrom(e.target.value),
                                                    className: inputCls
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 532,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 530,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterTo')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 535,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "date",
                                                    value: filterTo,
                                                    onChange: (e)=>setFilterTo(e.target.value),
                                                    className: inputCls
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 536,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 534,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterTeacher')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 539,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    value: filterTeacher,
                                                    onChange: (e)=>setFilterTeacher(e.target.value),
                                                    className: inputCls,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: t('allTeachers')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 541,
                                                            columnNumber: 23
                                                        }, this),
                                                        teachers.map((teacher)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: teacher.id,
                                                                children: teacher.name
                                                            }, teacher.id, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 542,
                                                                columnNumber: 48
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 540,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 538,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterLocation')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 546,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    value: filterLocation,
                                                    onChange: (e)=>{
                                                        setFilterLocation(e.target.value);
                                                        setFilterRoom('');
                                                    },
                                                    className: inputCls,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: t('allLocations')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 548,
                                                            columnNumber: 23
                                                        }, this),
                                                        locations.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: l.id,
                                                                children: l.name
                                                            }, l.id, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 549,
                                                                columnNumber: 43
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 547,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 545,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterRoom')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 553,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    value: filterRoom,
                                                    onChange: (e)=>setFilterRoom(e.target.value),
                                                    className: inputCls,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: t('allRooms')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 555,
                                                            columnNumber: 23
                                                        }, this),
                                                        rooms.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: r.id,
                                                                children: r.name
                                                            }, r.id, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 556,
                                                                columnNumber: 39
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 554,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 552,
                                            columnNumber: 19
                                        }, this),
                                        compensationPlans.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterCompPlan')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 561,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    value: filterCompPlan,
                                                    onChange: (e)=>setFilterCompPlan(e.target.value),
                                                    className: inputCls,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: t('allPlans')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 563,
                                                            columnNumber: 25
                                                        }, this),
                                                        compensationPlans.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: p.id,
                                                                children: p.name
                                                            }, p.id, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 564,
                                                                columnNumber: 53
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 562,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 560,
                                            columnNumber: 21
                                        }, this),
                                        (filterFrom || filterTo || filterTeacher || filterLocation || filterRoom || filterCompPlan) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>{
                                                setFilterFrom('');
                                                setFilterTo('');
                                                setFilterTeacher('');
                                                setFilterLocation('');
                                                setFilterRoom('');
                                                setFilterCompPlan('');
                                            },
                                            className: "px-3 py-1.5 text-xs text-gray-400 hover:text-gray-600 border border-gray-200 rounded-lg",
                                            children: t('clearFilters')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 569,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-400 ml-auto self-center",
                                            children: t('lessonCount', {
                                                count: filteredLessons.length
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 576,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                    lineNumber: 529,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 528,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-6 py-4 border-b border-gray-100 flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "font-semibold text-gray-900",
                                                children: t('lessonsDetailTitle')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 582,
                                                columnNumber: 19
                                            }, this),
                                            filteredLessons.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tooltip, {
                                                text: t('exportLessonsTooltip', {
                                                    count: filteredLessons.length
                                                }),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>downloadCSV(filteredLessons.map((r)=>({
                                                                Name: r.name,
                                                                Date: r.date,
                                                                Teacher: r.teacher,
                                                                Location: r.location,
                                                                Room: r.room,
                                                                'Room Cost (€)': r.room_cost !== null ? Number(r.room_cost).toFixed(2) : '—',
                                                                'Comp. Plan': r.compensation_plan,
                                                                Capacity: r.capacity,
                                                                Booked: r.booked,
                                                                Attended: r.attended,
                                                                'No Shows': r.no_shows,
                                                                Cancelled: r.cancelled,
                                                                Status: r.status
                                                            })), "school-lessons-".concat(new Date().toISOString().slice(0, 10), ".csv")),
                                                    className: "text-sm text-[#6B1F3A] border border-[#6B1F3A]/30 px-3 py-1.5 rounded-lg hover:bg-[#6B1F3A]/5 transition",
                                                    children: t('exportCSV')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 585,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 584,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 581,
                                        columnNumber: 17
                                    }, this),
                                    filteredLessons.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-8 text-center text-sm text-gray-400",
                                        children: t('noLessonsMatch')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 606,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "overflow-x-auto",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                            className: "w-full text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                        className: "border-b border-gray-100 bg-gray-50",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colLesson'),
                                                                col: "name",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 612,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colDate'),
                                                                col: "date",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 613,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colTeacher'),
                                                                col: "teacher",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 614,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colLocation'),
                                                                col: "location",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 615,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colRoom'),
                                                                col: "room",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 616,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colRoomCost'),
                                                                col: "room_cost",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 617,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colCompPlan'),
                                                                col: "compensation_plan",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 618,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colCapacity'),
                                                                col: "capacity",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 619,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colBooked'),
                                                                col: "booked",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 620,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colAttended'),
                                                                col: "attended",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 621,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colNoShows'),
                                                                col: "no_shows",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 622,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colStatus'),
                                                                col: "status",
                                                                sortCol: lessonSortCol,
                                                                sortDir: lessonSortDir,
                                                                onSort: handleLessonSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 623,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                        lineNumber: 611,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 610,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                    className: "divide-y divide-gray-50",
                                                    children: filteredLessons.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                            className: "hover:bg-gray-50 transition",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 font-medium text-gray-900",
                                                                    children: row.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 629,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-gray-500 whitespace-nowrap",
                                                                    children: new Date(row.date).toLocaleDateString('en-GB', {
                                                                        day: '2-digit',
                                                                        month: 'short',
                                                                        year: 'numeric'
                                                                    })
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 630,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-gray-600",
                                                                    children: row.teacher
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 633,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-gray-500 text-xs",
                                                                    children: row.location
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 634,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-gray-500 text-xs",
                                                                    children: row.room
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 635,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right text-gray-500 text-xs",
                                                                    children: row.room_cost !== null ? "€".concat(Number(row.room_cost).toFixed(2)) : '—'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 636,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-gray-500 text-xs",
                                                                    children: row.compensation_plan
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 639,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right text-gray-900",
                                                                    children: row.capacity
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 640,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right text-gray-900",
                                                                    children: row.booked
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 641,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right font-semibold text-green-700",
                                                                    children: row.attended
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 642,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right font-semibold text-red-500",
                                                                    children: row.no_shows
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 643,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs px-2 py-0.5 rounded-full ".concat(row.status === 'completed' ? 'bg-green-100 text-green-700' : row.status === 'cancelled' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-700'),
                                                                        children: row.status
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 645,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 644,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, row.id, true, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 628,
                                                            columnNumber: 27
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 626,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 609,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 608,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 580,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                        lineNumber: 513,
                        columnNumber: 13
                    }, this),
                    activeTab === 'students' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 lg:grid-cols-4 gap-4",
                                children: [
                                    {
                                        label: t('kpiTotalStudents'),
                                        value: studentKpis.total
                                    },
                                    {
                                        label: t('kpiAvgCredits'),
                                        value: studentKpis.avg_credits
                                    },
                                    {
                                        label: t('kpiCreditsBurned'),
                                        value: studentKpis.total_burned
                                    },
                                    {
                                        label: t('kpiDocsExpired'),
                                        value: studentKpis.docs_expired,
                                        warn: studentKpis.docs_expired > 0
                                    }
                                ].map((kpi)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-xl border border-gray-100 p-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-400 font-medium uppercase tracking-wide",
                                                children: kpi.label
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 673,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-2xl font-bold mt-1 ".concat(kpi.warn ? 'text-red-600' : 'text-gray-900'),
                                                children: kpi.value
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 674,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, kpi.label, true, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 672,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 665,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 px-5 py-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-wrap gap-3 items-end",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterFrom')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 683,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "date",
                                                    value: sFilterFrom,
                                                    onChange: (e)=>setSFilterFrom(e.target.value),
                                                    className: inputCls
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 684,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 682,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterTo')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 687,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "date",
                                                    value: sFilterTo,
                                                    onChange: (e)=>setSFilterTo(e.target.value),
                                                    className: inputCls
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 688,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 686,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterTeacher')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 691,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    value: sFilterTeacher,
                                                    onChange: (e)=>setSFilterTeacher(e.target.value),
                                                    className: inputCls,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: t('allTeachers')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 693,
                                                            columnNumber: 23
                                                        }, this),
                                                        sTeachers.map((teacher)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: teacher.id,
                                                                children: teacher.name
                                                            }, teacher.id, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 694,
                                                                columnNumber: 49
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 692,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 690,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterLocation')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 698,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    value: sFilterLocation,
                                                    onChange: (e)=>{
                                                        setSFilterLocation(e.target.value);
                                                        setSFilterRoom('');
                                                    },
                                                    className: inputCls,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: t('allLocations')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 700,
                                                            columnNumber: 23
                                                        }, this),
                                                        sLocations.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: l.id,
                                                                children: l.name
                                                            }, l.id, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 701,
                                                                columnNumber: 44
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 699,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 697,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-1",
                                                    children: t('filterRoom')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 705,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    value: sFilterRoom,
                                                    onChange: (e)=>setSFilterRoom(e.target.value),
                                                    className: inputCls,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: "",
                                                            children: t('allRooms')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 707,
                                                            columnNumber: 23
                                                        }, this),
                                                        sRooms.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: r.id,
                                                                children: r.name
                                                            }, r.id, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 708,
                                                                columnNumber: 40
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 706,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 704,
                                            columnNumber: 19
                                        }, this),
                                        (sFilterFrom || sFilterTo || sFilterTeacher || sFilterLocation || sFilterRoom) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>{
                                                setSFilterFrom('');
                                                setSFilterTo('');
                                                setSFilterTeacher('');
                                                setSFilterLocation('');
                                                setSFilterRoom('');
                                            },
                                            className: "px-3 py-1.5 text-xs text-gray-400 hover:text-gray-600 border border-gray-200 rounded-lg",
                                            children: t('clearFilters')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 712,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-400 ml-auto self-center",
                                            children: t('studentCount', {
                                                count: filteredStudents.length
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 719,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                    lineNumber: 681,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 680,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-6 py-4 border-b border-gray-100 flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "font-semibold text-gray-900",
                                                children: t('studentsDetailTitle')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 726,
                                                columnNumber: 19
                                            }, this),
                                            filteredStudents.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tooltip, {
                                                text: t('exportStudentsTooltip', {
                                                    count: filteredStudents.length
                                                }),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>downloadCSV(filteredStudents.map((r)=>({
                                                                Name: r.name,
                                                                'Credits Remaining': r.credits_remaining,
                                                                'Credits Burned': r.credits_burned,
                                                                'Last Attendance': r.last_attendance,
                                                                'Total Attended': r.total_attended,
                                                                'Active Package': r.has_active_package ? 'Yes' : 'No'
                                                            })), "school-students-".concat(new Date().toISOString().slice(0, 10), ".csv")),
                                                    className: "text-sm text-[#6B1F3A] border border-[#6B1F3A]/30 px-3 py-1.5 rounded-lg hover:bg-[#6B1F3A]/5 transition",
                                                    children: t('exportCSV')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 729,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 728,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 725,
                                        columnNumber: 17
                                    }, this),
                                    filteredStudents.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-8 text-center text-sm text-gray-400",
                                        children: t('noStudents')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 749,
                                        columnNumber: 19
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "overflow-x-auto",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                            className: "w-full text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                        className: "border-b border-gray-100 bg-gray-50",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colStudent'),
                                                                col: "name",
                                                                sortCol: studentSortCol,
                                                                sortDir: studentSortDir,
                                                                onSort: handleStudentSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 755,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colCredits'),
                                                                col: "credits_remaining",
                                                                sortCol: studentSortCol,
                                                                sortDir: studentSortDir,
                                                                onSort: handleStudentSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 756,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colCreditsBurned'),
                                                                col: "credits_burned",
                                                                sortCol: studentSortCol,
                                                                sortDir: studentSortDir,
                                                                onSort: handleStudentSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 757,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colLastAttendance'),
                                                                col: "last_attendance",
                                                                sortCol: studentSortCol,
                                                                sortDir: studentSortDir,
                                                                onSort: handleStudentSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 758,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colTotalLessons'),
                                                                col: "total_attended",
                                                                sortCol: studentSortCol,
                                                                sortDir: studentSortDir,
                                                                onSort: handleStudentSort,
                                                                right: true
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 759,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                                label: t('colPackage'),
                                                                col: "has_active_package",
                                                                sortCol: studentSortCol,
                                                                sortDir: studentSortDir,
                                                                onSort: handleStudentSort
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 760,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                        lineNumber: 754,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 753,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                    className: "divide-y divide-gray-50",
                                                    children: filteredStudents.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                            className: "hover:bg-gray-50 transition",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 font-medium text-gray-900",
                                                                    children: row.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 766,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right font-semibold text-[#6B1F3A]",
                                                                    children: row.credits_remaining
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 767,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right font-semibold text-orange-600",
                                                                    children: row.credits_burned
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 768,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-gray-500",
                                                                    children: row.last_attendance
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 769,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3 text-right text-gray-900 font-medium",
                                                                    children: row.total_attended
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 770,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                    className: "px-4 py-3",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs px-2 py-0.5 rounded-full ".concat(row.has_active_package ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'),
                                                                        children: row.has_active_package ? t('packageActive') : t('packageNone')
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 772,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 771,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, row.id, true, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 765,
                                                            columnNumber: 27
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 763,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 752,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 751,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 724,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                        lineNumber: 663,
                        columnNumber: 13
                    }, this),
                    activeTab === 'student-classes' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: [
                            scLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 p-8 text-center text-gray-400 text-sm",
                                children: t('loading')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 789,
                                columnNumber: 29
                            }, this),
                            scError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-red-50 border border-red-200 rounded-xl p-5 text-sm text-red-700",
                                children: scError
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                lineNumber: 790,
                                columnNumber: 27
                            }, this),
                            !scLoading && !scError && scData && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-xl border border-gray-100 px-5 py-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-wrap gap-3 items-end",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-500 mb-1",
                                                            children: t('filterStudent')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 797,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: scFilterStudent,
                                                            onChange: (e)=>setScFilterStudent(e.target.value),
                                                            className: inputCls,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: t('allStudents')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 799,
                                                                    columnNumber: 27
                                                                }, this),
                                                                scStudentNames.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                        value: s.id,
                                                                        children: s.name
                                                                    }, s.id, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 800,
                                                                        columnNumber: 52
                                                                    }, this))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 798,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 796,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-500 mb-1",
                                                            children: t('filterFrom')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 804,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "date",
                                                            value: scFilterFrom,
                                                            onChange: (e)=>setScFilterFrom(e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 805,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 803,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-500 mb-1",
                                                            children: t('filterTo')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 808,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "date",
                                                            value: scFilterTo,
                                                            onChange: (e)=>setScFilterTo(e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 809,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 807,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-500 mb-1",
                                                            children: t('filterTeacher')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 812,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: scFilterTeacher,
                                                            onChange: (e)=>setScFilterTeacher(e.target.value),
                                                            className: inputCls,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: t('allTeachers')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 814,
                                                                    columnNumber: 27
                                                                }, this),
                                                                scTeachers.map((t2)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                        value: t2.id,
                                                                        children: t2.name
                                                                    }, t2.id, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 815,
                                                                        columnNumber: 49
                                                                    }, this))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 813,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 811,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-500 mb-1",
                                                            children: t('filterLocation')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 819,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: scFilterLocation,
                                                            onChange: (e)=>{
                                                                setScFilterLocation(e.target.value);
                                                                setScFilterRoom('');
                                                            },
                                                            className: inputCls,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: t('allLocations')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 821,
                                                                    columnNumber: 27
                                                                }, this),
                                                                scLocations.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                        value: l.id,
                                                                        children: l.name
                                                                    }, l.id, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 822,
                                                                        columnNumber: 49
                                                                    }, this))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 820,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 818,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-500 mb-1",
                                                            children: t('filterRoom')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 826,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: scFilterRoom,
                                                            onChange: (e)=>setScFilterRoom(e.target.value),
                                                            className: inputCls,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: t('allRooms')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 828,
                                                                    columnNumber: 27
                                                                }, this),
                                                                scRooms.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                        value: r.id,
                                                                        children: r.name
                                                                    }, r.id, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 829,
                                                                        columnNumber: 45
                                                                    }, this))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 827,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 825,
                                                    columnNumber: 23
                                                }, this),
                                                (scFilterStudent || scFilterFrom || scFilterTo || scFilterTeacher || scFilterLocation || scFilterRoom) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>{
                                                        setScFilterStudent('');
                                                        setScFilterFrom('');
                                                        setScFilterTo('');
                                                        setScFilterTeacher('');
                                                        setScFilterLocation('');
                                                        setScFilterRoom('');
                                                    },
                                                    className: "px-3 py-1.5 text-xs text-gray-400 hover:text-gray-600 border border-gray-200 rounded-lg",
                                                    children: t('clearFilters')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 833,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 795,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 794,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: filteredScRows.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white rounded-xl border border-gray-100 p-8 text-center text-sm text-gray-400",
                                            children: t('noStudents')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 846,
                                            columnNumber: 23
                                        }, this) : filteredScRows.map((sc)=>{
                                            const isExpanded = scExpandedStudent === sc.student_id;
                                            const totalBurned = sc.attendance.filter((a)=>a.status === 'present').reduce((s, a)=>s + a.credits_deducted, 0);
                                            const totalPresent = sc.attendance.filter((a)=>a.status === 'present').length;
                                            const totalNoShow = sc.attendance.filter((a)=>a.status === 'no_show').length;
                                            const activePackages = sc.packages.filter((p)=>p.status === 'active');
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>setScExpandedStudent(isExpanded ? null : sc.student_id),
                                                        className: "w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition text-left",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-4",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "font-semibold text-gray-900",
                                                                        children: sc.student_name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 862,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs text-gray-400",
                                                                        children: t('scLessonsAttended', {
                                                                            count: totalPresent
                                                                        })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 863,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    totalNoShow > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs text-red-400",
                                                                        children: t('scNoShows', {
                                                                            count: totalNoShow
                                                                        })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 865,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    totalBurned > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs text-orange-600 font-medium",
                                                                        children: t('scCreditsBurned', {
                                                                            count: totalBurned
                                                                        })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 868,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 861,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-4",
                                                                children: [
                                                                    activePackages.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full",
                                                                        children: t('scActivePackages', {
                                                                            count: activePackages.length
                                                                        })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 873,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        viewBox: "0 0 20 20",
                                                                        fill: "currentColor",
                                                                        className: "w-4 h-4 text-gray-400 transition-transform ".concat(isExpanded ? 'rotate-180' : ''),
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            fillRule: "evenodd",
                                                                            d: "M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z",
                                                                            clipRule: "evenodd"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                            lineNumber: 879,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 877,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 871,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                        lineNumber: 857,
                                                        columnNumber: 27
                                                    }, this),
                                                    isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "border-t border-gray-100",
                                                        children: [
                                                            sc.packages.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "px-6 py-4 border-b border-gray-50 bg-gray-50/50",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide mb-3",
                                                                        children: t('scPackagesTitle')
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 889,
                                                                        columnNumber: 35
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex flex-wrap gap-3",
                                                                        children: sc.packages.map((pkg)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "text-xs px-3 py-2 rounded-lg border ".concat(pkg.status === 'active' ? 'border-green-200 bg-green-50' : 'border-gray-200 bg-white'),
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "font-medium ".concat(pkg.status === 'active' ? 'text-green-700' : 'text-gray-500'),
                                                                                        children: [
                                                                                            pkg.credits_remaining,
                                                                                            "/",
                                                                                            pkg.credits_total,
                                                                                            " ",
                                                                                            t('colCredits')
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 893,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    pkg.expires_at && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "text-gray-400 ml-2",
                                                                                        children: [
                                                                                            t('scExpires'),
                                                                                            " ",
                                                                                            new Date(pkg.expires_at).toLocaleDateString('en-GB', {
                                                                                                day: '2-digit',
                                                                                                month: 'short',
                                                                                                year: 'numeric'
                                                                                            })
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 897,
                                                                                        columnNumber: 43
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "ml-2 px-1.5 py-0.5 rounded-full ".concat(pkg.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'),
                                                                                        children: pkg.status
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 901,
                                                                                        columnNumber: 41
                                                                                    }, this)
                                                                                ]
                                                                            }, pkg.id, true, {
                                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                lineNumber: 892,
                                                                                columnNumber: 39
                                                                            }, this))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                        lineNumber: 890,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 888,
                                                                columnNumber: 33
                                                            }, this),
                                                            sc.attendance.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "px-6 py-4 text-sm text-gray-400",
                                                                children: t('scNoAttendance')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 912,
                                                                columnNumber: 33
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "overflow-x-auto",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                                                    className: "w-full text-sm",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                                className: "border-b border-gray-100 bg-gray-50",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-left text-gray-400",
                                                                                        children: t('colDate')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 918,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-left text-gray-400",
                                                                                        children: t('colLesson')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 919,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-left text-gray-400",
                                                                                        children: t('colTeacher')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 920,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-left text-gray-400",
                                                                                        children: t('colLocation')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 921,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-left text-gray-400",
                                                                                        children: t('colRoom')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 922,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-right text-gray-400",
                                                                                        children: t('colCreditsBurned')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 923,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-left text-gray-400",
                                                                                        children: t('colSource')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 924,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                        className: "px-4 py-3 text-xs font-medium uppercase tracking-wide text-left text-gray-400",
                                                                                        children: t('colStatus')
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                        lineNumber: 925,
                                                                                        columnNumber: 41
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                lineNumber: 917,
                                                                                columnNumber: 39
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                            lineNumber: 916,
                                                                            columnNumber: 37
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                                            className: "divide-y divide-gray-50",
                                                                            children: sc.attendance.map((a, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                                    className: "hover:bg-gray-50 transition",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3 text-gray-500 whitespace-nowrap",
                                                                                            children: [
                                                                                                new Date(a.date).toLocaleDateString('en-GB', {
                                                                                                    day: '2-digit',
                                                                                                    month: 'short',
                                                                                                    year: 'numeric'
                                                                                                }),
                                                                                                a.start_time && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "text-xs text-gray-400 ml-1",
                                                                                                    children: a.start_time
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                                    lineNumber: 933,
                                                                                                    columnNumber: 62
                                                                                                }, this)
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 931,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3 font-medium text-gray-900",
                                                                                            children: a.course_name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 935,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3 text-gray-600",
                                                                                            children: a.teacher_name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 936,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3 text-gray-500 text-xs",
                                                                                            children: a.location_name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 937,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3 text-gray-500 text-xs",
                                                                                            children: a.room_name
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 938,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3 text-right font-semibold text-orange-600",
                                                                                            children: a.credits_deducted > 0 ? a.credits_deducted : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                className: "text-gray-300 font-normal",
                                                                                                children: "—"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                                lineNumber: 940,
                                                                                                columnNumber: 92
                                                                                            }, this)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 939,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3 text-xs text-gray-400",
                                                                                            children: a.access_source
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 942,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                            className: "px-4 py-3",
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                className: "text-xs px-2 py-0.5 rounded-full ".concat(a.status === 'present' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'),
                                                                                                children: a.status
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                                lineNumber: 944,
                                                                                                columnNumber: 45
                                                                                            }, this)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                            lineNumber: 943,
                                                                                            columnNumber: 43
                                                                                        }, this)
                                                                                    ]
                                                                                }, i, true, {
                                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                                    lineNumber: 930,
                                                                                    columnNumber: 41
                                                                                }, this))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                            lineNumber: 928,
                                                                            columnNumber: 37
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 915,
                                                                    columnNumber: 35
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 914,
                                                                columnNumber: 33
                                                            }, this),
                                                            sc.attendance.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "px-6 py-3 border-t border-gray-50 flex justify-end",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>downloadCSV(sc.attendance.map((a)=>({
                                                                                Student: sc.student_name,
                                                                                Date: a.date,
                                                                                Time: a.start_time,
                                                                                Lesson: a.course_name,
                                                                                Teacher: a.teacher_name,
                                                                                Location: a.location_name,
                                                                                Room: a.room_name,
                                                                                'Credits Deducted': a.credits_deducted,
                                                                                'Access Source': a.access_source,
                                                                                Status: a.status
                                                                            })), "".concat(sc.student_name.replace(/\s+/g, '-'), "-classes-").concat(new Date().toISOString().slice(0, 10), ".csv")),
                                                                    className: "text-xs text-[#6B1F3A] border border-[#6B1F3A]/30 px-3 py-1.5 rounded-lg hover:bg-[#6B1F3A]/5 transition",
                                                                    children: t('exportCSV')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 958,
                                                                    columnNumber: 35
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 957,
                                                                columnNumber: 33
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                        lineNumber: 885,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, sc.student_id, true, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 855,
                                                columnNumber: 25
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 844,
                                        columnNumber: 19
                                    }, this),
                                    filteredScRows.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-end",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>{
                                                const allRows = [];
                                                for (const sc of filteredScRows){
                                                    for (const a of sc.attendance){
                                                        allRows.push({
                                                            Student: sc.student_name,
                                                            Date: a.date,
                                                            Time: a.start_time,
                                                            Lesson: a.course_name,
                                                            Teacher: a.teacher_name,
                                                            Location: a.location_name,
                                                            Room: a.room_name,
                                                            'Credits Deducted': a.credits_deducted,
                                                            'Access Source': a.access_source,
                                                            Status: a.status
                                                        });
                                                    }
                                                }
                                                downloadCSV(allRows, "student-classes-".concat(new Date().toISOString().slice(0, 10), ".csv"));
                                            },
                                            className: "text-sm text-[#6B1F3A] border border-[#6B1F3A]/30 px-4 py-2 rounded-lg hover:bg-[#6B1F3A]/5 transition",
                                            children: t('exportAllCSV')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 990,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 989,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                        lineNumber: 788,
                        columnNumber: 13
                    }, this),
                    activeTab === 'teachers' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "px-6 py-4 border-b border-gray-100 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "font-semibold text-gray-900",
                                            children: t('teacherPerformanceTitle')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 1027,
                                            columnNumber: 19
                                        }, this),
                                        filteredTeachers.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tooltip, {
                                            text: t('exportTeachersTooltip', {
                                                count: filteredTeachers.length
                                            }),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>downloadCSV(filteredTeachers.map((r)=>({
                                                            Name: r.name,
                                                            'Lessons (Month)': r.lessons_this_month,
                                                            'Total Students': r.total_students,
                                                            'Attendance Rate': r.attendance_rate === '—' ? '—' : "".concat(r.attendance_rate, "%"),
                                                            'Compensation Estimate (€)': r.compensation_estimate.toFixed(2)
                                                        })), "school-teachers-".concat(new Date().toISOString().slice(0, 10), ".csv")),
                                                className: "text-sm text-[#6B1F3A] border border-[#6B1F3A]/30 px-3 py-1.5 rounded-lg hover:bg-[#6B1F3A]/5 transition",
                                                children: t('exportCSV')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 1030,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                            lineNumber: 1029,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                    lineNumber: 1026,
                                    columnNumber: 17
                                }, this),
                                filteredTeachers.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "p-8 text-center text-sm text-gray-400",
                                    children: t('noTeachers')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                    lineNumber: 1043,
                                    columnNumber: 19
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-x-auto",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "w-full text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "border-b border-gray-100 bg-gray-50",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                            label: t('colTeacher'),
                                                            col: "name",
                                                            sortCol: teacherSortCol,
                                                            sortDir: teacherSortDir,
                                                            onSort: handleTeacherSort
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 1049,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                            label: t('colLessonsMonth'),
                                                            col: "lessons_this_month",
                                                            sortCol: teacherSortCol,
                                                            sortDir: teacherSortDir,
                                                            onSort: handleTeacherSort,
                                                            right: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 1050,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                            label: t('colStudents'),
                                                            col: "total_students",
                                                            sortCol: teacherSortCol,
                                                            sortDir: teacherSortDir,
                                                            onSort: handleTeacherSort,
                                                            right: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 1051,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                            label: t('colAttendanceRate'),
                                                            col: "attendance_rate",
                                                            sortCol: teacherSortCol,
                                                            sortDir: teacherSortDir,
                                                            onSort: handleTeacherSort,
                                                            right: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 1052,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortTh, {
                                                            label: t('colEstCompensation'),
                                                            col: "compensation_estimate",
                                                            sortCol: teacherSortCol,
                                                            sortDir: teacherSortDir,
                                                            onSort: handleTeacherSort,
                                                            right: true
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                            lineNumber: 1053,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                    lineNumber: 1048,
                                                    columnNumber: 25
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 1047,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                className: "divide-y divide-gray-50",
                                                children: filteredTeachers.map((row)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                        className: "hover:bg-gray-50 transition",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "px-4 py-3 font-medium text-gray-900",
                                                                children: row.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 1059,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "px-4 py-3 text-right text-gray-900 font-medium",
                                                                children: row.lessons_this_month
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 1060,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "px-4 py-3 text-right text-gray-900",
                                                                children: row.total_students
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 1061,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "px-4 py-3 text-right",
                                                                children: row.attendance_rate === '—' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-gray-400",
                                                                    children: "—"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 1063,
                                                                    columnNumber: 62
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "font-semibold ".concat(parseFloat(row.attendance_rate) >= 80 ? 'text-green-700' : parseFloat(row.attendance_rate) >= 60 ? 'text-yellow-600' : 'text-red-500'),
                                                                    children: [
                                                                        row.attendance_rate,
                                                                        "%"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 1064,
                                                                    columnNumber: 33
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 1062,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "px-4 py-3 text-right font-semibold text-[#6B1F3A]",
                                                                children: row.compensation_estimate > 0 ? "€".concat(row.compensation_estimate.toFixed(2)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-gray-400 font-normal",
                                                                    children: "—"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                    lineNumber: 1070,
                                                                    columnNumber: 109
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                                lineNumber: 1069,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, row.id, true, {
                                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                        lineNumber: 1058,
                                                        columnNumber: 27
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                                lineNumber: 1056,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                        lineNumber: 1046,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                                    lineNumber: 1045,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                            lineNumber: 1025,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
                        lineNumber: 1024,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/reports/page.tsx",
        lineNumber: 489,
        columnNumber: 5
    }, this);
}
_s(SchoolReportsPage, "r72FhX04O9lWSmcU0nWjlNU586Q=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c2 = SchoolReportsPage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "SortTh");
__turbopack_context__.k.register(_c1, "Tooltip");
__turbopack_context__.k.register(_c2, "SchoolReportsPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_school_reports_page_tsx_82baf794._.js.map