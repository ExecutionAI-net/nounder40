(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/SchoolSelectModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SchoolSelectModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function SchoolSelectModal(param) {
    let { open, currentSchoolId, onSaved } = param;
    _s();
    const [schools, setSchools] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(currentSchoolId !== null && currentSchoolId !== void 0 ? currentSchoolId : '');
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SchoolSelectModal.useEffect": ()=>{
            fetch('/api/schools/public').then({
                "SchoolSelectModal.useEffect": (r)=>r.json()
            }["SchoolSelectModal.useEffect"]).then({
                "SchoolSelectModal.useEffect": (d)=>setSchools(Array.isArray(d) ? d : [])
            }["SchoolSelectModal.useEffect"]).catch({
                "SchoolSelectModal.useEffect": ()=>{}
            }["SchoolSelectModal.useEffect"]);
        }
    }["SchoolSelectModal.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SchoolSelectModal.useEffect": ()=>{
            setSelected(currentSchoolId !== null && currentSchoolId !== void 0 ? currentSchoolId : '');
        }
    }["SchoolSelectModal.useEffect"], [
        currentSchoolId
    ]);
    if (!open) return null;
    async function handleSave() {
        if (!selected) return;
        setSaving(true);
        setError(null);
        const res = await fetch('/api/student/school', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                school_id: selected
            })
        });
        const data = await res.json();
        if (!res.ok) {
            var _data_error;
            setError((_data_error = data.error) !== null && _data_error !== void 0 ? _data_error : 'Failed to save');
            setSaving(false);
            return;
        }
        const school = schools.find((s)=>s.id === selected);
        onSaved(school);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-6 py-5 border-b border-gray-100",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "font-semibold text-gray-900 text-lg",
                            children: currentSchoolId ? 'Change School' : 'Choose Your School'
                        }, void 0, false, {
                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-400 mt-0.5",
                            children: currentSchoolId ? 'Select a new school. Your current school link will be removed.' : 'Select the school where you will be taking classes.'
                        }, void 0, false, {
                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/SchoolSelectModal.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-6 py-4",
                    children: [
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-3 p-3 bg-red-50 text-red-600 text-sm rounded-lg",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                            lineNumber: 66,
                            columnNumber: 21
                        }, this),
                        schools.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-400 py-4 text-center",
                            children: "Loading schools..."
                        }, void 0, false, {
                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                            lineNumber: 69,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-2 max-h-72 overflow-y-auto pr-1",
                            children: schools.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>setSelected(s.id),
                                    className: "w-full flex items-center gap-3 p-3 rounded-xl border text-left transition ".concat(selected === s.id ? 'border-[#6B1F3A] bg-[#6B1F3A]/5' : 'border-gray-200 hover:border-gray-300'),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center ".concat(selected === s.id ? 'border-[#6B1F3A]' : 'border-gray-300'),
                                            children: selected === s.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-2 h-2 rounded-full bg-[#6B1F3A]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/SchoolSelectModal.tsx",
                                                lineNumber: 86,
                                                columnNumber: 43
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                                            lineNumber: 83,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-medium ".concat(selected === s.id ? 'text-[#6B1F3A]' : 'text-gray-900'),
                                                    children: s.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/SchoolSelectModal.tsx",
                                                    lineNumber: 89,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-400",
                                                    children: [
                                                        s.city,
                                                        ", ",
                                                        s.country
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/SchoolSelectModal.tsx",
                                                    lineNumber: 92,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                                            lineNumber: 88,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, s.id, true, {
                                    fileName: "[project]/src/components/SchoolSelectModal.tsx",
                                    lineNumber: 73,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                            lineNumber: 71,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: handleSave,
                            disabled: !selected || saving,
                            className: "mt-4 w-full py-2.5 bg-[#6B1F3A] text-white rounded-lg text-sm font-medium hover:bg-[#5a1930] transition disabled:opacity-50",
                            children: saving ? 'Saving...' : 'Confirm School'
                        }, void 0, false, {
                            fileName: "[project]/src/components/SchoolSelectModal.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/SchoolSelectModal.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/SchoolSelectModal.tsx",
            lineNumber: 53,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/SchoolSelectModal.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_s(SchoolSelectModal, "Y6fYYCXrq2UE0Twm7YbuPl84ogw=");
_c = SchoolSelectModal;
var _c;
__turbopack_context__.k.register(_c, "SchoolSelectModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/[locale]/student/profile/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StudentProfilePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SchoolSelectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SchoolSelectModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const LANGUAGES = [
    {
        value: 'it',
        label: 'Italiano'
    },
    {
        value: 'en',
        label: 'English'
    },
    {
        value: 'es',
        label: 'Español'
    }
];
const DOC_TYPES = [
    'medical_cert',
    'privacy',
    'image_release'
];
const STATUS_COLORS = {
    valid: 'bg-green-100 text-green-700',
    expiring: 'bg-yellow-100 text-yellow-700',
    expired: 'bg-red-100 text-red-600'
};
function StudentProfilePage() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('student.profile');
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const [tab, setTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('profile');
    const [hqCountries, setHqCountries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [hqCities, setHqCities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [profile, setProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentSchool, setCurrentSchool] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [schoolModalOpen, setSchoolModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [docs, setDocs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [docsLoading, setDocsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [enrolledSchools, setEnrolledSchools] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [uploading, setUploading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [uploadError, setUploadError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [pendingUpload, setPendingUpload] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const DOC_LABELS = {
        medical_cert: t('docMedicalCert'),
        privacy: t('docPrivacy'),
        image_release: t('docImageRelease')
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudentProfilePage.useEffect": ()=>{
            fetch('/api/student/school').then({
                "StudentProfilePage.useEffect": (r)=>r.json()
            }["StudentProfilePage.useEffect"]).then({
                "StudentProfilePage.useEffect": (d)=>{
                    var _d_school;
                    return setCurrentSchool((_d_school = d.school) !== null && _d_school !== void 0 ? _d_school : null);
                }
            }["StudentProfilePage.useEffect"]).catch({
                "StudentProfilePage.useEffect": ()=>{}
            }["StudentProfilePage.useEffect"]);
        }
    }["StudentProfilePage.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudentProfilePage.useEffect": ()=>{
            fetch('/api/locations').then({
                "StudentProfilePage.useEffect": (r)=>r.json()
            }["StudentProfilePage.useEffect"]).then({
                "StudentProfilePage.useEffect": (d)=>{
                    var _d_countries;
                    setHqCountries((_d_countries = d.countries) !== null && _d_countries !== void 0 ? _d_countries : []);
                    var _d_cities;
                    setHqCities((_d_cities = d.cities) !== null && _d_cities !== void 0 ? _d_cities : []);
                }
            }["StudentProfilePage.useEffect"]).catch({
                "StudentProfilePage.useEffect": ()=>{}
            }["StudentProfilePage.useEffect"]);
        }
    }["StudentProfilePage.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudentProfilePage.useEffect": ()=>{
            async function load() {
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) return;
                const { data: profileData } = await supabase.from('profiles').select('name, city').eq('id', user.id).single();
                let { data: student } = await supabase.from('students').select('name, phone, date_of_birth, address, city, country, language_preference').eq('user_id', user.id).maybeSingle();
                if (!student) {
                    var _user_user_metadata;
                    const meta = (_user_user_metadata = user.user_metadata) !== null && _user_user_metadata !== void 0 ? _user_user_metadata : {};
                    var _meta_name, _ref;
                    const name = (_ref = (_meta_name = meta.name) !== null && _meta_name !== void 0 ? _meta_name : profileData === null || profileData === void 0 ? void 0 : profileData.name) !== null && _ref !== void 0 ? _ref : user.email.split('@')[0];
                    let detectedLanguage = 'en';
                    try {
                        const langRes = await fetch('/api/student/detect-language');
                        if (langRes.ok) {
                            const langData = await langRes.json();
                            var _langData_language;
                            detectedLanguage = (_langData_language = langData.language) !== null && _langData_language !== void 0 ? _langData_language : 'en';
                        }
                    } catch (e) {}
                    var _meta_phone, _meta_date_of_birth, _meta_city, _meta_country;
                    const { error: insertErr } = await supabase.from('students').insert({
                        user_id: user.id,
                        name,
                        email: user.email,
                        phone: (_meta_phone = meta.phone) !== null && _meta_phone !== void 0 ? _meta_phone : null,
                        date_of_birth: (_meta_date_of_birth = meta.date_of_birth) !== null && _meta_date_of_birth !== void 0 ? _meta_date_of_birth : null,
                        city: (_meta_city = meta.city) !== null && _meta_city !== void 0 ? _meta_city : null,
                        country: (_meta_country = meta.country) !== null && _meta_country !== void 0 ? _meta_country : null,
                        language_preference: detectedLanguage
                    });
                    if (insertErr) {
                        console.error('[profile] student insert error:', insertErr.message);
                    } else {
                        const { data: newStudent } = await supabase.from('students').select('name, phone, date_of_birth, address, city, country').eq('user_id', user.id).maybeSingle();
                        student = newStudent;
                    }
                }
                var _student_name, _ref1, _user_email, _student_phone, _student_date_of_birth, _student_address, _student_city, _ref2, _student_country, _student_language_preference;
                const merged = {
                    name: (_ref1 = (_student_name = student === null || student === void 0 ? void 0 : student.name) !== null && _student_name !== void 0 ? _student_name : profileData === null || profileData === void 0 ? void 0 : profileData.name) !== null && _ref1 !== void 0 ? _ref1 : '',
                    email: (_user_email = user.email) !== null && _user_email !== void 0 ? _user_email : '',
                    phone: (_student_phone = student === null || student === void 0 ? void 0 : student.phone) !== null && _student_phone !== void 0 ? _student_phone : null,
                    date_of_birth: (_student_date_of_birth = student === null || student === void 0 ? void 0 : student.date_of_birth) !== null && _student_date_of_birth !== void 0 ? _student_date_of_birth : null,
                    address: (_student_address = student === null || student === void 0 ? void 0 : student.address) !== null && _student_address !== void 0 ? _student_address : null,
                    city: (_ref2 = (_student_city = student === null || student === void 0 ? void 0 : student.city) !== null && _student_city !== void 0 ? _student_city : profileData === null || profileData === void 0 ? void 0 : profileData.city) !== null && _ref2 !== void 0 ? _ref2 : null,
                    country: (_student_country = student === null || student === void 0 ? void 0 : student.country) !== null && _student_country !== void 0 ? _student_country : null,
                    language_preference: (_student_language_preference = student === null || student === void 0 ? void 0 : student.language_preference) !== null && _student_language_preference !== void 0 ? _student_language_preference : 'en'
                };
                setProfile(merged);
                setForm(merged);
                setLoading(false);
            }
            load();
        }
    }["StudentProfilePage.useEffect"], [
        supabase
    ]); // eslint-disable-line react-hooks/exhaustive-deps
    async function loadDocs() {
        setDocsLoading(true);
        try {
            const res = await fetch('/api/student/documents');
            const data = await res.json();
            setDocs(Array.isArray(data) ? data : []);
            const { data: { user } } = await supabase.auth.getUser();
            if (user) {
                const { data: enrollments } = await supabase.from('school_students').select('school_id, schools(id, name)').eq('student_id', user.id);
                const schools = (enrollments !== null && enrollments !== void 0 ? enrollments : []).map((e)=>{
                    var _this;
                    var _name;
                    return {
                        id: e.school_id,
                        name: (_name = (_this = e.schools) === null || _this === void 0 ? void 0 : _this.name) !== null && _name !== void 0 ? _name : e.school_id
                    };
                });
                setEnrolledSchools(schools);
            }
        } catch (e) {
            console.error('[profile/documents] load error:', e);
        }
        setDocsLoading(false);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StudentProfilePage.useEffect": ()=>{
            if (tab === 'documents') loadDocs();
        }
    }["StudentProfilePage.useEffect"], [
        tab
    ]); // eslint-disable-line react-hooks/exhaustive-deps
    async function handleSave() {
        if (!form) return;
        setSaving(true);
        setError(null);
        setSuccess(false);
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;
        await supabase.from('profiles').update({
            name: form.name,
            city: form.city
        }).eq('id', user.id);
        const { error: err } = await supabase.from('students').upsert({
            user_id: user.id,
            name: form.name,
            email: form.email,
            phone: form.phone,
            date_of_birth: form.date_of_birth || null,
            address: form.address,
            city: form.city,
            country: form.country,
            language_preference: form.language_preference
        }, {
            onConflict: 'user_id'
        });
        if (err) {
            setError(err.message);
        } else {
            setSuccess(true);
            setProfile(form);
        }
        setSaving(false);
    }
    function triggerUpload(schoolId, type) {
        var _fileInputRef_current;
        setPendingUpload({
            schoolId,
            type
        });
        setUploadError(null);
        (_fileInputRef_current = fileInputRef.current) === null || _fileInputRef_current === void 0 ? void 0 : _fileInputRef_current.click();
    }
    async function handleFileChange(e) {
        var _e_target_files;
        const file = (_e_target_files = e.target.files) === null || _e_target_files === void 0 ? void 0 : _e_target_files[0];
        if (!file || !pendingUpload) return;
        const { schoolId, type } = pendingUpload;
        const key = "".concat(schoolId, "-").concat(type);
        setUploading(key);
        setUploadError(null);
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) throw new Error('Not authenticated');
            const ext = file.name.split('.').pop();
            const path = "".concat(user.id, "/").concat(schoolId, "/").concat(type, "-").concat(Date.now(), ".").concat(ext);
            const { error: uploadErr } = await supabase.storage.from('documents').upload(path, file, {
                upsert: true
            });
            if (uploadErr) throw uploadErr;
            const { data: urlData } = supabase.storage.from('documents').getPublicUrl(path);
            const file_url = urlData.publicUrl;
            const res = await fetch('/api/student/documents', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    school_id: schoolId,
                    type,
                    file_url
                })
            });
            const result = await res.json();
            var _result_error;
            if (!res.ok) throw new Error((_result_error = result.error) !== null && _result_error !== void 0 ? _result_error : t('uploadFailed'));
            await loadDocs();
        } catch (err) {
            console.error('[documents] upload error:', err);
            setUploadError(err instanceof Error ? err.message : t('uploadFailed'));
        }
        setUploading(null);
        setPendingUpload(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
    }
    if (loading || !form) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "animate-pulse h-8 bg-gray-100 rounded w-48"
        }, void 0, false, {
            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
            lineNumber: 279,
            columnNumber: 12
        }, this);
    }
    const profileTabs = [
        {
            key: 'profile',
            label: t('tabProfile')
        },
        {
            key: 'documents',
            label: t('tabDocuments')
        }
    ];
    var _form_phone, _form_date_of_birth, _form_address, _form_country, _form_country1, _form_city;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-2xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl font-bold text-gray-900 mb-6",
                children: t('title')
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                lineNumber: 289,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-1 mb-6 border-b border-gray-100",
                children: profileTabs.map((tb)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setTab(tb.key),
                        className: "px-4 py-2 text-sm font-medium capitalize transition border-b-2 -mb-px ".concat(tab === tb.key ? 'border-[#6B1F3A] text-[#6B1F3A]' : 'border-transparent text-gray-500 hover:text-gray-700'),
                        children: tb.label
                    }, tb.key, false, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 293,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                lineNumber: 291,
                columnNumber: 7
            }, this),
            tab === 'profile' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-xl border border-gray-100 p-6 space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-medium text-gray-500 mb-1",
                                        children: t('fullName')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 309,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm",
                                        value: form.name,
                                        onChange: (e)=>setForm({
                                                ...form,
                                                name: e.target.value
                                            })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 310,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 308,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-medium text-gray-500 mb-1",
                                        children: t('email')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 318,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50 text-gray-400",
                                        value: form.email,
                                        disabled: true
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 319,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 317,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-medium text-gray-500 mb-1",
                                        children: t('phone')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 327,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm",
                                        value: (_form_phone = form.phone) !== null && _form_phone !== void 0 ? _form_phone : '',
                                        onChange: (e)=>setForm({
                                                ...form,
                                                phone: e.target.value
                                            })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 328,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 326,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-medium text-gray-500 mb-1",
                                        children: t('dateOfBirth')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 336,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "date",
                                        className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm",
                                        value: (_form_date_of_birth = form.date_of_birth) !== null && _form_date_of_birth !== void 0 ? _form_date_of_birth : '',
                                        onChange: (e)=>setForm({
                                                ...form,
                                                date_of_birth: e.target.value
                                            })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 337,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 335,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-medium text-gray-500 mb-1",
                                        children: t('address')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 346,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm",
                                        value: (_form_address = form.address) !== null && _form_address !== void 0 ? _form_address : '',
                                        onChange: (e)=>setForm({
                                                ...form,
                                                address: e.target.value
                                            })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 347,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 345,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-xs font-medium text-gray-500 mb-1",
                                                children: t('country')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                lineNumber: 356,
                                                columnNumber: 17
                                            }, this),
                                            hqCountries.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm",
                                                value: (_form_country = form.country) !== null && _form_country !== void 0 ? _form_country : '',
                                                onChange: (e)=>setForm({
                                                        ...form,
                                                        country: e.target.value
                                                    })
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                lineNumber: 358,
                                                columnNumber: 19
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white",
                                                value: (_form_country1 = form.country) !== null && _form_country1 !== void 0 ? _form_country1 : '',
                                                onChange: (e)=>setForm({
                                                        ...form,
                                                        country: e.target.value,
                                                        city: ''
                                                    }),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        children: t('selectCountry')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                        lineNumber: 369,
                                                        columnNumber: 21
                                                    }, this),
                                                    hqCountries.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: c.name,
                                                            children: c.name
                                                        }, c.id, false, {
                                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                            lineNumber: 371,
                                                            columnNumber: 23
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                lineNumber: 364,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 355,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-xs font-medium text-gray-500 mb-1",
                                                children: t('city')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                lineNumber: 377,
                                                columnNumber: 17
                                            }, this),
                                            hqCountries.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm",
                                                value: (_form_city = form.city) !== null && _form_city !== void 0 ? _form_city : '',
                                                onChange: (e)=>setForm({
                                                        ...form,
                                                        city: e.target.value
                                                    })
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                lineNumber: 379,
                                                columnNumber: 19
                                            }, this) : (()=>{
                                                const matchedCountry = hqCountries.find((c)=>c.name === form.country);
                                                const filteredCities = matchedCountry ? hqCities.filter((c)=>c.country_id === matchedCountry.id) : [];
                                                var _form_city;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white disabled:opacity-50 disabled:cursor-not-allowed",
                                                    value: (_form_city = form.city) !== null && _form_city !== void 0 ? _form_city : '',
                                                    onChange: (e)=>setForm({
                                                            ...form,
                                                            city: e.target.value
                                                        }),
                                                    disabled: !form.country || filteredCities.length === 0,
                                                    children: !form.country ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        children: t('selectCountryFirst')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                        lineNumber: 397,
                                                        columnNumber: 25
                                                    }, this) : filteredCities.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        children: t('noCitiesAvailable')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                        lineNumber: 399,
                                                        columnNumber: 25
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: "",
                                                                children: t('selectCity')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                lineNumber: 402,
                                                                columnNumber: 27
                                                            }, this),
                                                            filteredCities.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: c.name,
                                                                    children: c.name
                                                                }, c.id, false, {
                                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                    lineNumber: 404,
                                                                    columnNumber: 29
                                                                }, this))
                                                        ]
                                                    }, void 0, true)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                    lineNumber: 390,
                                                    columnNumber: 21
                                                }, this);
                                            })()
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 376,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 354,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-medium text-gray-500 mb-1",
                                        children: t('language')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 415,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        className: "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm",
                                        value: form.language_preference,
                                        onChange: (e)=>setForm({
                                                ...form,
                                                language_preference: e.target.value
                                            }),
                                        children: LANGUAGES.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: l.value,
                                                children: l.label
                                            }, l.value, false, {
                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                lineNumber: 422,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 416,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-400 mt-1",
                                        children: t('languageHint')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                        lineNumber: 425,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 414,
                                columnNumber: 13
                            }, this),
                            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-red-600 text-sm",
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 428,
                                columnNumber: 23
                            }, this),
                            success && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-green-600 text-sm",
                                children: t('profileUpdated')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 429,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSave,
                                disabled: saving,
                                className: "w-full bg-[#6B1F3A] text-white rounded-lg py-2.5 text-sm font-medium hover:bg-[#5a1930] transition disabled:opacity-50",
                                children: saving ? t('saving') : t('saveChanges')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 431,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 307,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-xl border border-gray-100 p-6 mt-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm font-medium text-gray-700",
                                            children: t('mySchool')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                            lineNumber: 444,
                                            columnNumber: 17
                                        }, this),
                                        currentSchool ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-gray-500 mt-0.5",
                                            children: [
                                                currentSchool.name,
                                                " — ",
                                                currentSchool.city
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                            lineNumber: 446,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-gray-400 mt-0.5",
                                            children: t('noSchoolSelected')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                            lineNumber: 448,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                    lineNumber: 443,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setSchoolModalOpen(true),
                                    className: "text-sm text-[#6B1F3A] font-medium hover:underline",
                                    children: currentSchool ? t('changeSchool') : t('selectSchool')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                    lineNumber: 451,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                            lineNumber: 442,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 441,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SchoolSelectModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        open: schoolModalOpen,
                        currentSchoolId: currentSchool === null || currentSchool === void 0 ? void 0 : currentSchool.id,
                        onSaved: (school)=>{
                            setCurrentSchool(school);
                            setSchoolModalOpen(false);
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 460,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            tab === 'documents' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: fileInputRef,
                        type: "file",
                        accept: ".pdf,.jpg,.jpeg,.png",
                        className: "hidden",
                        onChange: handleFileChange
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 470,
                        columnNumber: 11
                    }, this),
                    docsLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm text-gray-400 py-8 text-center",
                        children: t('loading')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 479,
                        columnNumber: 13
                    }, this) : enrolledSchools.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-xl border border-gray-100 p-8 text-center text-sm text-gray-400",
                        children: t('notEnrolled')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 481,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: [
                            uploadError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-red-600 text-sm",
                                children: uploadError
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                lineNumber: 487,
                                columnNumber: 17
                            }, this),
                            enrolledSchools.map((school)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "px-5 py-3 bg-gray-50 border-b border-gray-100",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm font-medium text-gray-700",
                                                children: school.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                lineNumber: 492,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                            lineNumber: 491,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "divide-y divide-gray-50",
                                            children: DOC_TYPES.map((type)=>{
                                                const doc = docs.find((d)=>d.school_id === school.id && d.type === type);
                                                const key = "".concat(school.id, "-").concat(type);
                                                const isUploading = uploading === key;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between px-5 py-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-sm font-medium text-gray-800",
                                                                    children: DOC_LABELS[type]
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                    lineNumber: 502,
                                                                    columnNumber: 29
                                                                }, this),
                                                                doc ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 mt-0.5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs px-2 py-0.5 rounded-full ".concat(STATUS_COLORS[doc.status]),
                                                                            children: t("docStatus.".concat(doc.status))
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                            lineNumber: 505,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        doc.expires_at && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-gray-400",
                                                                            children: t('docExpires', {
                                                                                date: new Date(doc.expires_at).toLocaleDateString('en-GB', {
                                                                                    day: '2-digit',
                                                                                    month: 'short',
                                                                                    year: 'numeric'
                                                                                })
                                                                            })
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                            lineNumber: 509,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        !doc.validated_at && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-xs text-amber-600",
                                                                            children: t('pendingReview')
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                            lineNumber: 514,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                    lineNumber: 504,
                                                                    columnNumber: 31
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-xs text-gray-400 mt-0.5",
                                                                    children: t('notUploaded')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                    lineNumber: 518,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                            lineNumber: 501,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-3",
                                                            children: [
                                                                (doc === null || doc === void 0 ? void 0 : doc.file_url) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    href: doc.file_url,
                                                                    target: "_blank",
                                                                    rel: "noopener noreferrer",
                                                                    className: "text-xs text-[#6B1F3A] hover:underline",
                                                                    children: t('view')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                    lineNumber: 523,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>triggerUpload(school.id, type),
                                                                    disabled: isUploading,
                                                                    className: "text-xs bg-[#6B1F3A] text-white px-3 py-1.5 rounded-lg hover:bg-[#5a1930] transition disabled:opacity-50",
                                                                    children: isUploading ? t('uploading') : doc ? t('replace') : t('upload')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                                    lineNumber: 532,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                            lineNumber: 521,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, type, true, {
                                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                                    lineNumber: 500,
                                                    columnNumber: 25
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                            lineNumber: 494,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, school.id, true, {
                                    fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                                    lineNumber: 490,
                                    columnNumber: 17
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                        lineNumber: 485,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
                lineNumber: 469,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/student/profile/page.tsx",
        lineNumber: 288,
        columnNumber: 5
    }, this);
}
_s(StudentProfilePage, "PRzgR0GWKOnw9XOCGFhgwuQ/yaM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = StudentProfilePage;
var _c;
__turbopack_context__.k.register(_c, "StudentProfilePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_aac94e16._.js.map