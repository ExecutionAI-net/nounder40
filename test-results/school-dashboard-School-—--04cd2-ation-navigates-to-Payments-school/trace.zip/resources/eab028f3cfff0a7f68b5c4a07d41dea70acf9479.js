(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__630ad77a._.css",
  "static/chunks/node_modules_287f0ef9._.js"
],
    source: "dynamic"
});
