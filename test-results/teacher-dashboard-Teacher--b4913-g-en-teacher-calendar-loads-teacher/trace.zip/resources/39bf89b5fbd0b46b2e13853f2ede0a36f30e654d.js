(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/teacher/calendar/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TeacherCalendarPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function toISO(d) {
    return d.toISOString().split('T')[0];
}
function getWeekDates(anchor) {
    const day = anchor.getDay();
    const monday = new Date(anchor);
    monday.setDate(anchor.getDate() - (day + 6) % 7);
    return Array.from({
        length: 7
    }, (_, i)=>{
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        return d;
    });
}
function getMonthDates(anchor) {
    const year = anchor.getFullYear();
    const month = anchor.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startOffset = (firstDay.getDay() + 6) % 7;
    const totalCells = Math.ceil((startOffset + lastDay.getDate()) / 7) * 7;
    return Array.from({
        length: totalCells
    }, (_, i)=>{
        const d = new Date(firstDay);
        d.setDate(1 - startOffset + i);
        return d;
    });
}
function getRangeForMode(anchor, mode) {
    if (mode === 'day') {
        const s = toISO(anchor);
        return {
            from: s,
            to: s
        };
    }
    if (mode === 'week') {
        const dates = getWeekDates(anchor);
        return {
            from: toISO(dates[0]),
            to: toISO(dates[6])
        };
    }
    if (mode === 'month') {
        const year = anchor.getFullYear();
        const month = anchor.getMonth();
        return {
            from: toISO(new Date(year, month, 1)),
            to: toISO(new Date(year, month + 1, 0))
        };
    }
    const year = anchor.getFullYear();
    return {
        from: "".concat(year, "-01-01"),
        to: "".concat(year, "-12-31")
    };
}
function navigate(anchor, mode, dir) {
    const d = new Date(anchor);
    if (mode === 'day') d.setDate(d.getDate() + dir);
    else if (mode === 'week') d.setDate(d.getDate() + dir * 7);
    else if (mode === 'month') d.setMonth(d.getMonth() + dir);
    else d.setFullYear(d.getFullYear() + dir);
    return d;
}
function headerLabel(anchor, mode) {
    if (mode === 'day') {
        return anchor.toLocaleDateString('en-GB', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
    }
    if (mode === 'week') {
        const dates = getWeekDates(anchor);
        return "".concat(dates[0].toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short'
        }), " – ").concat(dates[6].toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        }));
    }
    if (mode === 'month') {
        return anchor.toLocaleDateString('en-GB', {
            month: 'long',
            year: 'numeric'
        });
    }
    return String(anchor.getFullYear());
}
function TeacherCalendarPage() {
    var _selected_courses, _selected_courses1, _selected_lesson_types, _selected_lesson_types1, _selected_schools, _selected_school_rooms_school_locations;
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('teacher.calendar');
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const [anchor, setAnchor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "TeacherCalendarPage.useState": ()=>new Date()
    }["TeacherCalendarPage.useState"]);
    const [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('week');
    const [lessons, setLessons] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const DAYS_SHORT = [
        t('buttonDay'),
        t('buttonWeek'),
        t('buttonMonth'),
        t('buttonYear')
    ];
    const MONTHS = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December'
    ];
    const { from, to } = getRangeForMode(anchor, mode);
    const fetchLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TeacherCalendarPage.useCallback[fetchLessons]": async ()=>{
            setLoading(true);
            const res = await fetch("/api/teacher/calendar?from=".concat(from, "&to=").concat(to));
            if (res.ok) setLessons(await res.json());
            else setLessons([]);
            setLoading(false);
        }
    }["TeacherCalendarPage.useCallback[fetchLessons]"], [
        from,
        to
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TeacherCalendarPage.useEffect": ()=>{
            fetchLessons();
        }
    }["TeacherCalendarPage.useEffect"], [
        fetchLessons
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TeacherCalendarPage.useEffect": ()=>{
            const channel = supabase.channel('teacher-lessons-realtime').on('postgres_changes', {
                event: '*',
                schema: 'public',
                table: 'lessons'
            }, {
                "TeacherCalendarPage.useEffect.channel": ()=>{
                    fetchLessons();
                }
            }["TeacherCalendarPage.useEffect.channel"]).subscribe();
            return ({
                "TeacherCalendarPage.useEffect": ()=>{
                    supabase.removeChannel(channel);
                }
            })["TeacherCalendarPage.useEffect"];
        }
    }["TeacherCalendarPage.useEffect"], [
        supabase,
        fetchLessons
    ]);
    function lessonsForDay(dateStr) {
        return lessons.filter((l)=>l.date === dateStr);
    }
    const today = toISO(new Date());
    var _selected_courses_color, _selected_courses_name, _selected_schools_name, _selected_school_rooms_school_locations_name;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-5 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold text-gray-900",
                                children: t('title')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 142,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500 text-sm mt-0.5",
                                children: headerLabel(anchor, mode)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 143,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                        lineNumber: 141,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex bg-white border border-gray-200 rounded-lg p-1 gap-0.5",
                                children: [
                                    'day',
                                    'week',
                                    'month',
                                    'year'
                                ].map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setMode(m);
                                            setSelected(null);
                                        },
                                        className: "px-3 py-1.5 text-xs font-medium rounded transition capitalize ".concat(mode === m ? 'bg-gray-800 text-white' : 'text-gray-500 hover:bg-gray-100'),
                                        children: t("button".concat(m.charAt(0).toUpperCase()).concat(m.slice(1)))
                                    }, m, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 149,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 147,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 bg-white border border-gray-200 rounded-lg p-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setAnchor(navigate(anchor, mode, -1)),
                                        className: "p-1.5 hover:bg-gray-100 rounded text-gray-500",
                                        children: t('buttonPrev')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 163,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setAnchor(new Date()),
                                        className: "px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 rounded",
                                        children: mode === 'day' ? t('buttonDay') : mode === 'week' ? t('buttonWeek') : mode === 'month' ? t('buttonMonth') : t('buttonYear')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 164,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setAnchor(navigate(anchor, mode, 1)),
                                        className: "p-1.5 hover:bg-gray-100 rounded text-gray-500",
                                        children: t('buttonNext')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 170,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 162,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 min-w-0",
                        children: [
                            mode === 'day' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 border-b border-gray-100 ".concat(today === toISO(anchor) ? 'bg-gray-800/5' : ''),
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm font-semibold text-gray-700",
                                            children: anchor.toLocaleDateString('en-GB', {
                                                weekday: 'long',
                                                day: 'numeric',
                                                month: 'long',
                                                year: 'numeric'
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                            lineNumber: 181,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 180,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 min-h-64",
                                        children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-300",
                                            children: t('noLessons')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                            lineNumber: 187,
                                            columnNumber: 19
                                        }, this) : lessonsForDay(toISO(anchor)).length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-gray-400 text-center mt-8",
                                            children: t('emptyStateMonth')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                            lineNumber: 189,
                                            columnNumber: 19
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-2",
                                            children: lessonsForDay(toISO(anchor)).sort((a, b)=>a.start_time.localeCompare(b.start_time)).map((l)=>{
                                                var _l_courses, _l_courses1, _l_lesson_types, _l_schools, _l_school_rooms;
                                                var _l_courses_color, _l_courses_name, _l_schools_name, _l_school_rooms_name;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>setSelected(l),
                                                    className: "w-full text-left rounded-xl px-4 py-3 text-sm transition hover:opacity-90 flex items-center gap-4",
                                                    style: {
                                                        backgroundColor: (_l_courses_color = (_l_courses = l.courses) === null || _l_courses === void 0 ? void 0 : _l_courses.color) !== null && _l_courses_color !== void 0 ? _l_courses_color : '#374151',
                                                        color: '#fff'
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs opacity-80 w-16 shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    children: l.start_time.slice(0, 5)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 202,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    children: l.end_time.slice(0, 5)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 203,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                            lineNumber: 201,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex-1 min-w-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "font-semibold truncate",
                                                                    children: (_l_courses_name = (_l_courses1 = l.courses) === null || _l_courses1 === void 0 ? void 0 : _l_courses1.name) !== null && _l_courses_name !== void 0 ? _l_courses_name : (_l_lesson_types = l.lesson_types) === null || _l_lesson_types === void 0 ? void 0 : _l_lesson_types.name_en
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 206,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-xs opacity-80 truncate",
                                                                    children: [
                                                                        (_l_schools_name = (_l_schools = l.schools) === null || _l_schools === void 0 ? void 0 : _l_schools.name) !== null && _l_schools_name !== void 0 ? _l_schools_name : '—',
                                                                        " · ",
                                                                        (_l_school_rooms_name = (_l_school_rooms = l.school_rooms) === null || _l_school_rooms === void 0 ? void 0 : _l_school_rooms.name) !== null && _l_school_rooms_name !== void 0 ? _l_school_rooms_name : '—'
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 207,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                            lineNumber: 205,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs opacity-70 shrink-0",
                                                            children: [
                                                                l.current_bookings,
                                                                "/",
                                                                l.max_capacity
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                            lineNumber: 209,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, l.id, true, {
                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                    lineNumber: 195,
                                                    columnNumber: 25
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                            lineNumber: 191,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 185,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 179,
                                columnNumber: 13
                            }, this),
                            mode === 'week' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7 border-b border-gray-100",
                                        children: getWeekDates(anchor).map((d, i)=>{
                                            const isToday = toISO(d) === today;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-3 text-center border-r border-gray-100 last:border-r-0 ".concat(isToday ? 'bg-gray-800/5' : ''),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-gray-400 font-medium",
                                                        children: DAYS_SHORT[i]
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 226,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-lg font-bold mt-0.5 ".concat(isToday ? 'text-gray-800' : 'text-gray-800'),
                                                        children: d.getDate()
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 227,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 225,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 221,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7 min-h-96",
                                        children: getWeekDates(anchor).map((d, i)=>{
                                            const dateStr = toISO(d);
                                            const dayLessons = lessonsForDay(dateStr);
                                            const isToday = dateStr === today;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-2 border-r border-gray-100 last:border-r-0 space-y-1.5 ".concat(isToday ? 'bg-gray-800/5' : ''),
                                                children: [
                                                    loading && i === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-300 mt-2",
                                                        children: t('noLessons')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 239,
                                                        columnNumber: 46
                                                    }, this),
                                                    dayLessons.map((l)=>{
                                                        var _l_courses, _l_courses1, _l_lesson_types;
                                                        var _l_courses_color, _l_courses_name;
                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setSelected(l),
                                                            className: "w-full text-left rounded-lg px-2 py-1.5 text-xs transition hover:opacity-80",
                                                            style: {
                                                                backgroundColor: (_l_courses_color = (_l_courses = l.courses) === null || _l_courses === void 0 ? void 0 : _l_courses.color) !== null && _l_courses_color !== void 0 ? _l_courses_color : '#374151',
                                                                color: '#fff'
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "font-semibold truncate",
                                                                    children: (_l_courses_name = (_l_courses1 = l.courses) === null || _l_courses1 === void 0 ? void 0 : _l_courses1.name) !== null && _l_courses_name !== void 0 ? _l_courses_name : (_l_lesson_types = l.lesson_types) === null || _l_lesson_types === void 0 ? void 0 : _l_lesson_types.name_en
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 247,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "opacity-80",
                                                                    children: l.start_time.slice(0, 5)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 248,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "opacity-70",
                                                                    children: [
                                                                        l.current_bookings,
                                                                        "/",
                                                                        l.max_capacity
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 249,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, l.id, true, {
                                                            fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                            lineNumber: 241,
                                                            columnNumber: 25
                                                        }, this);
                                                    })
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 238,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 232,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 220,
                                columnNumber: 13
                            }, this),
                            mode === 'month' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7 border-b border-gray-100",
                                        children: DAYS_SHORT.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-3 text-center",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-400 font-medium",
                                                    children: d
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                    lineNumber: 265,
                                                    columnNumber: 21
                                                }, this)
                                            }, d, false, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 264,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 262,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7",
                                        children: getMonthDates(anchor).map((d, i)=>{
                                            const dateStr = toISO(d);
                                            const inMonth = d.getMonth() === anchor.getMonth();
                                            const isToday = dateStr === today;
                                            const dayLessons = lessonsForDay(dateStr);
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "min-h-24 p-1.5 border-r border-b border-gray-100 last:border-r-0 ".concat(!inMonth ? 'bg-gray-50/50' : isToday ? 'bg-gray-800/5' : ''),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs font-medium mb-1 w-6 h-6 flex items-center justify-center rounded-full ".concat(isToday ? 'bg-gray-800 text-white' : inMonth ? 'text-gray-700' : 'text-gray-300'),
                                                        children: d.getDate()
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 282,
                                                        columnNumber: 23
                                                    }, this),
                                                    loading && i === 0 ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-0.5",
                                                        children: [
                                                            dayLessons.slice(0, 3).map((l)=>{
                                                                var _l_courses, _l_courses1, _l_lesson_types;
                                                                var _l_courses_color, _l_courses_name;
                                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>setSelected(l),
                                                                    className: "w-full text-left rounded px-1.5 py-0.5 text-xs truncate transition hover:opacity-80",
                                                                    style: {
                                                                        backgroundColor: (_l_courses_color = (_l_courses = l.courses) === null || _l_courses === void 0 ? void 0 : _l_courses.color) !== null && _l_courses_color !== void 0 ? _l_courses_color : '#374151',
                                                                        color: '#fff'
                                                                    },
                                                                    children: [
                                                                        l.start_time.slice(0, 5),
                                                                        " ",
                                                                        (_l_courses_name = (_l_courses1 = l.courses) === null || _l_courses1 === void 0 ? void 0 : _l_courses1.name) !== null && _l_courses_name !== void 0 ? _l_courses_name : (_l_lesson_types = l.lesson_types) === null || _l_lesson_types === void 0 ? void 0 : _l_lesson_types.name_en
                                                                    ]
                                                                }, l.id, true, {
                                                                    fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                    lineNumber: 290,
                                                                    columnNumber: 29
                                                                }, this);
                                                            }),
                                                            dayLessons.length > 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-gray-400 pl-1",
                                                                children: [
                                                                    "+",
                                                                    dayLessons.length - 3,
                                                                    " more"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                                lineNumber: 300,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 288,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 276,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 269,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 261,
                                columnNumber: 13
                            }, this),
                            mode === 'year' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-4 gap-4",
                                children: MONTHS.map((monthName, mi)=>{
                                    const year = anchor.getFullYear();
                                    const firstDay = new Date(year, mi, 1);
                                    const lastDay = new Date(year, mi + 1, 0);
                                    const startOffset = (firstDay.getDay() + 6) % 7;
                                    const totalCells = Math.ceil((startOffset + lastDay.getDate()) / 7) * 7;
                                    const cells = Array.from({
                                        length: totalCells
                                    }, (_, i)=>{
                                        const d = new Date(firstDay);
                                        d.setDate(1 - startOffset + i);
                                        return d;
                                    });
                                    const monthLessons = lessons.filter((l)=>{
                                        const lDate = new Date(l.date);
                                        return lDate.getFullYear() === year && lDate.getMonth() === mi;
                                    });
                                    const lessonDates = new Set(monthLessons.map((l)=>l.date));
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-xl border border-gray-100 p-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs font-semibold text-gray-700",
                                                        children: monthName
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 334,
                                                        columnNumber: 23
                                                    }, this),
                                                    monthLessons.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-gray-400",
                                                        children: [
                                                            monthLessons.length,
                                                            " lessons"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 336,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 333,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-7 mb-1",
                                                children: [
                                                    'M',
                                                    'T',
                                                    'W',
                                                    'T',
                                                    'F',
                                                    'S',
                                                    'S'
                                                ].map((d, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-center text-[10px] text-gray-300 font-medium",
                                                        children: d
                                                    }, i, false, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 341,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 339,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-7 gap-y-0.5",
                                                children: cells.map((d, i)=>{
                                                    const dateStr = toISO(d);
                                                    const inMonth = d.getMonth() === mi;
                                                    const isToday = dateStr === today;
                                                    const hasLesson = lessonDates.has(dateStr);
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        disabled: !inMonth || !hasLesson,
                                                        onClick: ()=>{
                                                            if (inMonth && hasLesson) {
                                                                setAnchor(d);
                                                                setMode('day');
                                                            }
                                                        },
                                                        className: "text-[10px] h-5 w-full flex items-center justify-center rounded transition ".concat(!inMonth ? 'text-gray-200' : isToday ? 'bg-gray-800 text-white font-bold' : hasLesson ? 'bg-gray-800/15 text-gray-700 font-medium hover:bg-gray-800/30 cursor-pointer' : 'text-gray-500'),
                                                        children: d.getDate()
                                                    }, i, false, {
                                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                        lineNumber: 351,
                                                        columnNumber: 27
                                                    }, this);
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 344,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, mi, true, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 332,
                                        columnNumber: 19
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 313,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this),
                    selected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-72 bg-white rounded-xl border border-gray-100 p-5 space-y-4 self-start shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-start justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-3 h-3 rounded-full mt-1 mr-2 shrink-0",
                                        style: {
                                            backgroundColor: (_selected_courses_color = (_selected_courses = selected.courses) === null || _selected_courses === void 0 ? void 0 : _selected_courses.color) !== null && _selected_courses_color !== void 0 ? _selected_courses_color : '#374151'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 383,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-semibold text-gray-900 text-sm",
                                                children: (_selected_courses_name = (_selected_courses1 = selected.courses) === null || _selected_courses1 === void 0 ? void 0 : _selected_courses1.name) !== null && _selected_courses_name !== void 0 ? _selected_courses_name : (_selected_lesson_types = selected.lesson_types) === null || _selected_lesson_types === void 0 ? void 0 : _selected_lesson_types.name_en
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 388,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-400 mt-0.5",
                                                children: (_selected_lesson_types1 = selected.lesson_types) === null || _selected_lesson_types1 === void 0 ? void 0 : _selected_lesson_types1.name_en
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                                lineNumber: 389,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 387,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setSelected(null),
                                        className: "text-gray-300 hover:text-gray-500 text-lg leading-none",
                                        children: "×"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 391,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 382,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Date",
                                        value: new Date(selected.date + 'T12:00:00').toLocaleDateString('en-GB', {
                                            weekday: 'long',
                                            day: 'numeric',
                                            month: 'long'
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 395,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Time",
                                        value: "".concat(selected.start_time.slice(0, 5), " – ").concat(selected.end_time.slice(0, 5))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 396,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "School",
                                        value: (_selected_schools_name = (_selected_schools = selected.schools) === null || _selected_schools === void 0 ? void 0 : _selected_schools.name) !== null && _selected_schools_name !== void 0 ? _selected_schools_name : '—'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 397,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Room",
                                        value: selected.school_rooms ? "".concat((_selected_school_rooms_school_locations_name = (_selected_school_rooms_school_locations = selected.school_rooms.school_locations) === null || _selected_school_rooms_school_locations === void 0 ? void 0 : _selected_school_rooms_school_locations.name) !== null && _selected_school_rooms_school_locations_name !== void 0 ? _selected_school_rooms_school_locations_name : '', " · ").concat(selected.school_rooms.name) : '—'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 398,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Bookings",
                                        value: "".concat(selected.current_bookings, " / ").concat(selected.max_capacity)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                        lineNumber: 403,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 394,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs px-2 py-1 rounded-full text-center font-medium ".concat(selected.status === 'completed' ? 'bg-blue-100 text-blue-600' : selected.current_bookings >= selected.max_capacity ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'),
                                children: selected.status === 'completed' ? 'Completed' : selected.current_bookings >= selected.max_capacity ? 'Full' : "".concat(selected.max_capacity - selected.current_bookings, " spots available")
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 406,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/teacher/attendance/".concat(selected.id),
                                className: "block w-full text-center bg-gray-800 text-white text-sm font-medium py-2.5 rounded-lg hover:bg-gray-700 transition",
                                children: t('subscribeICal')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                                lineNumber: 420,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                        lineNumber: 381,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                lineNumber: 175,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
        lineNumber: 138,
        columnNumber: 5
    }, this);
}
_s(TeacherCalendarPage, "ucYELUYAsXpE8rDXX3BizCgGTWA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = TeacherCalendarPage;
function Row(param) {
    let { label, value } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-between gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-gray-400 text-xs",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                lineNumber: 436,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-gray-800 text-xs text-right",
                children: value
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
                lineNumber: 437,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/teacher/calendar/page.tsx",
        lineNumber: 435,
        columnNumber: 5
    }, this);
}
_c1 = Row;
var _c, _c1;
__turbopack_context__.k.register(_c, "TeacherCalendarPage");
__turbopack_context__.k.register(_c1, "Row");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_teacher_calendar_page_tsx_0df30585._.js.map