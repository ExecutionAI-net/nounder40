(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7e5ab332._.js",
  "static/chunks/src_8aea8e45._.js"
],
    source: "dynamic"
});
