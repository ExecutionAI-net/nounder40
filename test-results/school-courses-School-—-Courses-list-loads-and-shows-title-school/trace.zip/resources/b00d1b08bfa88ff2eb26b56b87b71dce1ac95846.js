(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/school/courses/CoursesClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CoursesClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
// Returns the common value if all are equal, else ''
function commonValue(values) {
    if (values.length === 0) return '';
    const first = values[0];
    return values.every((v)=>v === first) ? first : '';
}
// Returns the common boolean if all are equal, else null (indeterminate)
function commonBool(values) {
    if (values.length === 0) return null;
    const first = values[0];
    return values.every((v)=>v === first) ? first : null;
}
const COLORS = [
    '#6B1F3A',
    '#1F3A6B',
    '#1F6B3A',
    '#6B5A1F',
    '#3A1F6B',
    '#1F6B5A',
    '#6B1F1F',
    '#4A4A4A'
];
function fmtDate(iso) {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    return "".concat(d, "/").concat(m, "/").concat(y);
}
function CoursesClient(param) {
    let { initialCourses, initialLessonTypes = [], initialTeachers = [] } = param;
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('school.courses.list');
    const WEEKDAY_LABELS = {
        monday: t('dayMonday'),
        tuesday: t('dayTuesday'),
        wednesday: t('dayWednesday'),
        thursday: t('dayThursday'),
        friday: t('dayFriday'),
        saturday: t('daySaturday'),
        sunday: t('daySunday')
    };
    const freqLabel = {
        single: t('freqSingle'),
        weekly: t('freqWeekly'),
        biweekly: t('freqBiweekly')
    };
    const [courses, setCourses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCourses);
    const [deletingId, setDeletingId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [bulkDeleting, setBulkDeleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showBulkConfirm, setShowBulkConfirm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filterTeacher, setFilterTeacher] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterLocation, setFilterLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterStartHour, setFilterStartHour] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Bulk edit state
    const [showBulkEdit, setShowBulkEdit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [bulkEditLoading, setBulkEditLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [bulkSaving, setBulkSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [bulkSaveError, setBulkSaveError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [bulkSaved, setBulkSaved] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Reference data (passed from server)
    const lessonTypes = initialLessonTypes;
    const teachers = initialTeachers;
    // Bulk edit form — '' means "not set / keep unchanged"
    const [bulkForm, setBulkForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        lesson_type_id: '',
        teacher_id: '',
        name: '',
        description: '',
        notes: '',
        is_online: null,
        online_link: '',
        start_time: '',
        duration_minutes: '',
        max_capacity: '',
        reserve_spots: '',
        credit_cost: '',
        color: '',
        vip_booking_hours_before: '',
        min_booking_notice_hours: '',
        waitlist_enabled: null,
        update_future_lessons: true
    });
    const uniqueTeachers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CoursesClient.useMemo[uniqueTeachers]": ()=>{
            const map = new Map();
            for (const c of courses){
                var _c_teachers;
                if ((_c_teachers = c.teachers) === null || _c_teachers === void 0 ? void 0 : _c_teachers.name) map.set(c.teachers.name, c.teachers.name);
            }
            return Array.from(map.keys());
        }
    }["CoursesClient.useMemo[uniqueTeachers]"], [
        courses
    ]);
    const uniqueLocations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CoursesClient.useMemo[uniqueLocations]": ()=>{
            const set = new Set();
            for (const c of courses){
                for (const sc of c._schedules){
                    if (sc.location_name) set.add(sc.location_name);
                }
            }
            return Array.from(set).sort();
        }
    }["CoursesClient.useMemo[uniqueLocations]"], [
        courses
    ]);
    const uniqueStartHours = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CoursesClient.useMemo[uniqueStartHours]": ()=>{
            const set = new Set();
            for (const c of courses){
                if (c.start_time) set.add(c.start_time.slice(0, 5));
            }
            return Array.from(set).sort();
        }
    }["CoursesClient.useMemo[uniqueStartHours]"], [
        courses
    ]);
    const filteredCourses = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "CoursesClient.useMemo[filteredCourses]": ()=>{
            return courses.filter({
                "CoursesClient.useMemo[filteredCourses]": (c)=>{
                    var _c_teachers, _c_start_time;
                    if (filterTeacher && ((_c_teachers = c.teachers) === null || _c_teachers === void 0 ? void 0 : _c_teachers.name) !== filterTeacher) return false;
                    if (filterLocation && !c._schedules.some({
                        "CoursesClient.useMemo[filteredCourses]": (sc)=>sc.location_name === filterLocation
                    }["CoursesClient.useMemo[filteredCourses]"])) return false;
                    if (filterStartHour && ((_c_start_time = c.start_time) === null || _c_start_time === void 0 ? void 0 : _c_start_time.slice(0, 5)) !== filterStartHour) return false;
                    return true;
                }
            }["CoursesClient.useMemo[filteredCourses]"]);
        }
    }["CoursesClient.useMemo[filteredCourses]"], [
        courses,
        filterTeacher,
        filterLocation,
        filterStartHour
    ]);
    const hasActiveFilters = filterTeacher || filterLocation || filterStartHour;
    // Open bulk edit: fetch all selected course details, compute mixed values
    async function openBulkEdit() {
        setBulkEditLoading(true);
        setBulkSaveError(null);
        setBulkSaved(false);
        setShowBulkEdit(true);
        const ids = Array.from(selected);
        const details = [];
        await Promise.all(ids.map(async (id)=>{
            const res = await fetch("/api/school/courses/".concat(id));
            if (res.ok) details.push(await res.json());
        }));
        setBulkForm({
            lesson_type_id: commonValue(details.map((d)=>{
                var _d_lesson_type_id;
                return (_d_lesson_type_id = d.lesson_type_id) !== null && _d_lesson_type_id !== void 0 ? _d_lesson_type_id : '';
            })),
            teacher_id: commonValue(details.map((d)=>{
                var _d_teacher_id;
                return (_d_teacher_id = d.teacher_id) !== null && _d_teacher_id !== void 0 ? _d_teacher_id : '';
            })),
            name: commonValue(details.map((d)=>{
                var _d_name;
                return (_d_name = d.name) !== null && _d_name !== void 0 ? _d_name : '';
            })),
            description: commonValue(details.map((d)=>{
                var _d_description;
                return (_d_description = d.description) !== null && _d_description !== void 0 ? _d_description : '';
            })),
            notes: commonValue(details.map((d)=>{
                var _d_notes;
                return (_d_notes = d.notes) !== null && _d_notes !== void 0 ? _d_notes : '';
            })),
            is_online: commonBool(details.map((d)=>{
                var _d_is_online;
                return (_d_is_online = d.is_online) !== null && _d_is_online !== void 0 ? _d_is_online : false;
            })),
            online_link: commonValue(details.map((d)=>{
                var _d_online_link;
                return (_d_online_link = d.online_link) !== null && _d_online_link !== void 0 ? _d_online_link : '';
            })),
            start_time: commonValue(details.map((d)=>{
                var _d_start_time;
                var _d_start_time_slice;
                return (_d_start_time_slice = (_d_start_time = d.start_time) === null || _d_start_time === void 0 ? void 0 : _d_start_time.slice(0, 5)) !== null && _d_start_time_slice !== void 0 ? _d_start_time_slice : '';
            })),
            duration_minutes: commonValue(details.map((d)=>{
                var _d_duration_minutes;
                return String((_d_duration_minutes = d.duration_minutes) !== null && _d_duration_minutes !== void 0 ? _d_duration_minutes : '');
            })),
            max_capacity: commonValue(details.map((d)=>{
                var _d_max_capacity;
                return String((_d_max_capacity = d.max_capacity) !== null && _d_max_capacity !== void 0 ? _d_max_capacity : '');
            })),
            reserve_spots: commonValue(details.map((d)=>{
                var _d_reserve_spots;
                return String((_d_reserve_spots = d.reserve_spots) !== null && _d_reserve_spots !== void 0 ? _d_reserve_spots : '');
            })),
            credit_cost: commonValue(details.map((d)=>{
                var _d_credit_cost;
                return String((_d_credit_cost = d.credit_cost) !== null && _d_credit_cost !== void 0 ? _d_credit_cost : '');
            })),
            color: commonValue(details.map((d)=>{
                var _d_color;
                return (_d_color = d.color) !== null && _d_color !== void 0 ? _d_color : '';
            })),
            vip_booking_hours_before: commonValue(details.map((d)=>{
                var _d_vip_booking_hours_before;
                return String((_d_vip_booking_hours_before = d.vip_booking_hours_before) !== null && _d_vip_booking_hours_before !== void 0 ? _d_vip_booking_hours_before : '');
            })),
            min_booking_notice_hours: commonValue(details.map((d)=>{
                var _d_min_booking_notice_hours;
                return String((_d_min_booking_notice_hours = d.min_booking_notice_hours) !== null && _d_min_booking_notice_hours !== void 0 ? _d_min_booking_notice_hours : '');
            })),
            waitlist_enabled: commonBool(details.map((d)=>{
                var _d_waitlist_enabled;
                return (_d_waitlist_enabled = d.waitlist_enabled) !== null && _d_waitlist_enabled !== void 0 ? _d_waitlist_enabled : false;
            })),
            update_future_lessons: true
        });
        setBulkEditLoading(false);
    }
    async function handleBulkSave() {
        setBulkSaving(true);
        setBulkSaveError(null);
        const ids = Array.from(selected);
        // Build partial payload — only include fields the user actually filled in
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const patch = {};
        if (bulkForm.lesson_type_id) patch.lesson_type_id = bulkForm.lesson_type_id;
        if (bulkForm.teacher_id !== '') patch.teacher_id = bulkForm.teacher_id === '__clear__' ? null : bulkForm.teacher_id || null;
        if (bulkForm.name) patch.name = bulkForm.name;
        if (bulkForm.description !== '') patch.description = bulkForm.description || null;
        if (bulkForm.notes !== '') patch.notes = bulkForm.notes || null;
        if (bulkForm.is_online !== null) patch.is_online = bulkForm.is_online;
        if (bulkForm.online_link !== '') patch.online_link = bulkForm.online_link || null;
        if (bulkForm.start_time) patch.start_time = bulkForm.start_time;
        if (bulkForm.duration_minutes) patch.duration_minutes = Number(bulkForm.duration_minutes);
        if (bulkForm.max_capacity) patch.max_capacity = Number(bulkForm.max_capacity);
        if (bulkForm.reserve_spots) patch.reserve_spots = Number(bulkForm.reserve_spots);
        if (bulkForm.credit_cost) patch.credit_cost = Number(bulkForm.credit_cost);
        if (bulkForm.color) patch.color = bulkForm.color;
        if (bulkForm.vip_booking_hours_before) patch.vip_booking_hours_before = Number(bulkForm.vip_booking_hours_before);
        if (bulkForm.min_booking_notice_hours) patch.min_booking_notice_hours = Number(bulkForm.min_booking_notice_hours);
        if (bulkForm.waitlist_enabled !== null) patch.waitlist_enabled = bulkForm.waitlist_enabled;
        // lesson_type_id and name are required by the API — if not set, fetch from each course
        const results = await Promise.allSettled(ids.map(async (id)=>{
            const course = courses.find((c)=>c.id === id);
            var _patch_lesson_type_id, _patch_name;
            const body = {
                ...patch,
                // Ensure required fields are present
                lesson_type_id: (_patch_lesson_type_id = patch.lesson_type_id) !== null && _patch_lesson_type_id !== void 0 ? _patch_lesson_type_id : undefined,
                name: (_patch_name = patch.name) !== null && _patch_name !== void 0 ? _patch_name : undefined,
                update_future_lessons: bulkForm.update_future_lessons
            };
            // If required fields are missing, we need to get them from the existing course data
            // We'll make a GET first if needed
            if (!body.lesson_type_id || !body.name) {
                const res = await fetch("/api/school/courses/".concat(id));
                if (!res.ok) throw new Error("Failed to fetch course ".concat(id));
                const existing = await res.json();
                var _body_lesson_type_id;
                body.lesson_type_id = (_body_lesson_type_id = body.lesson_type_id) !== null && _body_lesson_type_id !== void 0 ? _body_lesson_type_id : existing.lesson_type_id;
                var _body_name;
                body.name = (_body_name = body.name) !== null && _body_name !== void 0 ? _body_name : existing.name;
            }
            const res = await fetch("/api/school/courses/".concat(id), {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });
            if (!res.ok) {
                const data = await res.json();
                var _course_name, _data_error;
                throw new Error((_data_error = data.error) !== null && _data_error !== void 0 ? _data_error : "Failed for course ".concat((_course_name = course === null || course === void 0 ? void 0 : course.name) !== null && _course_name !== void 0 ? _course_name : id));
            }
        }));
        const failed = results.filter((r)=>r.status === 'rejected');
        if (failed.length > 0) {
            setBulkSaveError(failed.map((f)=>{
                var _f_reason;
                var _f_reason_message;
                return (_f_reason_message = (_f_reason = f.reason) === null || _f_reason === void 0 ? void 0 : _f_reason.message) !== null && _f_reason_message !== void 0 ? _f_reason_message : 'Unknown error';
            }).join(', '));
            setBulkSaving(false);
            return;
        }
        setBulkSaved(true);
        setBulkSaving(false);
        setShowBulkEdit(false);
        setSelected(new Set());
        // Refresh page to show updated data
        window.location.reload();
    }
    async function handleDelete(courseId, courseName) {
        if (!confirm('Delete "'.concat(courseName, '"?\n\nAll future classes will be cancelled and students refunded. Past classes are kept.'))) return;
        setDeletingId(courseId);
        setError(null);
        const res = await fetch("/api/school/courses/".concat(courseId), {
            method: 'DELETE'
        });
        const data = await res.json();
        if (!res.ok) {
            setError(data.error);
            setDeletingId(null);
            return;
        }
        setCourses((prev)=>prev.filter((c)=>c.id !== courseId));
        setDeletingId(null);
    }
    async function handleBulkDelete() {
        setBulkDeleting(true);
        setShowBulkConfirm(false);
        setError(null);
        for (const courseId of selected){
            await fetch("/api/school/courses/".concat(courseId), {
                method: 'DELETE'
            });
        }
        setCourses((prev)=>prev.filter((c)=>!selected.has(c.id)));
        setSelected(new Set());
        setBulkDeleting(false);
    }
    function toggleSelect(id) {
        setSelected((prev)=>{
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    }
    function toggleSelectAll() {
        if (selected.size === filteredCourses.length) {
            setSelected(new Set());
        } else {
            setSelected(new Set(filteredCourses.map((c)=>c.id)));
        }
    }
    // Close bulk edit when selection changes to 0
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CoursesClient.useEffect": ()=>{
            if (selected.size === 0) setShowBulkEdit(false);
        }
    }["CoursesClient.useEffect"], [
        selected.size
    ]);
    const inputCls = 'w-full px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20';
    const labelCls = 'block text-xs font-medium text-gray-600 mb-1';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold text-gray-900",
                                children: "Courses"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 342,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500 text-sm mt-1",
                                children: "Manage your courses and their classes."
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 343,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 341,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/school/courses/new",
                        className: "px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-medium hover:bg-gray-700 transition",
                        children: "+ New Course"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 345,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 340,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 354,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterTeacher,
                        onChange: (e)=>{
                            setFilterTeacher(e.target.value);
                            setSelected(new Set());
                        },
                        className: "px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-600 bg-white focus:outline-none focus:ring-2 focus:ring-gray-900/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All teachers"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 364,
                                columnNumber: 11
                            }, this),
                            uniqueTeachers.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: t,
                                    children: t
                                }, t, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 365,
                                    columnNumber: 36
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 359,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterLocation,
                        onChange: (e)=>{
                            setFilterLocation(e.target.value);
                            setSelected(new Set());
                        },
                        className: "px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-600 bg-white focus:outline-none focus:ring-2 focus:ring-gray-900/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All locations"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 372,
                                columnNumber: 11
                            }, this),
                            uniqueLocations.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: l,
                                    children: l
                                }, l, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 373,
                                    columnNumber: 37
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 367,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterStartHour,
                        onChange: (e)=>{
                            setFilterStartHour(e.target.value);
                            setSelected(new Set());
                        },
                        className: "px-3 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-600 bg-white focus:outline-none focus:ring-2 focus:ring-gray-900/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All times"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 380,
                                columnNumber: 11
                            }, this),
                            uniqueStartHours.map((h)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: h,
                                    children: h
                                }, h, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 381,
                                    columnNumber: 38
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 375,
                        columnNumber: 9
                    }, this),
                    hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setFilterTeacher('');
                            setFilterLocation('');
                            setFilterStartHour('');
                            setSelected(new Set());
                        },
                        className: "px-2 py-1.5 text-xs text-gray-400 hover:text-gray-600 transition",
                        children: "Clear"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 384,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 358,
                columnNumber: 7
            }, this),
            selected.size > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-sm text-gray-700 font-medium",
                        children: [
                            selected.size,
                            " course",
                            selected.size > 1 ? 's' : '',
                            " selected"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 396,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: openBulkEdit,
                        className: "px-4 py-1.5 bg-[#6B1F3A] text-white rounded-lg text-sm font-medium hover:bg-[#5a1930] transition",
                        children: "Edit Selected"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 397,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setShowBulkConfirm(true),
                        disabled: bulkDeleting,
                        className: "px-4 py-1.5 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600 transition disabled:opacity-50",
                        children: bulkDeleting ? 'Deleting...' : 'Delete Selected'
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 403,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSelected(new Set()),
                        className: "text-sm text-gray-400 hover:text-gray-600",
                        children: "Clear selection"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 410,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 395,
                columnNumber: 9
            }, this),
            showBulkEdit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-[#6B1F3A]/20 p-5 space-y-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-start justify-between gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-semibold text-gray-900 text-sm",
                                        children: [
                                            "Edit ",
                                            selected.size,
                                            " Course",
                                            selected.size > 1 ? 's' : ''
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 422,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-500 mt-1",
                                        children: "Only the fields you fill in will be updated. Fields left blank will not be changed. If selected courses have different values for a field, that field appears empty."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 423,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 421,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setShowBulkEdit(false),
                                className: "text-gray-400 hover:text-gray-600 text-lg leading-none shrink-0",
                                children: "×"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 428,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 420,
                        columnNumber: 11
                    }, this),
                    bulkEditLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm text-gray-400 py-4 text-center",
                        children: "Loading course details..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 432,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-4 py-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-700",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: [
                                            selected.size,
                                            " courses selected."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 437,
                                        columnNumber: 17
                                    }, this),
                                    " Fields you fill in will overwrite the same field in all selected courses. Fields left blank will not be changed."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 436,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Lesson Type"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 443,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                value: bulkForm.lesson_type_id,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            lesson_type_id: e.target.value
                                                        })),
                                                className: inputCls,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        children: "— unchanged —"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                        lineNumber: 445,
                                                        columnNumber: 21
                                                    }, this),
                                                    lessonTypes.map((lt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: lt.id,
                                                            children: lt.name_it || lt.name_en
                                                        }, lt.id, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                            lineNumber: 446,
                                                            columnNumber: 44
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 444,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 442,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Default Teacher"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 452,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                value: bulkForm.teacher_id,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            teacher_id: e.target.value
                                                        })),
                                                className: inputCls,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        children: "— unchanged —"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                        lineNumber: 454,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "__clear__",
                                                        children: "No teacher"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                        lineNumber: 455,
                                                        columnNumber: 21
                                                    }, this),
                                                    teachers.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: t.id,
                                                            children: t.name
                                                        }, t.id, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                            lineNumber: 456,
                                                            columnNumber: 40
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 453,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 451,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Start Time"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 462,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "time",
                                                value: bulkForm.start_time,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            start_time: e.target.value
                                                        })),
                                                className: inputCls
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 463,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 461,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Duration (min)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 468,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: "15",
                                                step: "15",
                                                value: bulkForm.duration_minutes,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            duration_minutes: e.target.value
                                                        })),
                                                placeholder: "— unchanged —",
                                                className: inputCls
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 469,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 467,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Max Capacity"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 474,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: "1",
                                                value: bulkForm.max_capacity,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            max_capacity: e.target.value
                                                        })),
                                                placeholder: "— unchanged —",
                                                className: inputCls
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 475,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 473,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Reserve Spots"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 480,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: "0",
                                                value: bulkForm.reserve_spots,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            reserve_spots: e.target.value
                                                        })),
                                                placeholder: "— unchanged —",
                                                className: inputCls
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 481,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 479,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Credit Cost"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 486,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: "1",
                                                value: bulkForm.credit_cost,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            credit_cost: e.target.value
                                                        })),
                                                placeholder: "— unchanged —",
                                                className: inputCls
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 487,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 485,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "VIP Booking Hours Before"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 492,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: "0",
                                                value: bulkForm.vip_booking_hours_before,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            vip_booking_hours_before: e.target.value
                                                        })),
                                                placeholder: "— unchanged —",
                                                className: inputCls
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 493,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 491,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: labelCls,
                                                children: "Min Booking Notice (hours)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 498,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "number",
                                                min: "0",
                                                value: bulkForm.min_booking_notice_hours,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            min_booking_notice_hours: e.target.value
                                                        })),
                                                placeholder: "— unchanged —",
                                                className: inputCls
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 499,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 497,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 440,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: "Calendar Color"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 505,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2 mt-1 flex-wrap items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setBulkForm((f)=>({
                                                            ...f,
                                                            color: ''
                                                        })),
                                                className: "px-3 py-1 rounded-full text-xs border transition ".concat(!bulkForm.color ? 'border-gray-900 bg-gray-100 font-medium' : 'border-gray-200 text-gray-400'),
                                                children: "unchanged"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 507,
                                                columnNumber: 19
                                            }, this),
                                            COLORS.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>setBulkForm((f)=>({
                                                                ...f,
                                                                color: c
                                                            })),
                                                    className: "w-8 h-8 rounded-full border-2 transition",
                                                    style: {
                                                        backgroundColor: c,
                                                        borderColor: bulkForm.color === c ? '#1f2937' : 'transparent'
                                                    }
                                                }, c, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                    lineNumber: 515,
                                                    columnNumber: 21
                                                }, this)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "w-8 h-8 rounded-full border-2 border-dashed border-gray-300 cursor-pointer overflow-hidden relative flex items-center justify-center hover:border-gray-400 transition",
                                                title: "Custom color",
                                                style: bulkForm.color && !COLORS.includes(bulkForm.color) ? {
                                                    borderColor: '#1f2937',
                                                    borderStyle: 'solid',
                                                    backgroundColor: bulkForm.color
                                                } : {},
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "color",
                                                        value: bulkForm.color || '#6B1F3A',
                                                        onChange: (e)=>setBulkForm((f)=>({
                                                                    ...f,
                                                                    color: e.target.value
                                                                })),
                                                        className: "absolute opacity-0 w-full h-full cursor-pointer"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                        lineNumber: 526,
                                                        columnNumber: 21
                                                    }, this),
                                                    (!bulkForm.color || COLORS.includes(bulkForm.color)) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-400 text-xs leading-none select-none",
                                                        children: "+"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                        lineNumber: 528,
                                                        columnNumber: 78
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 521,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 506,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 504,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: "Course Name"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 535,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        value: bulkForm.name,
                                        onChange: (e)=>setBulkForm((f)=>({
                                                    ...f,
                                                    name: e.target.value
                                                })),
                                        placeholder: "— unchanged —",
                                        className: inputCls
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 536,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 534,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: "Description"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 541,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                        value: bulkForm.description,
                                        onChange: (e)=>setBulkForm((f)=>({
                                                    ...f,
                                                    description: e.target.value
                                                })),
                                        rows: 2,
                                        placeholder: "— unchanged —",
                                        className: "".concat(inputCls, " resize-none")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 542,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 540,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: "Notes"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 547,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                        value: bulkForm.notes,
                                        onChange: (e)=>setBulkForm((f)=>({
                                                    ...f,
                                                    notes: e.target.value
                                                })),
                                        rows: 2,
                                        placeholder: "— unchanged —",
                                        className: "".concat(inputCls, " resize-none")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 548,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 546,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: "Online / In-Person"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 553,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setBulkForm((f)=>({
                                                            ...f,
                                                            is_online: null
                                                        })),
                                                className: "px-3 py-1.5 rounded-lg text-xs border transition ".concat(bulkForm.is_online === null ? 'bg-gray-200 font-medium border-gray-400' : 'border-gray-200 text-gray-400'),
                                                children: "Unchanged"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 555,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setBulkForm((f)=>({
                                                            ...f,
                                                            is_online: false
                                                        })),
                                                className: "px-3 py-1.5 rounded-lg text-xs border transition ".concat(bulkForm.is_online === false ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-600'),
                                                children: "📍 In-Person"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 562,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setBulkForm((f)=>({
                                                            ...f,
                                                            is_online: true
                                                        })),
                                                className: "px-3 py-1.5 rounded-lg text-xs border transition ".concat(bulkForm.is_online === true ? 'bg-[#6B1F3A] text-white border-[#6B1F3A]' : 'border-gray-200 text-gray-600'),
                                                children: "🌐 Online"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 569,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 554,
                                        columnNumber: 17
                                    }, this),
                                    bulkForm.is_online === true && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "url",
                                        value: bulkForm.online_link,
                                        onChange: (e)=>setBulkForm((f)=>({
                                                    ...f,
                                                    online_link: e.target.value
                                                })),
                                        placeholder: "https://zoom.us/j/...",
                                        className: "".concat(inputCls, " mt-2")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 578,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 552,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: "Waitlist"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 584,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setBulkForm((f)=>({
                                                            ...f,
                                                            waitlist_enabled: null
                                                        })),
                                                className: "px-3 py-1.5 rounded-lg text-xs border transition ".concat(bulkForm.waitlist_enabled === null ? 'bg-gray-200 font-medium border-gray-400' : 'border-gray-200 text-gray-400'),
                                                children: "Unchanged"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 586,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setBulkForm((f)=>({
                                                            ...f,
                                                            waitlist_enabled: false
                                                        })),
                                                className: "px-3 py-1.5 rounded-lg text-xs border transition ".concat(bulkForm.waitlist_enabled === false ? 'bg-gray-900 text-white border-gray-900' : 'border-gray-200 text-gray-600'),
                                                children: "Disabled"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 590,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setBulkForm((f)=>({
                                                            ...f,
                                                            waitlist_enabled: true
                                                        })),
                                                className: "px-3 py-1.5 rounded-lg text-xs border transition ".concat(bulkForm.waitlist_enabled === true ? 'bg-[#6B1F3A] text-white border-[#6B1F3A]' : 'border-gray-200 text-gray-600'),
                                                children: "Enabled"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 594,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 585,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 583,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex items-center gap-3 cursor-pointer",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative shrink-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                className: "sr-only",
                                                checked: bulkForm.update_future_lessons,
                                                onChange: (e)=>setBulkForm((f)=>({
                                                            ...f,
                                                            update_future_lessons: e.target.checked
                                                        }))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 604,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-10 h-6 rounded-full transition ".concat(bulkForm.update_future_lessons ? 'bg-[#6B1F3A]' : 'bg-gray-200')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 605,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ".concat(bulkForm.update_future_lessons ? 'left-5' : 'left-1')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 606,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 603,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm font-medium text-gray-700",
                                                children: "Apply changes to future classes too"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 609,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-400",
                                                children: "When on, upcoming class instances will also be updated."
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                lineNumber: 610,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 608,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 602,
                                columnNumber: 15
                            }, this),
                            bulkSaveError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600",
                                children: bulkSaveError
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 615,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 pt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleBulkSave,
                                        disabled: bulkSaving,
                                        className: "px-5 py-2.5 bg-[#6B1F3A] text-white rounded-lg text-sm font-medium hover:bg-[#5a1930] transition disabled:opacity-50",
                                        children: bulkSaving ? 'Saving...' : "Save Changes to ".concat(selected.size, " Course").concat(selected.size > 1 ? 's' : '')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 619,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setShowBulkEdit(false),
                                        className: "px-5 py-2.5 border border-gray-200 text-gray-600 rounded-lg text-sm hover:bg-gray-50 transition",
                                        children: "Cancel"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                        lineNumber: 626,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 618,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 434,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 418,
                columnNumber: 9
            }, this),
            bulkSaved && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700",
                children: "Changes saved successfully to all selected courses."
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 636,
                columnNumber: 9
            }, this),
            filteredCourses.length === 0 && courses.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 p-6 text-sm text-gray-400",
                children: "No courses match the selected filters."
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 642,
                columnNumber: 9
            }, this) : courses.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 p-8 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-400 text-sm",
                        children: "No courses yet."
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 647,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/school/courses/new",
                        className: "mt-3 inline-block text-sm text-gray-900 font-medium underline",
                        children: "Create your first course"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 648,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 646,
                columnNumber: 9
            }, this) : filteredCourses.length === 0 ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 divide-y divide-gray-50",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-5 py-2.5 flex items-center gap-3 bg-gray-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "checkbox",
                                checked: selected.size === filteredCourses.length && filteredCourses.length > 0,
                                onChange: toggleSelectAll,
                                className: "w-4 h-4 rounded border-gray-300 cursor-pointer"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 655,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs text-gray-500",
                                children: selected.size > 0 ? "".concat(selected.size, " selected") : 'Select all'
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                lineNumber: 661,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                        lineNumber: 654,
                        columnNumber: 11
                    }, this),
                    filteredCourses.map((course)=>{
                        var _course_lesson_types, _course_lesson_types1, _course_teachers;
                        const totalClasses = course._schedules.reduce((s, sc)=>s + sc.class_count, 0);
                        var _freqLabel_course_frequency;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-5 py-4 flex items-start gap-4 ".concat(selected.has(course.id) ? 'bg-[#6B1F3A]/5' : ''),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    checked: selected.has(course.id),
                                    onChange: ()=>toggleSelect(course.id),
                                    className: "w-4 h-4 rounded border-gray-300 cursor-pointer shrink-0 mt-1"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 670,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-3 h-3 rounded-full shrink-0 mt-1",
                                    style: {
                                        backgroundColor: course.color
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 676,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 min-w-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 flex-wrap",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-sm font-semibold text-gray-900",
                                                    children: course.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                    lineNumber: 680,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded shrink-0",
                                                    children: ((_course_lesson_types = course.lesson_types) === null || _course_lesson_types === void 0 ? void 0 : _course_lesson_types.name_it) || ((_course_lesson_types1 = course.lesson_types) === null || _course_lesson_types1 === void 0 ? void 0 : _course_lesson_types1.name_en) || '—'
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                    lineNumber: 681,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-400 shrink-0",
                                                    children: (_freqLabel_course_frequency = freqLabel[course.frequency]) !== null && _freqLabel_course_frequency !== void 0 ? _freqLabel_course_frequency : course.frequency
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                    lineNumber: 684,
                                                    columnNumber: 21
                                                }, this),
                                                ((_course_teachers = course.teachers) === null || _course_teachers === void 0 ? void 0 : _course_teachers.name) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-400 shrink-0",
                                                    children: [
                                                        "· ",
                                                        course.teachers.name
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                    lineNumber: 688,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs font-medium text-gray-500 shrink-0",
                                                    children: [
                                                        "· ",
                                                        totalClasses,
                                                        " upcoming ",
                                                        totalClasses === 1 ? 'class' : 'classes'
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                    lineNumber: 690,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                            lineNumber: 679,
                                            columnNumber: 19
                                        }, this),
                                        course._schedules.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-2 space-y-1",
                                            children: course._schedules.map((sc, i)=>{
                                                var _WEEKDAY_LABELS_sc_weekday;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 flex-wrap",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "inline-flex items-center gap-1.5 text-xs bg-gray-50 border border-gray-100 rounded-lg px-2.5 py-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium text-gray-700",
                                                                children: (_WEEKDAY_LABELS_sc_weekday = WEEKDAY_LABELS[sc.weekday]) !== null && _WEEKDAY_LABELS_sc_weekday !== void 0 ? _WEEKDAY_LABELS_sc_weekday : sc.weekday
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 700,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-300",
                                                                children: "·"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 701,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-500",
                                                                children: sc.start_time
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 702,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-300",
                                                                children: "·"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 703,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-500",
                                                                children: [
                                                                    sc.duration_minutes,
                                                                    "min"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 704,
                                                                columnNumber: 29
                                                            }, this),
                                                            sc.location_name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-gray-300",
                                                                        children: "·"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                        lineNumber: 707,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-gray-500",
                                                                        children: sc.location_name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                        lineNumber: 708,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                ]
                                                            }, void 0, true),
                                                            sc.teacher_name && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-gray-300",
                                                                        children: "·"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                        lineNumber: 713,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-gray-500",
                                                                        children: sc.teacher_name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                        lineNumber: 714,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                ]
                                                            }, void 0, true),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-300",
                                                                children: "·"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 717,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-500",
                                                                children: [
                                                                    fmtDate(sc.first_date),
                                                                    " → ",
                                                                    fmtDate(sc.last_date)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 718,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-300",
                                                                children: "·"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 719,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium text-gray-600",
                                                                children: [
                                                                    sc.class_count,
                                                                    " ",
                                                                    sc.class_count === 1 ? 'class' : 'classes'
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                                lineNumber: 720,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                        lineNumber: 699,
                                                        columnNumber: 27
                                                    }, this)
                                                }, i, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                                    lineNumber: 698,
                                                    columnNumber: 25
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                            lineNumber: 696,
                                            columnNumber: 21
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-300 mt-1",
                                            children: "No upcoming classes"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                            lineNumber: 726,
                                            columnNumber: 21
                                        }, this),
                                        course.notes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-500 mt-1.5",
                                            children: course.notes
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                            lineNumber: 729,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 678,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 shrink-0 mt-0.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/school/courses/".concat(course.id),
                                            className: "text-xs px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 transition",
                                            children: "View Classes"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                            lineNumber: 734,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/school/courses/".concat(course.id, "/edit"),
                                            className: "text-xs px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 transition",
                                            children: "Edit"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                            lineNumber: 740,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleDelete(course.id, course.name),
                                            disabled: deletingId === course.id,
                                            className: "text-xs px-3 py-1.5 rounded-lg border border-red-100 text-red-400 hover:bg-red-50 transition disabled:opacity-50",
                                            children: deletingId === course.id ? 'Deleting...' : 'Delete'
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                            lineNumber: 746,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 733,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, course.id, true, {
                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                            lineNumber: 669,
                            columnNumber: 15
                        }, this);
                    })
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 653,
                columnNumber: 9
            }, this),
            showBulkConfirm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-2xl shadow-xl p-6 max-w-sm w-full mx-4 space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "font-semibold text-gray-900 text-base",
                            children: [
                                "Delete ",
                                selected.size,
                                " course",
                                selected.size > 1 ? 's' : '',
                                "?"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                            lineNumber: 763,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-500",
                            children: "All future classes will be cancelled and booked students refunded. Past classes are kept. This cannot be undone."
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                            lineNumber: 766,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2 pt-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleBulkDelete,
                                    className: "flex-1 px-4 py-2.5 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600 transition",
                                    children: "Yes, delete all"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 770,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setShowBulkConfirm(false),
                                    className: "flex-1 px-4 py-2.5 border border-gray-200 text-gray-600 rounded-lg text-sm hover:bg-gray-50 transition",
                                    children: "Go back"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                                    lineNumber: 776,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                            lineNumber: 769,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                    lineNumber: 762,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
                lineNumber: 761,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/courses/CoursesClient.tsx",
        lineNumber: 339,
        columnNumber: 5
    }, this);
}
_s(CoursesClient, "vX9u2X9DFRN6UOioBFEcMFTGepY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = CoursesClient;
var _c;
__turbopack_context__.k.register(_c, "CoursesClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_school_courses_CoursesClient_tsx_bf1eb6b9._.js.map