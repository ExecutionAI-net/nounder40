(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/school/locations/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LocationsPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function Tooltip(param) {
    let { text, children } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative group/tip",
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "pointer-events-none absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover/tip:block z-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-gray-800 text-white text-xs rounded-md px-2 py-1 whitespace-nowrap shadow-lg",
                    children: [
                        text,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-gray-800"
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                            lineNumber: 14,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Tooltip;
function LocationsPage() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('school.locations');
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const [schoolId, setSchoolId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [locations, setLocations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [showAddLocation, setShowAddLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newLocation, setNewLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        address: '',
        google_maps_url: ''
    });
    const [addingLocation, setAddingLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newRoom, setNewRoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [addingRoom, setAddingRoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Edit location state
    const [editingLocationId, setEditingLocationId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editLocationForm, setEditLocationForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        address: '',
        google_maps_url: ''
    });
    const [savingLocation, setSavingLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Edit room state
    const [editingRoomId, setEditingRoomId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editRoomForm, setEditRoomForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        capacity: '',
        cost: ''
    });
    const [savingRoom, setSavingRoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LocationsPage.useEffect": ()=>{
            async function load() {
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) return;
                const { data: profile } = await supabase.from('profiles').select('school_id').eq('id', user.id).single();
                if (!(profile === null || profile === void 0 ? void 0 : profile.school_id)) return;
                setSchoolId(profile.school_id);
                await fetchLocations(profile.school_id);
                setLoading(false);
            }
            load();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["LocationsPage.useEffect"], []);
    async function fetchLocations(sid) {
        const { data } = await supabase.from('school_locations').select('id, name, address, google_maps_url').eq('school_id', sid).order('created_at');
        if (!data) return;
        const withRooms = await Promise.all(data.map(async (loc)=>{
            const { data: rooms } = await supabase.from('school_rooms').select('id, name, capacity, cost').eq('location_id', loc.id);
            return {
                ...loc,
                rooms: rooms !== null && rooms !== void 0 ? rooms : []
            };
        }));
        setLocations(withRooms);
    }
    async function addLocation() {
        if (!schoolId || !newLocation.name) return;
        setAddingLocation(true);
        const { error } = await supabase.from('school_locations').insert({
            school_id: schoolId,
            ...newLocation
        });
        if (!error) {
            await fetchLocations(schoolId);
            setNewLocation({
                name: '',
                address: '',
                google_maps_url: ''
            });
            setShowAddLocation(false);
        }
        setAddingLocation(false);
    }
    async function deleteLocation(id) {
        if (!schoolId) return;
        await supabase.from('school_locations').delete().eq('id', id);
        await fetchLocations(schoolId);
    }
    function startEditLocation(loc) {
        setEditingLocationId(loc.id);
        var _loc_address, _loc_google_maps_url;
        setEditLocationForm({
            name: loc.name,
            address: (_loc_address = loc.address) !== null && _loc_address !== void 0 ? _loc_address : '',
            google_maps_url: (_loc_google_maps_url = loc.google_maps_url) !== null && _loc_google_maps_url !== void 0 ? _loc_google_maps_url : ''
        });
    }
    async function saveLocation(id) {
        if (!schoolId || !editLocationForm.name) return;
        setSavingLocation(true);
        await supabase.from('school_locations').update({
            name: editLocationForm.name,
            address: editLocationForm.address || null,
            google_maps_url: editLocationForm.google_maps_url || null
        }).eq('id', id);
        await fetchLocations(schoolId);
        setEditingLocationId(null);
        setSavingLocation(false);
    }
    async function addRoom(locationId) {
        const room = newRoom[locationId];
        if (!(room === null || room === void 0 ? void 0 : room.name)) return;
        setAddingRoom(locationId);
        const { error } = await supabase.from('school_rooms').insert({
            location_id: locationId,
            name: room.name,
            capacity: Number(room.capacity) || 20,
            cost: Number(room.cost) || 0
        });
        if (!error && schoolId) {
            await fetchLocations(schoolId);
            setNewRoom((r)=>({
                    ...r,
                    [locationId]: {
                        name: '',
                        capacity: '20',
                        cost: '0'
                    }
                }));
        }
        setAddingRoom(null);
    }
    async function deleteRoom(id) {
        if (!schoolId) return;
        await supabase.from('school_rooms').delete().eq('id', id);
        await fetchLocations(schoolId);
    }
    function startEditRoom(room) {
        setEditingRoomId(room.id);
        var _room_cost;
        setEditRoomForm({
            name: room.name,
            capacity: String(room.capacity),
            cost: String((_room_cost = room.cost) !== null && _room_cost !== void 0 ? _room_cost : 0)
        });
    }
    async function saveRoom(id) {
        if (!schoolId || !editRoomForm.name) return;
        setSavingRoom(true);
        await supabase.from('school_rooms').update({
            name: editRoomForm.name,
            capacity: Number(editRoomForm.capacity) || 20,
            cost: Number(editRoomForm.cost) || 0
        }).eq('id', id);
        await fetchLocations(schoolId);
        setEditingRoomId(null);
        setSavingRoom(false);
    }
    const inputCls = 'w-full px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20';
    if (loading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-sm text-gray-400",
        children: t('loading')
    }, void 0, false, {
        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
        lineNumber: 154,
        columnNumber: 23
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-2xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold text-gray-900",
                                children: t('title')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                lineNumber: 160,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500 text-sm mt-1",
                                children: t('subtitle')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                lineNumber: 161,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 159,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setShowAddLocation(true),
                        className: "bg-[#6B1F3A] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#5a1930] transition",
                        children: t('addLocation')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                lineNumber: 158,
                columnNumber: 7
            }, this),
            showAddLocation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 p-4 mb-4 space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "font-medium text-gray-900 text-sm",
                        children: t('newLocation')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 173,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        placeholder: t('locationNamePlaceholder'),
                        value: newLocation.name,
                        onChange: (e)=>setNewLocation((l)=>({
                                    ...l,
                                    name: e.target.value
                                })),
                        className: inputCls
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 174,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        placeholder: t('addressPlaceholder'),
                        value: newLocation.address,
                        onChange: (e)=>setNewLocation((l)=>({
                                    ...l,
                                    address: e.target.value
                                })),
                        className: inputCls
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 177,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        placeholder: t('googleMapsPlaceholder'),
                        value: newLocation.google_maps_url,
                        onChange: (e)=>setNewLocation((l)=>({
                                    ...l,
                                    google_maps_url: e.target.value
                                })),
                        className: inputCls
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 180,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: addLocation,
                                disabled: addingLocation || !newLocation.name,
                                className: "px-4 py-2 bg-[#6B1F3A] text-white rounded-lg text-sm disabled:opacity-50",
                                children: addingLocation ? t('adding') : t('add')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                lineNumber: 184,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setShowAddLocation(false),
                                className: "px-4 py-2 border border-gray-200 rounded-lg text-sm text-gray-600",
                                children: t('cancel')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                lineNumber: 188,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 183,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                lineNumber: 172,
                columnNumber: 9
            }, this),
            !locations.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 p-8 text-center text-sm text-gray-400",
                children: t('noLocations')
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                lineNumber: 197,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: locations.map((loc)=>{
                    var _newRoom_loc_id, _newRoom_loc_id1, _newRoom_loc_id2, _newRoom_loc_id3;
                    var _newRoom_loc_id_name, _newRoom_loc_id_capacity, _newRoom_loc_id_cost;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                        children: [
                            editingLocationId === loc.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-5 py-4 border-b border-gray-50 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: editLocationForm.name,
                                        onChange: (e)=>setEditLocationForm((f)=>({
                                                    ...f,
                                                    name: e.target.value
                                                })),
                                        placeholder: t('locationNamePlaceholder'),
                                        className: inputCls
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 208,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: editLocationForm.address,
                                        onChange: (e)=>setEditLocationForm((f)=>({
                                                    ...f,
                                                    address: e.target.value
                                                })),
                                        placeholder: "Address",
                                        className: inputCls
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 212,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: editLocationForm.google_maps_url,
                                        onChange: (e)=>setEditLocationForm((f)=>({
                                                    ...f,
                                                    google_maps_url: e.target.value
                                                })),
                                        placeholder: "Google Maps URL",
                                        className: inputCls
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 216,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2 pt-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>saveLocation(loc.id),
                                                disabled: savingLocation || !editLocationForm.name,
                                                className: "px-4 py-1.5 bg-[#6B1F3A] text-white rounded-lg text-sm disabled:opacity-50",
                                                children: savingLocation ? t('saving') : t('save')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 221,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setEditingLocationId(null),
                                                className: "px-4 py-1.5 border border-gray-200 rounded-lg text-sm text-gray-600",
                                                children: t('cancel')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 225,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 220,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                lineNumber: 207,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-5 py-4 flex items-center justify-between border-b border-gray-50",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-medium text-gray-900",
                                                children: loc.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 234,
                                                columnNumber: 21
                                            }, this),
                                            loc.address && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-400 mt-0.5",
                                                children: loc.address
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 235,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 233,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>startEditLocation(loc),
                                                className: "text-xs text-gray-400 hover:text-gray-700 px-2 py-1 rounded hover:bg-gray-50",
                                                children: t('edit')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 238,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>deleteLocation(loc.id),
                                                className: "text-xs text-red-400 hover:text-red-600",
                                                children: t('delete')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 242,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 237,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                lineNumber: 232,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-400 uppercase tracking-wide mb-2",
                                        children: t('rooms')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 252,
                                        columnNumber: 17
                                    }, this),
                                    loc.rooms.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1.5 mb-3",
                                        children: loc.rooms.map((room)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: editingRoomId === room.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2 items-center bg-gray-50 rounded-lg px-3 py-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            value: editRoomForm.name,
                                                            onChange: (e)=>setEditRoomForm((f)=>({
                                                                        ...f,
                                                                        name: e.target.value
                                                                    })),
                                                            placeholder: "Room name",
                                                            className: "flex-1 px-2 py-1 rounded border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 259,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tooltip, {
                                                            text: t('capacityTooltip'),
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                value: editRoomForm.capacity,
                                                                type: "number",
                                                                onChange: (e)=>setEditRoomForm((f)=>({
                                                                            ...f,
                                                                            capacity: e.target.value
                                                                        })),
                                                                className: "w-16 px-2 py-1 rounded border border-gray-200 text-sm focus:outline-none"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                lineNumber: 264,
                                                                columnNumber: 31
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 263,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tooltip, {
                                                            text: t('costTooltip'),
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "relative",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 text-sm",
                                                                        children: "€"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                        lineNumber: 270,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        value: editRoomForm.cost,
                                                                        type: "number",
                                                                        min: "0",
                                                                        step: "0.01",
                                                                        onChange: (e)=>setEditRoomForm((f)=>({
                                                                                    ...f,
                                                                                    cost: e.target.value
                                                                                })),
                                                                        className: "w-20 pl-5 pr-2 py-1 rounded border border-gray-200 text-sm focus:outline-none"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                        lineNumber: 271,
                                                                        columnNumber: 33
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                lineNumber: 269,
                                                                columnNumber: 31
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 268,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>saveRoom(room.id),
                                                            disabled: savingRoom,
                                                            className: "px-2 py-1 bg-[#6B1F3A] text-white rounded text-xs disabled:opacity-50",
                                                            children: savingRoom ? '...' : t('save')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 276,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setEditingRoomId(null),
                                                            className: "px-2 py-1 text-gray-400 rounded text-xs hover:bg-gray-100",
                                                            children: t('cancel')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 280,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                    lineNumber: 258,
                                                    columnNumber: 27
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-sm text-gray-700",
                                                            children: room.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 287,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-xs text-gray-400",
                                                                    children: [
                                                                        room.capacity,
                                                                        " ",
                                                                        t('cap')
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                    lineNumber: 289,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-xs text-gray-400",
                                                                    children: [
                                                                        "€",
                                                                        Number(room.cost).toFixed(2)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                    lineNumber: 290,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>startEditRoom(room),
                                                                    className: "text-xs text-gray-400 hover:text-gray-700",
                                                                    children: t('edit')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                    lineNumber: 291,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>deleteRoom(room.id),
                                                                    className: "text-xs text-red-400 hover:text-red-600",
                                                                    children: "×"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                                    lineNumber: 295,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 288,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                    lineNumber: 286,
                                                    columnNumber: 27
                                                }, this)
                                            }, room.id, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 256,
                                                columnNumber: 23
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 254,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                placeholder: "Room name",
                                                value: (_newRoom_loc_id_name = (_newRoom_loc_id = newRoom[loc.id]) === null || _newRoom_loc_id === void 0 ? void 0 : _newRoom_loc_id.name) !== null && _newRoom_loc_id_name !== void 0 ? _newRoom_loc_id_name : '',
                                                onChange: (e)=>setNewRoom((r)=>({
                                                            ...r,
                                                            [loc.id]: {
                                                                ...r[loc.id],
                                                                name: e.target.value
                                                            }
                                                        })),
                                                className: "flex-1 px-3 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 308,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tooltip, {
                                                text: t('capacityTooltip'),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    placeholder: t('capPlaceholder'),
                                                    type: "number",
                                                    value: (_newRoom_loc_id_capacity = (_newRoom_loc_id1 = newRoom[loc.id]) === null || _newRoom_loc_id1 === void 0 ? void 0 : _newRoom_loc_id1.capacity) !== null && _newRoom_loc_id_capacity !== void 0 ? _newRoom_loc_id_capacity : '20',
                                                    onChange: (e)=>setNewRoom((r)=>({
                                                                ...r,
                                                                [loc.id]: {
                                                                    ...r[loc.id],
                                                                    capacity: e.target.value
                                                                }
                                                            })),
                                                    className: "w-16 px-3 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                    lineNumber: 313,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 312,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tooltip, {
                                                text: t('costTooltip'),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm",
                                                            children: "€"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 320,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            placeholder: t('costPlaceholder'),
                                                            type: "number",
                                                            min: "0",
                                                            step: "0.01",
                                                            value: (_newRoom_loc_id_cost = (_newRoom_loc_id2 = newRoom[loc.id]) === null || _newRoom_loc_id2 === void 0 ? void 0 : _newRoom_loc_id2.cost) !== null && _newRoom_loc_id_cost !== void 0 ? _newRoom_loc_id_cost : '0',
                                                            onChange: (e)=>setNewRoom((r)=>({
                                                                        ...r,
                                                                        [loc.id]: {
                                                                            ...r[loc.id],
                                                                            cost: e.target.value
                                                                        }
                                                                    })),
                                                            className: "w-24 pl-6 pr-2 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                            lineNumber: 321,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                    lineNumber: 319,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 318,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>addRoom(loc.id),
                                                disabled: addingRoom === loc.id || !((_newRoom_loc_id3 = newRoom[loc.id]) === null || _newRoom_loc_id3 === void 0 ? void 0 : _newRoom_loc_id3.name),
                                                className: "px-3 py-1.5 bg-gray-900 text-white rounded-lg text-sm disabled:opacity-50",
                                                children: t('addRoom')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                                lineNumber: 327,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                        lineNumber: 307,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                                lineNumber: 251,
                                columnNumber: 15
                            }, this)
                        ]
                    }, loc.id, true, {
                        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                        lineNumber: 203,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
                lineNumber: 201,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/locations/page.tsx",
        lineNumber: 157,
        columnNumber: 5
    }, this);
}
_s(LocationsPage, "oH7IzFacPNwXo5+G5mnQZozgDAg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c1 = LocationsPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "Tooltip");
__turbopack_context__.k.register(_c1, "LocationsPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_school_locations_page_tsx_decc9b0d._.js.map