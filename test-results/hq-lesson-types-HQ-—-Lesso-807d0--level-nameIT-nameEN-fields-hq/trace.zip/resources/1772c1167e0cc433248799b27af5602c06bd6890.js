(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_[locale]_hq_lesson-types_page_tsx_73a93e6d._.js"
],
    source: "dynamic"
});
