(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/school/courses/new/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NewCoursePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const LANGUAGES = [
    {
        value: 'it',
        label: 'Italiano'
    },
    {
        value: 'en',
        label: 'English'
    },
    {
        value: 'es',
        label: 'Español'
    }
];
const COLORS = [
    '#6B1F3A',
    '#1F3A6B',
    '#1F6B3A',
    '#6B5A1F',
    '#3A1F6B',
    '#1F6B5A',
    '#6B1F1F',
    '#4A4A4A'
];
const DEFAULT_SCHEDULE = {
    start_date: '',
    start_time: '',
    duration_minutes: '60',
    end_date: '',
    frequency: 'weekly',
    weekday: '',
    room_id: '',
    teacher_id: '',
    max_capacity: '15',
    credit_cost: '1',
    color: '#6B1F3A',
    vip_booking_hours_before: '0',
    min_booking_notice_hours: '2',
    reserve_spots: '0',
    waitlist_enabled: false,
    compensation_plan_id: ''
};
function fmtDate(iso) {
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    return "".concat(d, "/").concat(m, "/").concat(y);
}
function NewCoursePage() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('school.courses.new');
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const STEPS = [
        t('stepBasicDetails'),
        t('stepSchedules')
    ];
    const WEEKDAYS = [
        {
            value: 'monday',
            label: t('monday')
        },
        {
            value: 'tuesday',
            label: t('tuesday')
        },
        {
            value: 'wednesday',
            label: t('wednesday')
        },
        {
            value: 'thursday',
            label: t('thursday')
        },
        {
            value: 'friday',
            label: t('friday')
        },
        {
            value: 'saturday',
            label: t('saturday')
        },
        {
            value: 'sunday',
            label: t('sunday')
        }
    ];
    const FREQ_OPTIONS = [
        {
            value: 'single',
            label: t('freqSingle'),
            desc: t('freqSingleDesc')
        },
        {
            value: 'weekly',
            label: t('freqWeekly'),
            desc: t('freqWeeklyDesc')
        },
        {
            value: 'biweekly',
            label: t('freqBiweekly'),
            desc: t('freqBiweeklyDesc')
        },
        {
            value: 'intensive',
            label: t('freqIntensive'),
            desc: t('freqIntensiveDesc')
        }
    ];
    function scheduleLabel(s) {
        var _FREQ_OPTIONS_find, _WEEKDAYS_find;
        if (!s.start_date || !s.start_time) return t('notConfigured');
        var _FREQ_OPTIONS_find_label;
        const freqLabel = (_FREQ_OPTIONS_find_label = (_FREQ_OPTIONS_find = FREQ_OPTIONS.find((f)=>f.value === s.frequency)) === null || _FREQ_OPTIONS_find === void 0 ? void 0 : _FREQ_OPTIONS_find.label) !== null && _FREQ_OPTIONS_find_label !== void 0 ? _FREQ_OPTIONS_find_label : s.frequency;
        var _WEEKDAYS_find_label;
        const weekdayLabel = s.frequency === 'weekly' || s.frequency === 'biweekly' ? (_WEEKDAYS_find_label = (_WEEKDAYS_find = WEEKDAYS.find((w)=>w.value === s.weekday)) === null || _WEEKDAYS_find === void 0 ? void 0 : _WEEKDAYS_find.label) !== null && _WEEKDAYS_find_label !== void 0 ? _WEEKDAYS_find_label : '' : '';
        const dayPart = weekdayLabel ? " ".concat(weekdayLabel) : '';
        const end = s.end_date ? " → ".concat(fmtDate(s.end_date)) : s.frequency !== 'single' ? t('forOneYear') : '';
        return "".concat(freqLabel).concat(dayPart, " · ").concat(s.start_time, " · ").concat(s.duration_minutes, "min · from ").concat(fmtDate(s.start_date)).concat(end);
    }
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [lessonTypes, setLessonTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [teachers, setTeachers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [rooms, setRooms] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [plans, setPlans] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [schoolId, setSchoolId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [hqCountries, setHqCountries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [hqCities, setHqCities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Step 1 fields
    const [lessonTypeId, setLessonTypeId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [courseName, setCourseName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [teacherId, setTeacherId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [notes, setNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isOnline, setIsOnline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [onlineLink, setOnlineLink] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [language, setLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('it');
    const [courseCountry, setCourseCountry] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [courseCity, setCourseCity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Step 2: multiple schedules
    const [schedules, setSchedules] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        {
            ...DEFAULT_SCHEDULE
        }
    ]);
    const [openSchedule, setOpenSchedule] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NewCoursePage.useEffect": ()=>{
            async function load() {
                var _school_data, _school_data1, _school_data2;
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) return;
                const { data: profile } = await supabase.from('profiles').select('school_id').eq('id', user.id).single();
                if (!(profile === null || profile === void 0 ? void 0 : profile.school_id)) return;
                setSchoolId(profile.school_id);
                const [lt, th, loc, pl, school] = await Promise.all([
                    supabase.from('lesson_types').select('id, code, name_en, name_it').eq('active', true).order('name_en'),
                    supabase.from('teachers').select('id, name').eq('school_id', profile.school_id).eq('active', true).order('name'),
                    supabase.from('school_locations').select('id, name, school_rooms(id, name, capacity)').eq('school_id', profile.school_id),
                    supabase.from('compensation_plans').select('id, name').eq('school_id', profile.school_id).order('name'),
                    supabase.from('schools').select('language, country, city').eq('id', profile.school_id).single()
                ]);
                if ((_school_data = school.data) === null || _school_data === void 0 ? void 0 : _school_data.language) setLanguage(school.data.language);
                if ((_school_data1 = school.data) === null || _school_data1 === void 0 ? void 0 : _school_data1.country) setCourseCountry(school.data.country);
                if ((_school_data2 = school.data) === null || _school_data2 === void 0 ? void 0 : _school_data2.city) setCourseCity(school.data.city);
                const locRes = await fetch('/api/locations');
                if (locRes.ok) {
                    const loc = await locRes.json();
                    var _loc_countries;
                    setHqCountries((_loc_countries = loc.countries) !== null && _loc_countries !== void 0 ? _loc_countries : []);
                    var _loc_cities;
                    setHqCities((_loc_cities = loc.cities) !== null && _loc_cities !== void 0 ? _loc_cities : []);
                }
                var _lt_data;
                setLessonTypes((_lt_data = lt.data) !== null && _lt_data !== void 0 ? _lt_data : []);
                var _th_data;
                setTeachers((_th_data = th.data) !== null && _th_data !== void 0 ? _th_data : []);
                var _pl_data;
                setPlans((_pl_data = pl.data) !== null && _pl_data !== void 0 ? _pl_data : []);
                const flatRooms = [];
                var _loc_data;
                for (const location of (_loc_data = loc.data) !== null && _loc_data !== void 0 ? _loc_data : []){
                    var _location_school_rooms;
                    for (const room of (_location_school_rooms = location.school_rooms) !== null && _location_school_rooms !== void 0 ? _location_school_rooms : []){
                        flatRooms.push({
                            id: room.id,
                            name: room.name,
                            capacity: room.capacity,
                            location_name: location.name
                        });
                    }
                }
                setRooms(flatRooms);
            }
            load();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["NewCoursePage.useEffect"], []);
    function updateSchedule(index, key, value) {
        setSchedules((prev)=>prev.map((s, i)=>i === index ? {
                    ...s,
                    [key]: value
                } : s));
    }
    function addSchedule() {
        const last = schedules[schedules.length - 1];
        setSchedules((prev)=>[
                ...prev,
                {
                    ...last
                }
            ]);
        setOpenSchedule(schedules.length);
    }
    function removeSchedule(index) {
        if (schedules.length <= 1) return;
        setSchedules((prev)=>prev.filter((_, i)=>i !== index));
        setOpenSchedule(Math.max(0, openSchedule >= index ? openSchedule - 1 : openSchedule));
    }
    async function handleSubmit() {
        if (!schoolId) return;
        setSubmitting(true);
        setError(null);
        const res = await fetch('/api/school/courses', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                lesson_type_id: lessonTypeId,
                name: courseName,
                teacher_id: teacherId || null,
                description: description || null,
                notes: notes || null,
                is_online: isOnline,
                online_link: onlineLink || null,
                language,
                country: courseCountry || null,
                city: courseCity || null,
                schedules: schedules.map((s)=>({
                        frequency: s.frequency,
                        weekday: s.weekday || undefined,
                        start_date: s.start_date,
                        end_date: s.end_date || undefined,
                        start_time: s.start_time,
                        duration_minutes: Number(s.duration_minutes),
                        max_capacity: Number(s.max_capacity),
                        credit_cost: Number(s.credit_cost),
                        color: s.color,
                        vip_booking_hours_before: Number(s.vip_booking_hours_before),
                        min_booking_notice_hours: Number(s.min_booking_notice_hours),
                        room_id: s.room_id || undefined,
                        teacher_id: s.teacher_id || undefined,
                        reserve_spots: Number(s.reserve_spots),
                        waitlist_enabled: s.waitlist_enabled,
                        compensation_plan_id: s.compensation_plan_id || undefined
                    }))
            })
        });
        const data = await res.json();
        if (!res.ok) {
            var _data_error;
            setError((_data_error = data.error) !== null && _data_error !== void 0 ? _data_error : 'Something went wrong');
            setSubmitting(false);
        } else {
            router.push('/school/courses');
        }
    }
    const inputCls = 'w-full px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20';
    const labelCls = 'block text-sm font-medium text-gray-700 mb-1';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-2xl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/school/courses",
                        className: "text-sm text-gray-400 hover:text-gray-600",
                        children: t('backToCourses')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 236,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-2xl font-bold text-gray-900 mt-2",
                        children: t('title')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 237,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                lineNumber: 235,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center mb-8",
                children: [
                    STEPS.map((_s, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition ".concat(i < step ? 'bg-[#6B1F3A] text-white' : i === step ? 'bg-[#6B1F3A] text-white ring-4 ring-[#6B1F3A]/20' : 'bg-gray-100 text-gray-400'),
                                    children: i < step ? '✓' : i + 1
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                    lineNumber: 244,
                                    columnNumber: 13
                                }, this),
                                i < STEPS.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-0.5 w-16 mx-1 ".concat(i < step ? 'bg-[#6B1F3A]' : 'bg-gray-200')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                    lineNumber: 252,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, i, true, {
                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                            lineNumber: 243,
                            columnNumber: 11
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "ml-4 text-sm text-gray-500",
                        children: STEPS[step]
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 256,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                lineNumber: 241,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-lg",
                children: error
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                lineNumber: 259,
                columnNumber: 17
            }, this),
            step === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 p-6 space-y-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: labelCls,
                                children: t('labelLessonType')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 265,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: lessonTypeId,
                                onChange: (e)=>{
                                    const selected = lessonTypes.find((lt)=>lt.id === e.target.value);
                                    setLessonTypeId(e.target.value);
                                    var _selected_name_it, _ref;
                                    setCourseName((_ref = (_selected_name_it = selected === null || selected === void 0 ? void 0 : selected.name_it) !== null && _selected_name_it !== void 0 ? _selected_name_it : selected === null || selected === void 0 ? void 0 : selected.name_en) !== null && _ref !== void 0 ? _ref : '');
                                },
                                className: inputCls,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: t('selectLessonType')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 275,
                                        columnNumber: 15
                                    }, this),
                                    lessonTypes.map((lt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: lt.id,
                                            children: lt.name_it || lt.name_en
                                        }, lt.id, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 277,
                                            columnNumber: 17
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 266,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 264,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: labelCls,
                                children: t('labelDefaultTeacher')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 282,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: teacherId,
                                onChange: (e)=>setTeacherId(e.target.value),
                                className: inputCls,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: t('selectTeacher')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 284,
                                        columnNumber: 15
                                    }, this),
                                    teachers.map((teacher)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: teacher.id,
                                            children: teacher.name
                                        }, teacher.id, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 285,
                                            columnNumber: 42
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 283,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-400 mt-1",
                                children: t('teacherOverrideHint')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 287,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 281,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: labelCls,
                                children: t('labelLanguage')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 290,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: language,
                                onChange: (e)=>setLanguage(e.target.value),
                                className: inputCls,
                                children: LANGUAGES.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: l.value,
                                        children: l.label
                                    }, l.value, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 293,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 291,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-400 mt-1",
                                children: t('languageHint')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 296,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 289,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: t('labelCountry')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 300,
                                        columnNumber: 15
                                    }, this),
                                    hqCountries.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: courseCountry,
                                        onChange: (e)=>setCourseCountry(e.target.value),
                                        className: inputCls,
                                        placeholder: t('countryPlaceholder')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 302,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: courseCountry,
                                        onChange: (e)=>{
                                            setCourseCountry(e.target.value);
                                            setCourseCity('');
                                        },
                                        className: inputCls,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "",
                                                children: t('selectCountry')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                lineNumber: 309,
                                                columnNumber: 19
                                            }, this),
                                            hqCountries.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: c.name,
                                                    children: c.name
                                                }, c.id, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 311,
                                                    columnNumber: 21
                                                }, this))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 304,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 299,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: labelCls,
                                        children: t('labelCity')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 317,
                                        columnNumber: 15
                                    }, this),
                                    hqCountries.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: courseCity,
                                        onChange: (e)=>setCourseCity(e.target.value),
                                        className: inputCls,
                                        placeholder: t('cityPlaceholder')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                        lineNumber: 319,
                                        columnNumber: 17
                                    }, this) : (()=>{
                                        const matched = hqCountries.find((c)=>c.name === courseCountry);
                                        const filtered = matched ? hqCities.filter((c)=>c.country_id === matched.id) : [];
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            value: courseCity,
                                            onChange: (e)=>setCourseCity(e.target.value),
                                            disabled: !courseCountry || filtered.length === 0,
                                            className: "".concat(inputCls, " disabled:opacity-50 disabled:cursor-not-allowed"),
                                            children: !courseCountry ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "",
                                                children: t('selectCountryFirst')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                lineNumber: 331,
                                                columnNumber: 23
                                            }, this) : filtered.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "",
                                                children: t('noCities')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                lineNumber: 333,
                                                columnNumber: 23
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        children: t('selectCity')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                        lineNumber: 336,
                                                        columnNumber: 25
                                                    }, this),
                                                    filtered.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: c.name,
                                                            children: c.name
                                                        }, c.id, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 338,
                                                            columnNumber: 27
                                                        }, this))
                                                ]
                                            }, void 0, true)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 324,
                                            columnNumber: 19
                                        }, this);
                                    })()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 316,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 298,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: labelCls,
                                children: t('labelDescription')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 348,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                value: description,
                                onChange: (e)=>setDescription(e.target.value),
                                rows: 2,
                                className: inputCls,
                                placeholder: t('descriptionPlaceholder')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 349,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 347,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: labelCls,
                                children: t('labelNotes')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 352,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                value: notes,
                                onChange: (e)=>setNotes(e.target.value),
                                rows: 3,
                                className: "".concat(inputCls, " resize-none"),
                                placeholder: t('notesPlaceholder')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 353,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 351,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: labelCls,
                                children: "Online Course"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 356,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>{
                                    setIsOnline(!isOnline);
                                    if (isOnline) setOnlineLink('');
                                },
                                className: "px-4 py-2 rounded-lg text-sm font-medium transition border ".concat(isOnline ? 'bg-[#6B1F3A] text-white border-[#6B1F3A]' : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'),
                                children: isOnline ? '🌐 Online' : '📍 In-Person'
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 357,
                                columnNumber: 13
                            }, this),
                            isOnline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "url",
                                value: onlineLink,
                                onChange: (e)=>setOnlineLink(e.target.value),
                                placeholder: "https://zoom.us/j/...",
                                className: "".concat(inputCls, " mt-2")
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                lineNumber: 365,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 355,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                lineNumber: 263,
                columnNumber: 9
            }, this),
            step === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    schedules.map((sched, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between px-5 py-3.5 cursor-pointer hover:bg-gray-50 transition",
                                    onClick: ()=>setOpenSchedule(openSchedule === idx ? -1 : idx),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-3 h-3 rounded-full shrink-0",
                                                    style: {
                                                        backgroundColor: sched.color
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 388,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm font-medium text-gray-900",
                                                            children: t('scheduleNumber', {
                                                                num: idx + 1
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 390,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-400",
                                                            children: scheduleLabel(sched)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 391,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 389,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 387,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                schedules.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: (e)=>{
                                                        e.stopPropagation();
                                                        removeSchedule(idx);
                                                    },
                                                    className: "text-xs text-red-400 hover:text-red-600 px-2 py-1 rounded hover:bg-red-50 transition",
                                                    children: t('remove')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 396,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-300 text-sm",
                                                    children: openSchedule === idx ? '▲' : '▼'
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 403,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 394,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                    lineNumber: 383,
                                    columnNumber: 15
                                }, this),
                                openSchedule === idx && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "px-5 pb-5 pt-1 space-y-4 border-t border-gray-50",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: labelCls,
                                                    children: t('labelFrequency')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 412,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid grid-cols-2 gap-2 mt-1",
                                                    children: FREQ_OPTIONS.map((opt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            onClick: ()=>updateSchedule(idx, 'frequency', opt.value),
                                                            className: "p-3 rounded-xl border-2 text-left transition ".concat(sched.frequency === opt.value ? 'border-[#6B1F3A] bg-[#6B1F3A]/5' : 'border-gray-200 hover:border-gray-300'),
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "font-medium text-xs ".concat(sched.frequency === opt.value ? 'text-[#6B1F3A]' : 'text-gray-800'),
                                                                    children: opt.label
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                    lineNumber: 425,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-xs text-gray-400 mt-0.5",
                                                                    children: opt.desc
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                    lineNumber: 426,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, opt.value, true, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 415,
                                                            columnNumber: 25
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 413,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 411,
                                            columnNumber: 19
                                        }, this),
                                        (sched.frequency === 'weekly' || sched.frequency === 'biweekly') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: labelCls,
                                                    children: t('labelDayOfWeek')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 435,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex flex-wrap gap-2 mt-1",
                                                    children: WEEKDAYS.map((w)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            onClick: ()=>updateSchedule(idx, 'weekday', w.value),
                                                            className: "px-3 py-1.5 rounded-lg text-xs font-medium border transition ".concat(sched.weekday === w.value ? 'bg-[#6B1F3A] text-white border-[#6B1F3A]' : 'border-gray-200 text-gray-600 hover:border-gray-300'),
                                                            children: w.label
                                                        }, w.value, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 438,
                                                            columnNumber: 27
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 436,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 434,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-2 gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelStartDate')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 457,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "date",
                                                            value: sched.start_date,
                                                            onChange: (e)=>updateSchedule(idx, 'start_date', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 458,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 456,
                                                    columnNumber: 21
                                                }, this),
                                                sched.frequency !== 'single' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: [
                                                                t('labelEndDate'),
                                                                " ",
                                                                sched.frequency === 'intensive' ? '*' : t('endDateBlank')
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 462,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "date",
                                                            value: sched.end_date,
                                                            onChange: (e)=>updateSchedule(idx, 'end_date', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 463,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 461,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelStartTime')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 467,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "time",
                                                            value: sched.start_time,
                                                            onChange: (e)=>updateSchedule(idx, 'start_time', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 468,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 466,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelDuration')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 471,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "15",
                                                            step: "15",
                                                            value: sched.duration_minutes,
                                                            onChange: (e)=>updateSchedule(idx, 'duration_minutes', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 472,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 470,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelMaxCapacity')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 475,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "1",
                                                            value: sched.max_capacity,
                                                            onChange: (e)=>updateSchedule(idx, 'max_capacity', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 476,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 474,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelCreditCost')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 479,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "1",
                                                            value: sched.credit_cost,
                                                            onChange: (e)=>updateSchedule(idx, 'credit_cost', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 480,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 478,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelVipBooking')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 483,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "0",
                                                            value: sched.vip_booking_hours_before,
                                                            onChange: (e)=>updateSchedule(idx, 'vip_booking_hours_before', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 484,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 482,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelMinNotice')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 487,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "0",
                                                            value: sched.min_booking_notice_hours,
                                                            onChange: (e)=>updateSchedule(idx, 'min_booking_notice_hours', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 488,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 486,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelRoom')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 491,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: sched.room_id,
                                                            onChange: (e)=>updateSchedule(idx, 'room_id', e.target.value),
                                                            className: inputCls,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: t('noRoomAssigned')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                    lineNumber: 493,
                                                                    columnNumber: 25
                                                                }, this),
                                                                rooms.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                        value: r.id,
                                                                        children: [
                                                                            r.location_name,
                                                                            " — ",
                                                                            r.name,
                                                                            " (cap. ",
                                                                            r.capacity,
                                                                            ")"
                                                                        ]
                                                                    }, r.id, true, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 494,
                                                                        columnNumber: 43
                                                                    }, this))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 492,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 490,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelTeacherOverride')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 498,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: sched.teacher_id,
                                                            onChange: (e)=>updateSchedule(idx, 'teacher_id', e.target.value),
                                                            className: inputCls,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: t('useCourseDefault')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                    lineNumber: 500,
                                                                    columnNumber: 25
                                                                }, this),
                                                                teachers.map((teacher)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                        value: teacher.id,
                                                                        children: teacher.name
                                                                    }, teacher.id, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 501,
                                                                        columnNumber: 52
                                                                    }, this))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 499,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 497,
                                                    columnNumber: 21
                                                }, this),
                                                plans.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelCompPlan')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 506,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                            value: sched.compensation_plan_id,
                                                            onChange: (e)=>updateSchedule(idx, 'compensation_plan_id', e.target.value),
                                                            className: inputCls,
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: "",
                                                                    children: t('noPlan')
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                    lineNumber: 508,
                                                                    columnNumber: 27
                                                                }, this),
                                                                plans.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                        value: p.id,
                                                                        children: p.name
                                                                    }, p.id, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 509,
                                                                        columnNumber: 45
                                                                    }, this))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 507,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 505,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 455,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: labelCls,
                                                    children: t('labelCalendarColor')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 517,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2 mt-1 flex-wrap items-center",
                                                    children: [
                                                        COLORS.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: ()=>updateSchedule(idx, 'color', c),
                                                                className: "w-8 h-8 rounded-full border-2 transition",
                                                                style: {
                                                                    backgroundColor: c,
                                                                    borderColor: sched.color === c ? '#1f2937' : 'transparent'
                                                                }
                                                            }, c, false, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                lineNumber: 520,
                                                                columnNumber: 25
                                                            }, this)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "w-8 h-8 rounded-full border-2 border-dashed border-gray-300 cursor-pointer overflow-hidden relative flex items-center justify-center hover:border-gray-400 transition",
                                                            title: "Custom color",
                                                            style: !COLORS.includes(sched.color) ? {
                                                                borderColor: '#1f2937',
                                                                borderStyle: 'solid',
                                                                backgroundColor: sched.color
                                                            } : {},
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "color",
                                                                    value: sched.color,
                                                                    onChange: (e)=>updateSchedule(idx, 'color', e.target.value),
                                                                    className: "absolute opacity-0 w-full h-full cursor-pointer"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                    lineNumber: 530,
                                                                    columnNumber: 25
                                                                }, this),
                                                                COLORS.includes(sched.color) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-gray-400 text-xs leading-none select-none",
                                                                    children: "+"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                    lineNumber: 532,
                                                                    columnNumber: 58
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 525,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 518,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 516,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-2 gap-3 pt-1 border-t border-gray-50",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: labelCls,
                                                            children: t('labelReserveSpots')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 540,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "number",
                                                            min: "0",
                                                            value: sched.reserve_spots,
                                                            onChange: (e)=>updateSchedule(idx, 'reserve_spots', e.target.value),
                                                            className: inputCls
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 541,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-gray-400 mt-1",
                                                            children: t('reserveSpotsHint')
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                            lineNumber: 544,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 539,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex flex-col justify-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "flex items-center gap-3 cursor-pointer mt-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "relative",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "checkbox",
                                                                        className: "sr-only",
                                                                        checked: sched.waitlist_enabled,
                                                                        onChange: (e)=>setSchedules((prev)=>prev.map((s, i)=>i === idx ? {
                                                                                        ...s,
                                                                                        waitlist_enabled: e.target.checked
                                                                                    } : s))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 549,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "w-10 h-6 rounded-full transition ".concat(sched.waitlist_enabled ? 'bg-[#6B1F3A]' : 'bg-gray-200')
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 552,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ".concat(sched.waitlist_enabled ? 'left-5' : 'left-1')
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 553,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                lineNumber: 548,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-sm font-medium text-gray-700",
                                                                        children: t('enableWaitlist')
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 556,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-xs text-gray-400",
                                                                        children: t('waitlistHint')
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                        lineNumber: 557,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                                lineNumber: 555,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                        lineNumber: 547,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                                    lineNumber: 546,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 538,
                                            columnNumber: 19
                                        }, this),
                                        sched.start_date && sched.start_time && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-3 bg-blue-50 rounded-lg text-xs text-blue-700",
                                            children: scheduleLabel(sched)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                            lineNumber: 565,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                                    lineNumber: 409,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, idx, true, {
                            fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                            lineNumber: 381,
                            columnNumber: 13
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: addSchedule,
                        className: "w-full py-3 border-2 border-dashed border-gray-200 rounded-xl text-sm text-gray-400 hover:border-gray-300 hover:text-gray-600 transition",
                        children: t('addSchedule')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 575,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                lineNumber: 379,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between mt-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setStep((s)=>s - 1),
                        disabled: step === 0,
                        className: "px-5 py-2.5 border border-gray-200 rounded-lg text-sm text-gray-600 disabled:opacity-30",
                        children: t('back')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 588,
                        columnNumber: 9
                    }, this),
                    step < STEPS.length - 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>{
                            if (step === 0 && !lessonTypeId) {
                                setError(t('errorSelectLessonType'));
                                return;
                            }
                            if (step === 1) {
                                const missingDate = schedules.find((s)=>!s.start_date || !s.start_time);
                                if (missingDate) {
                                    setError(t('errorStartDateTime'));
                                    return;
                                }
                                const missingWeekday = schedules.find((s)=>(s.frequency === 'weekly' || s.frequency === 'biweekly') && !s.weekday);
                                if (missingWeekday) {
                                    setError(t('errorWeekday'));
                                    return;
                                }
                            }
                            setError(null);
                            setStep((s)=>s + 1);
                        },
                        className: "px-5 py-2.5 bg-[#6B1F3A] text-white rounded-lg text-sm font-medium hover:bg-[#5a1930] transition",
                        children: t('next')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 597,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleSubmit,
                        disabled: submitting,
                        className: "px-6 py-2.5 bg-[#6B1F3A] text-white rounded-lg text-sm font-medium hover:bg-[#5a1930] transition disabled:opacity-50",
                        children: submitting ? t('creating') : t('createCourse')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                        lineNumber: 626,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
                lineNumber: 587,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/courses/new/page.tsx",
        lineNumber: 234,
        columnNumber: 5
    }, this);
}
_s(NewCoursePage, "ZJLJOJa5RBpsGHgQhRL6h6lLaJY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = NewCoursePage;
var _c;
__turbopack_context__.k.register(_c, "NewCoursePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_school_courses_new_page_tsx_9b824e68._.js.map