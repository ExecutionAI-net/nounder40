(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/hq/emails/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EmailTemplatesPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
const LOCALES = [
    'en',
    'it',
    'es',
    'fr',
    'de'
];
const LOCALE_LABELS = {
    en: '🇬🇧 EN',
    it: '🇮🇹 IT',
    es: '🇪🇸 ES',
    fr: '🇫🇷 FR',
    de: '🇩🇪 DE'
};
const TEMPLATE_KEYS = [
    {
        key: 'student.welcome',
        label: 'Welcome',
        group: 'Student',
        icon: '👋'
    },
    {
        key: 'student.booking_confirmed',
        label: 'Booking Confirmed',
        group: 'Student',
        icon: '✅'
    },
    {
        key: 'student.booking_cancelled',
        label: 'Booking Cancelled',
        group: 'Student',
        icon: '❌'
    },
    {
        key: 'student.lesson_cancelled_by_school',
        label: 'Lesson Cancelled by School',
        group: 'Student',
        icon: '🚫'
    },
    {
        key: 'student.lesson_reminder_1day',
        label: 'Lesson Reminder — 1 Day',
        group: 'Student',
        icon: '🔔'
    },
    {
        key: 'student.lesson_reminder_2hour',
        label: 'Lesson Reminder — 2 Hours',
        group: 'Student',
        icon: '⏰'
    },
    {
        key: 'student.no_show',
        label: 'No Show',
        group: 'Student',
        icon: '👻'
    },
    {
        key: 'student.credits_low',
        label: 'Credits Low',
        group: 'Student',
        icon: '💳'
    },
    {
        key: 'student.after_purchase',
        label: 'After Purchase',
        group: 'Student',
        icon: '🛍️'
    },
    {
        key: 'student.package_expiring',
        label: 'Package Expiring (7 days)',
        group: 'Student',
        icon: '⏳'
    },
    {
        key: 'school.new_booking',
        label: 'New Booking',
        group: 'School',
        icon: '📅'
    },
    {
        key: 'school.booking_cancelled',
        label: 'Booking Cancelled',
        group: 'School',
        icon: '❌'
    },
    {
        key: 'school.stripe_connected',
        label: 'Stripe Connected',
        group: 'School',
        icon: '💰'
    },
    {
        key: 'hq.new_school_registered',
        label: 'New School Registered',
        group: 'HQ',
        icon: '🏫'
    }
];
const SAMPLE_VARS = {
    student_name: 'Maria Rossi',
    school_name: 'Dance Studio Roma',
    lesson_name: 'Ballet Fundamentals',
    lesson_date: '25 April 2026',
    lesson_time: '18:00',
    lesson_duration: '60 min',
    teacher_name: 'Sofia Ferrari',
    location_name: 'Studio Roma Centro',
    room_name: 'Sala A',
    credits_remaining: '3',
    credits_used: '7',
    credits_threshold: '5',
    package_name: 'Monthly 10 Credits',
    package_expiry: '30 April 2026',
    amount: '€45.00',
    booking_url: '#',
    platform_name: 'No Under 40'
};
function renderPreview(html) {
    return html.replace(/\{\{(\w+)\}\}/g, (_, k)=>{
        var _SAMPLE_VARS_k;
        return (_SAMPLE_VARS_k = SAMPLE_VARS[k]) !== null && _SAMPLE_VARS_k !== void 0 ? _SAMPLE_VARS_k : '<span style="background:#fef3c7;padding:0 2px">{{'.concat(k, "}}</span>");
    });
}
const VARIABLE_CHIPS = Object.keys(SAMPLE_VARS).map(_c = (k)=>"{{".concat(k, "}}"));
_c1 = VARIABLE_CHIPS;
function EmailTemplatesPage() {
    _s();
    const [dbMap, setDbMap] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Map());
    const [settings, setSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [selectedKey, setSelectedKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(TEMPLATE_KEYS[0].key);
    const [selectedLocale, setSelectedLocale] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('en');
    const [subject, setSubject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [bodyHtml, setBodyHtml] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [previewMode, setPreviewMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [translating, setTranslating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [translateResult, setTranslateResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [testEmail, setTestEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [sendingTest, setSendingTest] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [testResult, setTestResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [savingSettings, setSavingSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const load = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "EmailTemplatesPage.useCallback[load]": async ()=>{
            setLoading(true);
            const [tmplRes, settingsRes] = await Promise.all([
                fetch('/api/hq/email-templates').then({
                    "EmailTemplatesPage.useCallback[load]": (r)=>r.json()
                }["EmailTemplatesPage.useCallback[load]"]).catch({
                    "EmailTemplatesPage.useCallback[load]": ()=>[]
                }["EmailTemplatesPage.useCallback[load]"]),
                fetch('/api/hq/email-settings').then({
                    "EmailTemplatesPage.useCallback[load]": (r)=>r.json()
                }["EmailTemplatesPage.useCallback[load]"]).catch({
                    "EmailTemplatesPage.useCallback[load]": ()=>({})
                }["EmailTemplatesPage.useCallback[load]"])
            ]);
            const map = new Map();
            const rows = Array.isArray(tmplRes) ? tmplRes : [];
            for (const row of rows){
                if (!map.has(row.key)) map.set(row.key, new Map());
                map.get(row.key).set(row.locale, {
                    subject: row.subject,
                    body_html: row.body_html
                });
            }
            setDbMap(map);
            setSettings(typeof settingsRes === 'object' && !Array.isArray(settingsRes) ? settingsRes : {});
            setLoading(false);
        }
    }["EmailTemplatesPage.useCallback[load]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmailTemplatesPage.useEffect": ()=>{
            load();
        }
    }["EmailTemplatesPage.useEffect"], [
        load
    ]);
    // Load editor content when key/locale changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EmailTemplatesPage.useEffect": ()=>{
            const localeMap = dbMap.get(selectedKey);
            const data = localeMap === null || localeMap === void 0 ? void 0 : localeMap.get(selectedLocale);
            var _data_subject;
            setSubject((_data_subject = data === null || data === void 0 ? void 0 : data.subject) !== null && _data_subject !== void 0 ? _data_subject : '');
            var _data_body_html;
            setBodyHtml((_data_body_html = data === null || data === void 0 ? void 0 : data.body_html) !== null && _data_body_html !== void 0 ? _data_body_html : '');
            setPreviewMode(false);
            setTranslateResult(null);
            setTestResult(null);
        }
    }["EmailTemplatesPage.useEffect"], [
        selectedKey,
        selectedLocale,
        dbMap
    ]);
    async function handleSave() {
        setSaving(true);
        await fetch('/api/hq/email-templates', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                key: selectedKey,
                locale: selectedLocale,
                subject,
                body_html: bodyHtml
            })
        });
        await load();
        setSaving(false);
    }
    async function handleAutoTranslate() {
        setTranslating(true);
        setTranslateResult(null);
        const res = await fetch('/api/hq/email-templates/auto-translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                key: selectedKey
            })
        });
        const data = await res.json();
        if (!res.ok) setTranslateResult("Error: ".concat(data.error));
        else setTranslateResult(data.translated > 0 ? "✓ ".concat(data.translated, " locales translated") : '✓ All locales already filled');
        await load();
        setTranslating(false);
    }
    async function handleTestSend() {
        if (!testEmail) return;
        setSendingTest(true);
        setTestResult(null);
        const res = await fetch('/api/hq/email-templates/test-send', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                subject,
                body_html: bodyHtml,
                to_email: testEmail
            })
        });
        const data = await res.json();
        setTestResult(res.ok ? '✓ Test email sent' : "Error: ".concat(data.error));
        setSendingTest(false);
    }
    async function handleSaveSettings() {
        setSavingSettings(true);
        await fetch('/api/hq/email-settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(settings)
        });
        setSavingSettings(false);
    }
    function insertVariable(v) {
        setBodyHtml((prev)=>prev + v);
    }
    // Locale completeness for current key
    function localeStatus(locale) {
        var _dbMap_get, _data_subject, _data_body_html;
        const data = (_dbMap_get = dbMap.get(selectedKey)) === null || _dbMap_get === void 0 ? void 0 : _dbMap_get.get(locale);
        return (data === null || data === void 0 ? void 0 : (_data_subject = data.subject) === null || _data_subject === void 0 ? void 0 : _data_subject.trim()) && (data === null || data === void 0 ? void 0 : (_data_body_html = data.body_html) === null || _data_body_html === void 0 ? void 0 : _data_body_html.trim());
    }
    const groups = [
        'Student',
        'School',
        'HQ'
    ];
    const selectedMeta = TEMPLATE_KEYS.find((t)=>t.key === selectedKey);
    var _settings_credits_low_threshold;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-full overflow-hidden bg-gray-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                className: "w-72 flex-shrink-0 bg-white border-r border-gray-100 flex flex-col overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-4 py-4 border-b border-gray-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-base font-semibold text-gray-900",
                                children: "Email Templates"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 183,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-400 mt-0.5",
                                children: [
                                    TEMPLATE_KEYS.length,
                                    " templates · 5 languages"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 184,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                        lineNumber: 182,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 overflow-y-auto py-2",
                        children: groups.map((group)=>{
                            const items = TEMPLATE_KEYS.filter((t)=>t.group === group);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] font-semibold text-gray-400 uppercase tracking-wider px-4 py-2",
                                        children: group
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 192,
                                        columnNumber: 17
                                    }, this),
                                    items.map((t)=>{
                                        const filled = LOCALES.filter((l)=>localeStatus(l)).length;
                                        const isSelected = t.key === selectedKey;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>setSelectedKey(t.key),
                                            className: "w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ".concat(isSelected ? 'bg-[#6B1F3A]/8 border-r-2 border-[#6B1F3A]' : 'hover:bg-gray-50'),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-base flex-shrink-0",
                                                    children: t.icon
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                    lineNumber: 204,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "min-w-0 flex-1",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm truncate ".concat(isSelected ? 'font-semibold text-[#6B1F3A]' : 'text-gray-700'),
                                                        children: t.label
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                        lineNumber: 206,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                    lineNumber: 205,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-0.5 flex-shrink-0",
                                                    children: LOCALES.map((l)=>{
                                                        var _dbMap_get_get_subject, _dbMap_get_get, _dbMap_get;
                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-1.5 h-1.5 rounded-full ".concat(((_dbMap_get = dbMap.get(t.key)) === null || _dbMap_get === void 0 ? void 0 : (_dbMap_get_get = _dbMap_get.get(l)) === null || _dbMap_get_get === void 0 ? void 0 : (_dbMap_get_get_subject = _dbMap_get_get.subject) === null || _dbMap_get_get_subject === void 0 ? void 0 : _dbMap_get_get_subject.trim()) ? 'bg-green-400' : 'bg-gray-200')
                                                        }, l, false, {
                                                            fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                            lineNumber: 212,
                                                            columnNumber: 27
                                                        }, this);
                                                    })
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                    lineNumber: 210,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, t.key, true, {
                                            fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                            lineNumber: 197,
                                            columnNumber: 21
                                        }, this);
                                    })
                                ]
                            }, group, true, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 191,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                        lineNumber: 187,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-t border-gray-100 p-4 flex-shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3",
                                children: "Settings"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 227,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "text-xs text-gray-500 block mb-1",
                                                children: "Credits low threshold"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 230,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "number",
                                                        min: 1,
                                                        value: (_settings_credits_low_threshold = settings.credits_low_threshold) !== null && _settings_credits_low_threshold !== void 0 ? _settings_credits_low_threshold : '5',
                                                        onChange: (e)=>setSettings((s)=>({
                                                                    ...s,
                                                                    credits_low_threshold: e.target.value
                                                                })),
                                                        className: "w-20 px-2 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                        lineNumber: 232,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-gray-400",
                                                        children: "credits"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                        lineNumber: 239,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 231,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 229,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "text-xs text-gray-500 block mb-1.5",
                                                children: "All emails on/off"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 243,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setSettings((s)=>({
                                                            ...s,
                                                            emails_enabled: s.emails_enabled === 'true' ? 'false' : 'true'
                                                        })),
                                                className: "relative w-9 h-5 rounded-full transition-colors ".concat(settings.emails_enabled === 'true' ? 'bg-[#6B1F3A]' : 'bg-gray-200'),
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ".concat(settings.emails_enabled === 'true' ? 'translate-x-4' : 'translate-x-0.5')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                    lineNumber: 248,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 244,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 242,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleSaveSettings,
                                        disabled: savingSettings,
                                        className: "w-full py-1.5 rounded-lg bg-gray-900 text-white text-xs font-medium hover:bg-gray-700 disabled:opacity-50 transition",
                                        children: savingSettings ? 'Saving...' : 'Save Settings'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 251,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 228,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                        lineNumber: 226,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                lineNumber: 181,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex-1 flex flex-col overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white border-b border-gray-100 px-6 py-3 flex items-center gap-4 flex-shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xl",
                                        children: selectedMeta.icon
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 268,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-sm font-semibold text-gray-900",
                                                children: selectedMeta.label
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 270,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-400 font-mono",
                                                children: selectedKey
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 271,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 269,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 267,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 ml-4",
                                children: LOCALES.map((l)=>{
                                    const filled = localeStatus(l);
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setSelectedLocale(l),
                                        className: "px-3 py-1.5 rounded-lg text-xs font-medium transition flex items-center gap-1.5 ".concat(selectedLocale === l ? 'bg-[#6B1F3A] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'),
                                        children: [
                                            LOCALE_LABELS[l],
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "w-1.5 h-1.5 rounded-full ".concat(filled ? 'bg-green-400' : 'bg-red-300', " ").concat(selectedLocale === l ? 'opacity-80' : '')
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 290,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, l, true, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 280,
                                        columnNumber: 17
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 276,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "ml-auto flex items-center gap-2",
                                children: [
                                    translateResult && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs ".concat(translateResult.startsWith('Error') ? 'text-red-500' : 'text-green-600'),
                                        children: translateResult
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 298,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleAutoTranslate,
                                        disabled: translating || !subject.trim(),
                                        className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-violet-600 text-white text-xs font-medium hover:bg-violet-700 disabled:opacity-40 transition",
                                        children: translating ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "inline-block w-3 h-3 border-2 border-white/40 border-t-white rounded-full animate-spin"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                    lineNumber: 308,
                                                    columnNumber: 21
                                                }, this),
                                                "Translating..."
                                            ]
                                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: "✦ Auto-Translate All"
                                        }, void 0, false)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 302,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setPreviewMode((v)=>!v),
                                        className: "px-3 py-1.5 rounded-lg text-xs font-medium transition ".concat(previewMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'),
                                        children: previewMode ? 'Edit' : 'Preview'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 311,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleSave,
                                        disabled: saving,
                                        className: "px-4 py-1.5 rounded-lg bg-[#6B1F3A] text-white text-xs font-semibold hover:bg-[#5a1830] disabled:opacity-50 transition",
                                        children: saving ? 'Saving...' : 'Save'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 317,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 296,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                        lineNumber: 266,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 flex overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 flex flex-col overflow-hidden p-6 gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-xs font-medium text-gray-500 mb-1.5",
                                                children: "Subject line"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 334,
                                                columnNumber: 15
                                            }, this),
                                            previewMode ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "px-3 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-sm text-gray-800",
                                                dangerouslySetInnerHTML: {
                                                    __html: renderPreview(subject)
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 336,
                                                columnNumber: 17
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                value: subject,
                                                onChange: (e)=>setSubject(e.target.value),
                                                placeholder: "e.g. Your lesson is tomorrow, {{student_name}}",
                                                className: "w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 339,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 333,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1 flex flex-col min-h-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-xs font-medium text-gray-500 mb-1.5",
                                                children: "Email body (HTML)"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 351,
                                                columnNumber: 15
                                            }, this),
                                            previewMode ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex-1 overflow-auto rounded-xl border border-gray-200 bg-white",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                                                    srcDoc: renderPreview(bodyHtml),
                                                    className: "w-full h-full rounded-xl",
                                                    title: "Email preview"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                    lineNumber: 354,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 353,
                                                columnNumber: 17
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                value: bodyHtml,
                                                onChange: (e)=>setBodyHtml(e.target.value),
                                                placeholder: "Paste your HTML email template here...",
                                                className: "flex-1 px-3 py-2.5 rounded-xl border border-gray-200 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 resize-none"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 361,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 350,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 pt-2 border-t border-gray-100",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "email",
                                                value: testEmail,
                                                onChange: (e)=>setTestEmail(e.target.value),
                                                placeholder: "test@example.com",
                                                className: "flex-1 max-w-xs px-3 py-1.5 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 372,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleTestSend,
                                                disabled: sendingTest || !testEmail || !subject.trim(),
                                                className: "px-3 py-1.5 rounded-lg bg-gray-900 text-white text-xs font-medium hover:bg-gray-700 disabled:opacity-40 transition",
                                                children: sendingTest ? 'Sending...' : 'Send Test'
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 379,
                                                columnNumber: 15
                                            }, this),
                                            testResult && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs ".concat(testResult.startsWith('Error') ? 'text-red-500' : 'text-green-600'),
                                                children: testResult
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 387,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 371,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                                className: "w-56 flex-shrink-0 border-l border-gray-100 bg-white overflow-y-auto p-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3",
                                        children: "Variables"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 396,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-400 mb-3",
                                        children: "Click to insert into body"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 397,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1",
                                        children: VARIABLE_CHIPS.map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>insertVariable(v),
                                                disabled: previewMode,
                                                className: "w-full text-left px-2 py-1.5 rounded-lg bg-gray-50 hover:bg-[#6B1F3A]/8 text-xs font-mono text-[#6B1F3A] transition disabled:opacity-40",
                                                children: v
                                            }, v, false, {
                                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                                lineNumber: 400,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 398,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs font-semibold text-gray-500 uppercase tracking-wider mt-5 mb-3",
                                        children: "Base HTML"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 411,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setBodyHtml(BASE_HTML_TEMPLATE),
                                        disabled: previewMode,
                                        className: "w-full py-2 rounded-lg border border-dashed border-gray-200 text-xs text-gray-400 hover:border-[#6B1F3A] hover:text-[#6B1F3A] transition disabled:opacity-40",
                                        children: "Load base template"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                        lineNumber: 412,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                                lineNumber: 395,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                        lineNumber: 327,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
                lineNumber: 263,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/hq/emails/page.tsx",
        lineNumber: 178,
        columnNumber: 5
    }, this);
}
_s(EmailTemplatesPage, "hseQWgRSJ+6oQ4Nrhu6bA2VAoIY=");
_c2 = EmailTemplatesPage;
const BASE_HTML_TEMPLATE = '<!DOCTYPE html>\n<html>\n<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>\n<body style="margin:0;padding:0;background:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif">\n  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:40px 20px">\n    <tr><td align="center">\n      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,0.06)">\n\n        <!-- Header -->\n        <tr>\n          <td style="background:#6B1F3A;padding:28px 40px;text-align:center">\n            <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:700;letter-spacing:-0.3px">No Under 40</h1>\n            <p style="margin:6px 0 0;color:#f3d4de;font-size:12px;letter-spacing:0.5px;text-transform:uppercase">Classical Dance Network</p>\n          </td>\n        </tr>\n\n        <!-- Body -->\n        <tr>\n          <td style="padding:40px 40px 32px">\n            <h2 style="margin:0 0 16px;color:#111827;font-size:20px;font-weight:600">Hi {{student_name}},</h2>\n            <p style="margin:0 0 24px;color:#6b7280;font-size:15px;line-height:1.7">\n              Your message here.\n            </p>\n\n            <!-- CTA Button -->\n            <table cellpadding="0" cellspacing="0" style="margin-bottom:32px">\n              <tr>\n                <td style="background:#6B1F3A;border-radius:10px">\n                  <a href="{{booking_url}}" style="display:inline-block;padding:14px 28px;color:#ffffff;font-size:14px;font-weight:600;text-decoration:none">\n                    View Details →\n                  </a>\n                </td>\n              </tr>\n            </table>\n\n            <!-- Info card -->\n            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border-radius:12px;border:1px solid #e5e7eb;margin-bottom:24px">\n              <tr>\n                <td style="padding:20px 24px">\n                  <table width="100%" cellpadding="0" cellspacing="0">\n                    <tr>\n                      <td style="padding:6px 0;color:#6b7280;font-size:13px;width:40%">Lesson</td>\n                      <td style="padding:6px 0;color:#111827;font-size:13px;font-weight:500">{{lesson_name}}</td>\n                    </tr>\n                    <tr>\n                      <td style="padding:6px 0;color:#6b7280;font-size:13px">Date</td>\n                      <td style="padding:6px 0;color:#111827;font-size:13px;font-weight:500">{{lesson_date}} · {{lesson_time}}</td>\n                    </tr>\n                    <tr>\n                      <td style="padding:6px 0;color:#6b7280;font-size:13px">Teacher</td>\n                      <td style="padding:6px 0;color:#111827;font-size:13px;font-weight:500">{{teacher_name}}</td>\n                    </tr>\n                    <tr>\n                      <td style="padding:6px 0;color:#6b7280;font-size:13px">Location</td>\n                      <td style="padding:6px 0;color:#111827;font-size:13px;font-weight:500">{{location_name}} · {{room_name}}</td>\n                    </tr>\n                  </table>\n                </td>\n              </tr>\n            </table>\n\n            <p style="margin:0;color:#9ca3af;font-size:13px;line-height:1.6">\n              If you have any questions, reply to this email or contact {{school_name}}.\n            </p>\n          </td>\n        </tr>\n\n        <!-- Footer -->\n        <tr>\n          <td style="padding:20px 40px;background:#f9fafb;border-top:1px solid #f3f4f6;text-align:center">\n            <p style="margin:0;color:#9ca3af;font-size:12px">{{platform_name}} · Classical Dance Network</p>\n            <p style="margin:4px 0 0;color:#d1d5db;font-size:11px">{{school_name}}</p>\n          </td>\n        </tr>\n\n      </table>\n    </td></tr>\n  </table>\n</body>\n</html>';
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "VARIABLE_CHIPS$Object.keys(SAMPLE_VARS).map");
__turbopack_context__.k.register(_c1, "VARIABLE_CHIPS");
__turbopack_context__.k.register(_c2, "EmailTemplatesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_hq_emails_page_tsx_cca91173._.js.map