(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/school/calendar/CalendarClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CalendarClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const DAYS_SHORT = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun'
];
const MONTHS = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
];
function toISO(d) {
    return d.toISOString().split('T')[0];
}
function getWeekDates(anchor) {
    const day = anchor.getDay();
    const monday = new Date(anchor);
    monday.setDate(anchor.getDate() - (day + 6) % 7);
    return Array.from({
        length: 7
    }, (_, i)=>{
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        return d;
    });
}
function getMonthDates(anchor) {
    const year = anchor.getFullYear();
    const month = anchor.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startOffset = (firstDay.getDay() + 6) % 7;
    const totalCells = Math.ceil((startOffset + lastDay.getDate()) / 7) * 7;
    return Array.from({
        length: totalCells
    }, (_, i)=>{
        const d = new Date(firstDay);
        d.setDate(1 - startOffset + i);
        return d;
    });
}
function getRangeForMode(anchor, mode) {
    if (mode === 'day') {
        const s = toISO(anchor);
        return {
            from: s,
            to: s
        };
    }
    if (mode === 'week') {
        const dates = getWeekDates(anchor);
        return {
            from: toISO(dates[0]),
            to: toISO(dates[6])
        };
    }
    if (mode === 'month') {
        const year = anchor.getFullYear();
        const month = anchor.getMonth();
        return {
            from: toISO(new Date(year, month, 1)),
            to: toISO(new Date(year, month + 1, 0))
        };
    }
    const year = anchor.getFullYear();
    return {
        from: "".concat(year, "-01-01"),
        to: "".concat(year, "-12-31")
    };
}
function navigate(anchor, mode, dir) {
    const d = new Date(anchor);
    if (mode === 'day') d.setDate(d.getDate() + dir);
    else if (mode === 'week') d.setDate(d.getDate() + dir * 7);
    else if (mode === 'month') d.setMonth(d.getMonth() + dir);
    else d.setFullYear(d.getFullYear() + dir);
    return d;
}
function headerLabel(anchor, mode) {
    if (mode === 'day') {
        return anchor.toLocaleDateString('en-GB', {
            weekday: 'long',
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
    }
    if (mode === 'week') {
        const dates = getWeekDates(anchor);
        return "".concat(dates[0].toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short'
        }), " – ").concat(dates[6].toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        }));
    }
    if (mode === 'month') {
        return anchor.toLocaleDateString('en-GB', {
            month: 'long',
            year: 'numeric'
        });
    }
    return String(anchor.getFullYear());
}
/** Returns the Closure that covers the given ISO date string, or null */ function getClosureForDate(dateStr, closures) {
    for (const c of closures){
        var _c_end_date;
        const end = (_c_end_date = c.end_date) !== null && _c_end_date !== void 0 ? _c_end_date : c.date;
        if (dateStr >= c.date && dateStr <= end) return c;
    }
    return null;
}
function CalendarClient(param) {
    let { initialLessons, teacherOptions, studentOptions, initialCourses, initialClosures } = param;
    var _selected_courses, _selected_courses1, _selected_lesson_types, _selected_lesson_types1, _selected_teachers, _selected_school_rooms_school_locations, _selected_courses2;
    _s();
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [anchor, setAnchor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "CalendarClient.useState": ()=>new Date()
    }["CalendarClient.useState"]);
    const [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('week');
    const [lessons, setLessons] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialLessons);
    const [closures, setClosures] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialClosures);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const isFirstRender = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(true);
    // Filters
    const [filterLocation, setFilterLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterRoom, setFilterRoom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterTeacher, setFilterTeacher] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterStudent, setFilterStudent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [studentLessonIds, setStudentLessonIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Add Class from calendar
    const [showAddClass, setShowAddClass] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [courses, setCourses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCourses);
    const [addForm, setAddForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        course_id: '',
        date: '',
        start_time: '',
        duration_minutes: '60'
    });
    const [addingClass, setAddingClass] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [addClassError, setAddClassError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Enrolled students for selected class
    const [enrollments, setEnrollments] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [enrollmentsLoading, setEnrollmentsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CalendarClient.useEffect": ()=>{
            if (!selected) {
                setEnrollments([]);
                return;
            }
            setEnrollmentsLoading(true);
            fetch("/api/school/classes/".concat(selected.id)).then({
                "CalendarClient.useEffect": (r)=>r.json()
            }["CalendarClient.useEffect"]).then({
                "CalendarClient.useEffect": (data)=>{
                    var _data_enrollments;
                    setEnrollments((_data_enrollments = data.enrollments) !== null && _data_enrollments !== void 0 ? _data_enrollments : []);
                    setEnrollmentsLoading(false);
                }
            }["CalendarClient.useEffect"]).catch({
                "CalendarClient.useEffect": ()=>setEnrollmentsLoading(false)
            }["CalendarClient.useEffect"]);
        }
    }["CalendarClient.useEffect"], [
        selected
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CalendarClient.useEffect": ()=>{
            if (!filterStudent) {
                setStudentLessonIds(null);
                return;
            }
            supabase.from('bookings').select('lesson_id').eq('student_id', filterStudent).in('status', [
                'confirmed',
                'attended'
            ]).then({
                "CalendarClient.useEffect": (param)=>{
                    let { data } = param;
                    setStudentLessonIds(new Set((data !== null && data !== void 0 ? data : []).map({
                        "CalendarClient.useEffect": (b)=>b.lesson_id
                    }["CalendarClient.useEffect"])));
                }
            }["CalendarClient.useEffect"]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["CalendarClient.useEffect"], [
        filterStudent
    ]);
    async function handleAddClass() {
        if (!addForm.course_id || !addForm.date || !addForm.start_time) return;
        setAddingClass(true);
        setAddClassError(null);
        const res = await fetch('/api/school/classes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                ...addForm,
                frequency: 'single'
            })
        });
        const data = await res.json();
        if (!res.ok) {
            setAddClassError(data.error);
            setAddingClass(false);
            return;
        }
        setShowAddClass(false);
        setAddForm({
            course_id: '',
            date: '',
            start_time: '',
            duration_minutes: '60'
        });
        setAddingClass(false);
        fetchLessons();
    }
    const { from, to } = getRangeForMode(anchor, mode);
    const fetchLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CalendarClient.useCallback[fetchLessons]": async ()=>{
            setLoading(true);
            const res = await fetch("/api/school/courses?from=".concat(from, "&to=").concat(to));
            if (res.ok) setLessons(await res.json());
            setLoading(false);
        }
    }["CalendarClient.useCallback[fetchLessons]"], [
        from,
        to
    ]);
    // Fetch closures whenever the visible range changes (closures are school-wide, not date-limited but we refresh lazily)
    const fetchClosures = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "CalendarClient.useCallback[fetchClosures]": async ()=>{
            const res = await fetch('/api/school/closures');
            if (res.ok) setClosures(await res.json());
        }
    }["CalendarClient.useCallback[fetchClosures]"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CalendarClient.useEffect": ()=>{
            if (isFirstRender.current) {
                isFirstRender.current = false;
                return;
            }
            fetchLessons();
        }
    }["CalendarClient.useEffect"], [
        fetchLessons
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CalendarClient.useEffect": ()=>{
            fetchClosures();
        }
    }["CalendarClient.useEffect"], [
        fetchClosures
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CalendarClient.useEffect": ()=>{
            const channel = supabase.channel('lessons-realtime').on('postgres_changes', {
                event: '*',
                schema: 'public',
                table: 'lessons'
            }, {
                "CalendarClient.useEffect.channel": ()=>{
                    fetchLessons();
                }
            }["CalendarClient.useEffect.channel"]).subscribe();
            return ({
                "CalendarClient.useEffect": ()=>{
                    supabase.removeChannel(channel);
                }
            })["CalendarClient.useEffect"];
        }
    }["CalendarClient.useEffect"], [
        supabase,
        fetchLessons
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CalendarClient.useEffect": ()=>{
            if (!showAddClass || courses.length > 0) return;
            fetch('/api/school/courses').then({
                "CalendarClient.useEffect": (r)=>r.json()
            }["CalendarClient.useEffect"]).then({
                "CalendarClient.useEffect": (data)=>{
                    if (Array.isArray(data)) {
                        setCourses(data.map({
                            "CalendarClient.useEffect": (c)=>({
                                    id: c.id,
                                    name: c.name,
                                    color: c.color
                                })
                        }["CalendarClient.useEffect"]));
                    }
                }
            }["CalendarClient.useEffect"]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["CalendarClient.useEffect"], [
        showAddClass
    ]);
    const locationOptions = [
        ...new Set(lessons.map((l)=>{
            var _l_school_rooms_school_locations, _l_school_rooms;
            return (_l_school_rooms = l.school_rooms) === null || _l_school_rooms === void 0 ? void 0 : (_l_school_rooms_school_locations = _l_school_rooms.school_locations) === null || _l_school_rooms_school_locations === void 0 ? void 0 : _l_school_rooms_school_locations.name;
        }).filter(Boolean))
    ];
    const roomOptions = [
        ...new Set(lessons.filter((l)=>{
            var _l_school_rooms_school_locations, _l_school_rooms;
            return !filterLocation || ((_l_school_rooms = l.school_rooms) === null || _l_school_rooms === void 0 ? void 0 : (_l_school_rooms_school_locations = _l_school_rooms.school_locations) === null || _l_school_rooms_school_locations === void 0 ? void 0 : _l_school_rooms_school_locations.name) === filterLocation;
        }).map((l)=>{
            var _l_school_rooms;
            return (_l_school_rooms = l.school_rooms) === null || _l_school_rooms === void 0 ? void 0 : _l_school_rooms.name;
        }).filter(Boolean))
    ];
    const filteredLessons = lessons.filter((l)=>{
        var _l_school_rooms_school_locations, _l_school_rooms, _l_school_rooms1, _l_teachers;
        if (filterLocation && ((_l_school_rooms = l.school_rooms) === null || _l_school_rooms === void 0 ? void 0 : (_l_school_rooms_school_locations = _l_school_rooms.school_locations) === null || _l_school_rooms_school_locations === void 0 ? void 0 : _l_school_rooms_school_locations.name) !== filterLocation) return false;
        if (filterRoom && ((_l_school_rooms1 = l.school_rooms) === null || _l_school_rooms1 === void 0 ? void 0 : _l_school_rooms1.name) !== filterRoom) return false;
        if (filterTeacher && ((_l_teachers = l.teachers) === null || _l_teachers === void 0 ? void 0 : _l_teachers.name) !== filterTeacher) return false;
        if (filterStudent && studentLessonIds !== null && !studentLessonIds.has(l.id)) return false;
        return true;
    });
    const hasActiveFilter = !!(filterLocation || filterRoom || filterTeacher || filterStudent);
    function clearFilters() {
        setFilterLocation('');
        setFilterRoom('');
        setFilterTeacher('');
        setFilterStudent('');
    }
    function lessonsForDay(dateStr) {
        return filteredLessons.filter((l)=>l.date === dateStr);
    }
    const today = toISO(new Date());
    // Closure banner for a date cell
    function ClosureBanner(param) {
        let { dateStr } = param;
        const cl = getClosureForDate(dateStr, closures);
        if (!cl) return null;
        var _cl_notes;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full text-left rounded px-1.5 py-0.5 text-xs bg-amber-100 text-amber-700 font-medium truncate border border-amber-200",
            children: [
                "🔒 ",
                (_cl_notes = cl.notes) !== null && _cl_notes !== void 0 ? _cl_notes : 'Closed'
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
            lineNumber: 291,
            columnNumber: 7
        }, this);
    }
    var _selected_courses_color, _selected_courses_name, _selected_teachers_name, _selected_school_rooms_school_locations_name, _selected_courses_credit_cost;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-5 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold text-gray-900",
                                children: "Calendar"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 302,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500 text-sm mt-0.5",
                                children: headerLabel(anchor, mode)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 303,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 301,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex bg-white border border-gray-200 rounded-lg p-1 gap-0.5",
                                children: [
                                    'day',
                                    'week',
                                    'month',
                                    'year'
                                ].map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setMode(m);
                                            setSelected(null);
                                        },
                                        className: "px-3 py-1.5 text-xs font-medium rounded transition capitalize ".concat(mode === m ? 'bg-[#6B1F3A] text-white' : 'text-gray-500 hover:bg-gray-100'),
                                        children: m
                                    }, m, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 308,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 306,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1 bg-white border border-gray-200 rounded-lg p-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setAnchor(navigate(anchor, mode, -1)),
                                        className: "p-1.5 hover:bg-gray-100 rounded text-gray-500",
                                        children: "←"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 321,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setAnchor(new Date()),
                                        className: "px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 rounded",
                                        children: mode === 'day' ? 'Go to Today' : mode === 'week' ? 'This Week' : mode === 'month' ? 'This Month' : 'This Year'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 322,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setAnchor(navigate(anchor, mode, 1)),
                                        className: "p-1.5 hover:bg-gray-100 rounded text-gray-500",
                                        children: "→"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 328,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 320,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setShowAddClass(true),
                                className: "bg-[#6B1F3A] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#5a1930] transition",
                                children: "+ Add Class"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 331,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 305,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                lineNumber: 300,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4 flex items-center gap-2 flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterLocation,
                        onChange: (e)=>{
                            setFilterLocation(e.target.value);
                            setFilterRoom('');
                        },
                        className: "px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All Locations"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 347,
                                columnNumber: 11
                            }, this),
                            locationOptions.map((loc)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: loc,
                                    children: loc
                                }, loc, false, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 348,
                                    columnNumber: 39
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 342,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterRoom,
                        onChange: (e)=>setFilterRoom(e.target.value),
                        className: "px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All Rooms"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 356,
                                columnNumber: 11
                            }, this),
                            roomOptions.map((room)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: room,
                                    children: room
                                }, room, false, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 357,
                                    columnNumber: 36
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 351,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterTeacher,
                        onChange: (e)=>setFilterTeacher(e.target.value),
                        className: "px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All Teachers"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 365,
                                columnNumber: 11
                            }, this),
                            teacherOptions.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: t.name,
                                    children: t.name
                                }, t.id, false, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 366,
                                    columnNumber: 36
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 360,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterStudent,
                        onChange: (e)=>setFilterStudent(e.target.value),
                        className: "px-3 py-1.5 text-xs border border-gray-200 rounded-lg bg-white text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All Clients"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 374,
                                columnNumber: 11
                            }, this),
                            studentOptions.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: s.userId,
                                    children: s.name
                                }, s.userId, false, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 375,
                                    columnNumber: 36
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 369,
                        columnNumber: 9
                    }, this),
                    hasActiveFilter && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: clearFilters,
                        className: "px-3 py-1.5 text-xs text-[#6B1F3A] border border-[#6B1F3A]/30 rounded-lg hover:bg-[#6B1F3A]/5 transition font-medium",
                        children: "Clear filters"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 379,
                        columnNumber: 11
                    }, this),
                    closures.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "ml-auto flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 border border-amber-200 rounded-lg",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2.5 h-2.5 rounded-sm bg-amber-300"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 390,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs text-amber-700 font-medium",
                                children: "Closure day"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 391,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 389,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                lineNumber: 341,
                columnNumber: 7
            }, this),
            showAddClass && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-2xl shadow-xl p-6 max-w-sm w-full mx-4 space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "font-semibold text-gray-900",
                            children: "Add Class to Existing Course"
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                            lineNumber: 400,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-xs font-medium text-gray-600 mb-1",
                                            children: "Course *"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 403,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            value: addForm.course_id,
                                            onChange: (e)=>setAddForm((f)=>({
                                                        ...f,
                                                        course_id: e.target.value
                                                    })),
                                            className: "w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "",
                                                    children: "Select course..."
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                    lineNumber: 406,
                                                    columnNumber: 19
                                                }, this),
                                                courses.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: c.id,
                                                        children: c.name
                                                    }, c.id, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 407,
                                                        columnNumber: 37
                                                    }, this))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 404,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 402,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-xs font-medium text-gray-600 mb-1",
                                            children: "Date *"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 411,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "date",
                                            value: addForm.date,
                                            onChange: (e)=>setAddForm((f)=>({
                                                        ...f,
                                                        date: e.target.value
                                                    })),
                                            className: "w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 412,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 410,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-xs font-medium text-gray-600 mb-1",
                                            children: "Start Time *"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 417,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "time",
                                            value: addForm.start_time,
                                            onChange: (e)=>setAddForm((f)=>({
                                                        ...f,
                                                        start_time: e.target.value
                                                    })),
                                            className: "w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 418,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 416,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-xs font-medium text-gray-600 mb-1",
                                            children: "Duration (min)"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 423,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "number",
                                            value: addForm.duration_minutes,
                                            onChange: (e)=>setAddForm((f)=>({
                                                        ...f,
                                                        duration_minutes: e.target.value
                                                    })),
                                            className: "w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 424,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 422,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                            lineNumber: 401,
                            columnNumber: 13
                        }, this),
                        addClassError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-red-600",
                            children: addClassError
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                            lineNumber: 429,
                            columnNumber: 31
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2 pt-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleAddClass,
                                    disabled: addingClass || !addForm.course_id || !addForm.date || !addForm.start_time,
                                    className: "flex-1 px-4 py-2 bg-[#6B1F3A] text-white rounded-lg text-sm font-medium disabled:opacity-50",
                                    children: addingClass ? 'Creating...' : 'Create Class'
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 431,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        setShowAddClass(false);
                                        setAddClassError(null);
                                    },
                                    className: "px-4 py-2 border border-gray-200 text-gray-600 rounded-lg text-sm hover:bg-gray-50",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 435,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                            lineNumber: 430,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                    lineNumber: 399,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                lineNumber: 398,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 min-w-0",
                        children: [
                            mode === 'day' && (()=>{
                                const dateStr = toISO(anchor);
                                const closure = getClosureForDate(dateStr, closures);
                                var _closure_notes, _closure_notes1;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-4 border-b border-gray-100 ".concat(closure ? 'bg-amber-50 border-amber-100' : today === dateStr ? 'bg-[#6B1F3A]/5' : ''),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm font-semibold text-gray-700",
                                                        children: anchor.toLocaleDateString('en-GB', {
                                                            weekday: 'long',
                                                            day: 'numeric',
                                                            month: 'long',
                                                            year: 'numeric'
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 454,
                                                        columnNumber: 21
                                                    }, this),
                                                    closure && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs font-medium text-amber-700 bg-amber-100 border border-amber-200 px-2 py-0.5 rounded-full",
                                                        children: [
                                                            "🔒 ",
                                                            (_closure_notes = closure.notes) !== null && _closure_notes !== void 0 ? _closure_notes : 'Closed'
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 458,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 453,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 452,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-4 min-h-64 ".concat(closure ? 'bg-amber-50/30' : ''),
                                            children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-300",
                                                children: "Loading..."
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 466,
                                                columnNumber: 21
                                            }, this) : lessonsForDay(dateStr).length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-gray-400 text-center mt-8",
                                                children: closure ? "School closed — ".concat((_closure_notes1 = closure.notes) !== null && _closure_notes1 !== void 0 ? _closure_notes1 : 'Closure day') : 'No classes scheduled.'
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 468,
                                                columnNumber: 21
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: lessonsForDay(dateStr).sort((a, b)=>a.start_time.localeCompare(b.start_time)).map((l)=>{
                                                    var _l_courses, _l_courses1, _l_lesson_types, _l_teachers, _l_school_rooms;
                                                    var _l_courses_color, _l_courses_name, _l_teachers_name, _l_school_rooms_name;
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>setSelected(l),
                                                        className: "w-full text-left rounded-xl px-4 py-3 text-sm transition hover:opacity-90 flex items-center gap-4",
                                                        style: {
                                                            backgroundColor: (_l_courses_color = (_l_courses = l.courses) === null || _l_courses === void 0 ? void 0 : _l_courses.color) !== null && _l_courses_color !== void 0 ? _l_courses_color : '#6B1F3A',
                                                            color: '#fff'
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs opacity-80 w-16 shrink-0",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        children: l.start_time.slice(0, 5)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                        lineNumber: 483,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        children: l.end_time.slice(0, 5)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                        lineNumber: 484,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                lineNumber: 482,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex-1 min-w-0",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "font-semibold truncate",
                                                                        children: [
                                                                            (_l_courses_name = (_l_courses1 = l.courses) === null || _l_courses1 === void 0 ? void 0 : _l_courses1.name) !== null && _l_courses_name !== void 0 ? _l_courses_name : (_l_lesson_types = l.lesson_types) === null || _l_lesson_types === void 0 ? void 0 : _l_lesson_types.name_en,
                                                                            l.is_online ? ' 🌐' : ''
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                        lineNumber: 487,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-xs opacity-80 truncate",
                                                                        children: [
                                                                            (_l_teachers_name = (_l_teachers = l.teachers) === null || _l_teachers === void 0 ? void 0 : _l_teachers.name) !== null && _l_teachers_name !== void 0 ? _l_teachers_name : '—',
                                                                            " · ",
                                                                            l.is_online ? 'Online' : (_l_school_rooms_name = (_l_school_rooms = l.school_rooms) === null || _l_school_rooms === void 0 ? void 0 : _l_school_rooms.name) !== null && _l_school_rooms_name !== void 0 ? _l_school_rooms_name : '—'
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                        lineNumber: 488,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                lineNumber: 486,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs opacity-70 shrink-0",
                                                                children: [
                                                                    l.current_bookings,
                                                                    "/",
                                                                    l.max_capacity
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                lineNumber: 490,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, l.id, true, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 476,
                                                        columnNumber: 27
                                                    }, this);
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 472,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                            lineNumber: 464,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                    lineNumber: 451,
                                    columnNumber: 15
                                }, this);
                            })(),
                            mode === 'week' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7 border-b border-gray-100",
                                        children: getWeekDates(anchor).map((d, i)=>{
                                            const isToday = toISO(d) === today;
                                            const closure = getClosureForDate(toISO(d), closures);
                                            var _closure_notes, _closure_notes1;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-3 text-center border-r border-gray-100 last:border-r-0 ".concat(closure ? 'bg-amber-50' : isToday ? 'bg-[#6B1F3A]/5' : ''),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-gray-400 font-medium",
                                                        children: DAYS_SHORT[i]
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 509,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-lg font-bold mt-0.5 ".concat(isToday ? 'text-[#6B1F3A]' : closure ? 'text-amber-600' : 'text-gray-800'),
                                                        children: d.getDate()
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 510,
                                                        columnNumber: 23
                                                    }, this),
                                                    closure && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-[10px] text-amber-600 mt-0.5 truncate",
                                                        title: (_closure_notes = closure.notes) !== null && _closure_notes !== void 0 ? _closure_notes : 'Closed',
                                                        children: [
                                                            "🔒 ",
                                                            (_closure_notes1 = closure.notes) !== null && _closure_notes1 !== void 0 ? _closure_notes1 : 'Closed'
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 512,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 508,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 503,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7 min-h-96",
                                        children: getWeekDates(anchor).map((d, i)=>{
                                            const dateStr = toISO(d);
                                            const dayLessons = lessonsForDay(dateStr);
                                            const isToday = dateStr === today;
                                            const closure = getClosureForDate(dateStr, closures);
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-2 border-r border-gray-100 last:border-r-0 space-y-1.5 ".concat(closure ? 'bg-amber-50/40' : isToday ? 'bg-[#6B1F3A]/5' : ''),
                                                children: [
                                                    loading && i === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-300 mt-2",
                                                        children: "Loading..."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 528,
                                                        columnNumber: 46
                                                    }, this),
                                                    dayLessons.map((l)=>{
                                                        var _l_courses, _l_courses1, _l_lesson_types;
                                                        var _l_courses_color, _l_courses_name;
                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setSelected(l),
                                                            className: "w-full text-left rounded-lg px-2 py-1.5 text-xs transition hover:opacity-80",
                                                            style: {
                                                                backgroundColor: (_l_courses_color = (_l_courses = l.courses) === null || _l_courses === void 0 ? void 0 : _l_courses.color) !== null && _l_courses_color !== void 0 ? _l_courses_color : '#6B1F3A',
                                                                color: '#fff'
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "font-semibold truncate",
                                                                    children: (_l_courses_name = (_l_courses1 = l.courses) === null || _l_courses1 === void 0 ? void 0 : _l_courses1.name) !== null && _l_courses_name !== void 0 ? _l_courses_name : (_l_lesson_types = l.lesson_types) === null || _l_lesson_types === void 0 ? void 0 : _l_lesson_types.name_en
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                    lineNumber: 536,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "opacity-80",
                                                                    children: [
                                                                        l.start_time.slice(0, 5),
                                                                        l.is_online ? ' · 🌐' : ''
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                    lineNumber: 537,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "opacity-70",
                                                                    children: [
                                                                        l.current_bookings,
                                                                        "/",
                                                                        l.max_capacity
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                    lineNumber: 538,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, l.id, true, {
                                                            fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                            lineNumber: 530,
                                                            columnNumber: 25
                                                        }, this);
                                                    })
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 527,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 520,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 502,
                                columnNumber: 13
                            }, this),
                            mode === 'month' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-xl border border-gray-100 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7 border-b border-gray-100",
                                        children: DAYS_SHORT.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-3 text-center",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-400 font-medium",
                                                    children: d
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                    lineNumber: 554,
                                                    columnNumber: 21
                                                }, this)
                                            }, d, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 553,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 551,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-7",
                                        children: getMonthDates(anchor).map((d, i)=>{
                                            const dateStr = toISO(d);
                                            const inMonth = d.getMonth() === anchor.getMonth();
                                            const isToday = dateStr === today;
                                            const dayLessons = lessonsForDay(dateStr);
                                            const closure = inMonth ? getClosureForDate(dateStr, closures) : null;
                                            var _closure_notes;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "min-h-24 p-1.5 border-r border-b border-gray-100 last:border-r-0 ".concat(closure ? 'bg-amber-50/60' : !inMonth ? 'bg-gray-50/50' : isToday ? 'bg-[#6B1F3A]/5' : ''),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs font-medium mb-1 w-6 h-6 flex items-center justify-center rounded-full ".concat(isToday ? 'bg-[#6B1F3A] text-white' : closure ? 'text-amber-600' : inMonth ? 'text-gray-700' : 'text-gray-300'),
                                                        children: d.getDate()
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 572,
                                                        columnNumber: 23
                                                    }, this),
                                                    loading && i === 0 ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-0.5",
                                                        children: [
                                                            closure && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "w-full text-left rounded px-1.5 py-0.5 text-[10px] bg-amber-100 text-amber-700 font-medium truncate border border-amber-200",
                                                                children: [
                                                                    "🔒 ",
                                                                    (_closure_notes = closure.notes) !== null && _closure_notes !== void 0 ? _closure_notes : 'Closed'
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                lineNumber: 580,
                                                                columnNumber: 29
                                                            }, this),
                                                            dayLessons.slice(0, closure ? 2 : 3).map((l)=>{
                                                                var _l_courses, _l_courses1, _l_lesson_types;
                                                                var _l_courses_color, _l_courses_name;
                                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>setSelected(l),
                                                                    className: "w-full text-left rounded px-1.5 py-0.5 text-xs truncate transition hover:opacity-80",
                                                                    style: {
                                                                        backgroundColor: (_l_courses_color = (_l_courses = l.courses) === null || _l_courses === void 0 ? void 0 : _l_courses.color) !== null && _l_courses_color !== void 0 ? _l_courses_color : '#6B1F3A',
                                                                        color: '#fff'
                                                                    },
                                                                    children: [
                                                                        l.start_time.slice(0, 5),
                                                                        " ",
                                                                        (_l_courses_name = (_l_courses1 = l.courses) === null || _l_courses1 === void 0 ? void 0 : _l_courses1.name) !== null && _l_courses_name !== void 0 ? _l_courses_name : (_l_lesson_types = l.lesson_types) === null || _l_lesson_types === void 0 ? void 0 : _l_lesson_types.name_en
                                                                    ]
                                                                }, l.id, true, {
                                                                    fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                    lineNumber: 585,
                                                                    columnNumber: 29
                                                                }, this);
                                                            }),
                                                            dayLessons.length > (closure ? 2 : 3) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-gray-400 pl-1",
                                                                children: [
                                                                    "+",
                                                                    dayLessons.length - (closure ? 2 : 3),
                                                                    " more"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                                lineNumber: 595,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 578,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 566,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 558,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 550,
                                columnNumber: 13
                            }, this),
                            mode === 'year' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-4 gap-4",
                                children: MONTHS.map((monthName, mi)=>{
                                    const year = anchor.getFullYear();
                                    const firstDay = new Date(year, mi, 1);
                                    const lastDay = new Date(year, mi + 1, 0);
                                    const startOffset = (firstDay.getDay() + 6) % 7;
                                    const totalCells = Math.ceil((startOffset + lastDay.getDate()) / 7) * 7;
                                    const cells = Array.from({
                                        length: totalCells
                                    }, (_, i)=>{
                                        const d = new Date(firstDay);
                                        d.setDate(1 - startOffset + i);
                                        return d;
                                    });
                                    const monthLessons = filteredLessons.filter((l)=>{
                                        const lDate = new Date(l.date);
                                        return lDate.getFullYear() === year && lDate.getMonth() === mi;
                                    });
                                    const lessonDates = new Set(monthLessons.map((l)=>l.date));
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-xl border border-gray-100 p-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs font-semibold text-gray-700",
                                                        children: monthName
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 629,
                                                        columnNumber: 23
                                                    }, this),
                                                    monthLessons.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-gray-400",
                                                        children: [
                                                            monthLessons.length,
                                                            " classes"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 631,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 628,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-7 mb-1",
                                                children: [
                                                    'M',
                                                    'T',
                                                    'W',
                                                    'T',
                                                    'F',
                                                    'S',
                                                    'S'
                                                ].map((d, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-center text-[10px] text-gray-300 font-medium",
                                                        children: d
                                                    }, i, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 636,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 634,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-7 gap-y-0.5",
                                                children: cells.map((d, i)=>{
                                                    const dateStr = toISO(d);
                                                    const inMonth = d.getMonth() === mi;
                                                    const isToday = dateStr === today;
                                                    const hasLesson = lessonDates.has(dateStr);
                                                    const closure = inMonth ? getClosureForDate(dateStr, closures) : null;
                                                    var _closure_notes;
                                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        disabled: !inMonth || !hasLesson && !closure,
                                                        onClick: ()=>{
                                                            if (inMonth && (hasLesson || closure)) {
                                                                setAnchor(d);
                                                                setMode('day');
                                                            }
                                                        },
                                                        title: (_closure_notes = closure === null || closure === void 0 ? void 0 : closure.notes) !== null && _closure_notes !== void 0 ? _closure_notes : undefined,
                                                        className: "text-[10px] h-5 w-full flex items-center justify-center rounded transition ".concat(!inMonth ? 'text-gray-200' : isToday ? 'bg-[#6B1F3A] text-white font-bold' : closure ? 'bg-amber-200 text-amber-700 font-medium hover:bg-amber-300 cursor-pointer' : hasLesson ? 'bg-[#6B1F3A]/15 text-[#6B1F3A] font-medium hover:bg-[#6B1F3A]/30 cursor-pointer' : 'text-gray-500'),
                                                        children: d.getDate()
                                                    }, i, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 647,
                                                        columnNumber: 27
                                                    }, this);
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 639,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, mi, true, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 627,
                                        columnNumber: 19
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 608,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 445,
                        columnNumber: 9
                    }, this),
                    selected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-72 bg-white rounded-xl border border-gray-100 p-5 space-y-4 self-start shrink-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-start justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-3 h-3 rounded-full mt-1 mr-2 shrink-0",
                                        style: {
                                            backgroundColor: (_selected_courses_color = (_selected_courses = selected.courses) === null || _selected_courses === void 0 ? void 0 : _selected_courses.color) !== null && _selected_courses_color !== void 0 ? _selected_courses_color : '#6B1F3A'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 681,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "font-semibold text-gray-900 text-sm",
                                                children: (_selected_courses_name = (_selected_courses1 = selected.courses) === null || _selected_courses1 === void 0 ? void 0 : _selected_courses1.name) !== null && _selected_courses_name !== void 0 ? _selected_courses_name : (_selected_lesson_types = selected.lesson_types) === null || _selected_lesson_types === void 0 ? void 0 : _selected_lesson_types.name_en
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 686,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs text-gray-400 mt-0.5",
                                                children: (_selected_lesson_types1 = selected.lesson_types) === null || _selected_lesson_types1 === void 0 ? void 0 : _selected_lesson_types1.name_en
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 687,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 685,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setSelected(null),
                                        className: "text-gray-300 hover:text-gray-500 text-lg leading-none",
                                        children: "×"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 689,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 680,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2 text-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Date",
                                        value: new Date(selected.date + 'T12:00:00').toLocaleDateString('en-GB', {
                                            weekday: 'long',
                                            day: 'numeric',
                                            month: 'long'
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 693,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Time",
                                        value: "".concat(selected.start_time.slice(0, 5), " – ").concat(selected.end_time.slice(0, 5))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 694,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Teacher",
                                        value: (_selected_teachers_name = (_selected_teachers = selected.teachers) === null || _selected_teachers === void 0 ? void 0 : _selected_teachers.name) !== null && _selected_teachers_name !== void 0 ? _selected_teachers_name : '—'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 695,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Format",
                                        value: selected.is_online ? '🌐 Online' : '📍 In-Person'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 696,
                                        columnNumber: 15
                                    }, this),
                                    !selected.is_online && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Room",
                                        value: selected.school_rooms ? "".concat((_selected_school_rooms_school_locations_name = (_selected_school_rooms_school_locations = selected.school_rooms.school_locations) === null || _selected_school_rooms_school_locations === void 0 ? void 0 : _selected_school_rooms_school_locations.name) !== null && _selected_school_rooms_school_locations_name !== void 0 ? _selected_school_rooms_school_locations_name : '', " · ").concat(selected.school_rooms.name) : '—'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 698,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Bookings",
                                        value: "".concat(selected.current_bookings, " / ").concat(selected.max_capacity)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 704,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                        label: "Credits",
                                        value: "".concat((_selected_courses_credit_cost = (_selected_courses2 = selected.courses) === null || _selected_courses2 === void 0 ? void 0 : _selected_courses2.credit_cost) !== null && _selected_courses_credit_cost !== void 0 ? _selected_courses_credit_cost : 1, " credit(s)")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 705,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 692,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs px-2 py-1 rounded-full text-center font-medium ".concat(selected.current_bookings >= selected.max_capacity ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'),
                                children: selected.current_bookings >= selected.max_capacity ? 'Full' : "".concat(selected.max_capacity - selected.current_bookings, " spots available")
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 708,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "border-t border-gray-100 pt-3 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs font-semibold text-gray-500 uppercase tracking-wide",
                                        children: "Enrolled Students"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 717,
                                        columnNumber: 15
                                    }, this),
                                    enrollmentsLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-300",
                                        children: "Loading..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 721,
                                        columnNumber: 17
                                    }, this) : enrollments.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-gray-300",
                                        children: "No students enrolled."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 723,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-1.5 max-h-40 overflow-y-auto",
                                        children: enrollments.map((e)=>{
                                            var _e_student, _e_student1;
                                            var _e_student_name, _e_student_email;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "font-medium text-gray-800",
                                                        children: (_e_student_name = (_e_student = e.student) === null || _e_student === void 0 ? void 0 : _e_student.name) !== null && _e_student_name !== void 0 ? _e_student_name : '—'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 728,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-gray-400",
                                                        children: (_e_student_email = (_e_student1 = e.student) === null || _e_student1 === void 0 ? void 0 : _e_student1.email) !== null && _e_student_email !== void 0 ? _e_student_email : ''
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                        lineNumber: 729,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, e.id, true, {
                                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                                lineNumber: 727,
                                                columnNumber: 21
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                        lineNumber: 725,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 716,
                                columnNumber: 13
                            }, this),
                            selected.course_id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>router.push("/school/courses/".concat(selected.course_id, "/classes/").concat(selected.id)),
                                className: "w-full text-center text-xs text-[#6B1F3A] border border-[#6B1F3A]/30 rounded-lg py-2 hover:bg-[#6B1F3A]/5 transition font-medium",
                                children: "Edit Class"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 737,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>router.push("/school/attendance/".concat(selected.id)),
                                className: "w-full text-center text-xs text-white bg-gray-800 rounded-lg py-2 hover:bg-gray-700 transition font-medium",
                                children: "Mark Attendance"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                                lineNumber: 744,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                        lineNumber: 679,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                lineNumber: 444,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
        lineNumber: 298,
        columnNumber: 5
    }, this);
}
_s(CalendarClient, "huOCXp0Xv2q3NmKerPzPZSEMEFk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = CalendarClient;
function Row(param) {
    let { label, value } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-between gap-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-gray-400 text-xs",
                children: label
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                lineNumber: 760,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-gray-800 text-xs text-right",
                children: value
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
                lineNumber: 761,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/school/calendar/CalendarClient.tsx",
        lineNumber: 759,
        columnNumber: 5
    }, this);
}
_c1 = Row;
var _c, _c1;
__turbopack_context__.k.register(_c, "CalendarClient");
__turbopack_context__.k.register(_c1, "Row");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_school_calendar_CalendarClient_tsx_ccc0b06e._.js.map