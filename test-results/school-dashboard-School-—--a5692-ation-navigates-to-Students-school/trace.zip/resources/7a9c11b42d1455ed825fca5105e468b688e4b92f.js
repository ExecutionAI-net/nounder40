(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_1cdddcfc._.js",
  "static/chunks/src_88e6f185._.js"
],
    source: "dynamic"
});
