(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/[locale]/student/book/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BookPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const LANGUAGES = [
    {
        value: 'it',
        label: 'Italiano'
    },
    {
        value: 'en',
        label: 'English'
    },
    {
        value: 'es',
        label: 'Español'
    }
];
const LANG_FLAG = {
    it: '🇮🇹',
    en: '🇬🇧',
    es: '🇪🇸'
};
function hoursUntil(date, start_time) {
    return (new Date("".concat(date, "T").concat(start_time)).getTime() - Date.now()) / (1000 * 60 * 60);
}
function CancelModal(param) {
    let { lesson, bookingInfo, policyHours, onConfirm, onClose, cancelling } = param;
    var _lesson_courses, _lesson_lesson_types;
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('student.book');
    const hours = hoursUntil(lesson.date, lesson.start_time);
    const willRefund = hours >= policyHours;
    const credits = bookingInfo.credits_deducted;
    const lessonDateStr = new Date(lesson.date + 'T12:00:00').toLocaleDateString('en-GB', {
        weekday: 'long',
        day: 'numeric',
        month: 'long'
    });
    var _lesson_courses_name;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-6 pt-6 pb-4 space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "font-semibold text-gray-900 text-lg",
                            children: t('cancelModalTitle')
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 80,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-gray-50 rounded-xl p-4 space-y-2 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-500",
                                            children: t('lessonLabel')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium text-gray-900 text-right",
                                            children: (_lesson_courses_name = (_lesson_courses = lesson.courses) === null || _lesson_courses === void 0 ? void 0 : _lesson_courses.name) !== null && _lesson_courses_name !== void 0 ? _lesson_courses_name : (_lesson_lesson_types = lesson.lesson_types) === null || _lesson_lesson_types === void 0 ? void 0 : _lesson_lesson_types.name_en
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-500",
                                            children: t('dateLabel')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 88,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium text-gray-900",
                                            children: lessonDateStr
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 89,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 87,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-gray-500",
                                            children: t('timeLabel')
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 92,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-medium text-gray-900",
                                            children: [
                                                lesson.start_time.slice(0, 5),
                                                " – ",
                                                lesson.end_time.slice(0, 5)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 93,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 91,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 82,
                            columnNumber: 11
                        }, this),
                        credits > 0 && (willRefund ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start gap-2.5 bg-green-50 border border-green-200 rounded-xl px-4 py-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-green-500 mt-0.5",
                                    children: "✓"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 100,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-green-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold",
                                            children: t('creditsWillBeRefunded', {
                                                count: credits
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 102,
                                            columnNumber: 19
                                        }, this),
                                        t('cancelBeforePolicy', {
                                            policyHours
                                        })
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 101,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 99,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-start gap-2.5 bg-red-50 border border-red-200 rounded-xl px-4 py-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-red-500 mt-0.5",
                                    children: "⚠️"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 107,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-red-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold",
                                            children: t('creditsWillBeBurned', {
                                                count: credits
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 109,
                                            columnNumber: 19
                                        }, this),
                                        t('cancelAfterPolicy', {
                                            hoursLeft: Math.max(0, hours).toFixed(1),
                                            policyHours
                                        })
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 108,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 106,
                            columnNumber: 15
                        }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                    lineNumber: 79,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-6 pb-6 flex gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onConfirm,
                            disabled: cancelling,
                            className: "flex-1 py-2.5 rounded-xl text-sm font-medium transition disabled:opacity-50 ".concat(willRefund ? 'bg-gray-800 text-white hover:bg-gray-700' : 'bg-red-500 text-white hover:bg-red-600'),
                            children: cancelling ? t('cancellingText') : willRefund ? t('yesCancelRefund') : t('yesCancelBurn')
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 117,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            disabled: cancelling,
                            className: "px-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 transition",
                            children: t('goBack')
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 126,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                    lineNumber: 116,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
            lineNumber: 78,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
        lineNumber: 77,
        columnNumber: 5
    }, this);
}
_s(CancelModal, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = CancelModal;
function BookPageInner() {
    var _confirmLesson_courses, _confirmLesson_courses1, _confirmLesson_lesson_types, _confirmLesson_schools, _cancelTarget_lesson_schools;
    _s1();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])('student.book');
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [lessons, setLessons] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [city, setCity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [userCity, setUserCity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterCountry, setFilterCountry] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [selectedSchoolId, setSelectedSchoolId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [profileSchoolId, setProfileSchoolId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [schoolsInCity, setSchoolsInCity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [schoolCredits, setSchoolCredits] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Map());
    const [hqCountries, setHqCountries] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [hqCities, setHqCities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [bookedMap, setBookedMap] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [booking, setBooking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [cancelling, setCancelling] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [bookingError, setBookingError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [confirmLesson, setConfirmLesson] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [cancelTarget, setCancelTarget] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [filterLanguage, setFilterLanguage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterLessonTypeId, setFilterLessonTypeId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterTeacherId, setFilterTeacherId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [filterOnline, setFilterOnline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookPageInner.useEffect": ()=>{
            fetch('/api/locations').then({
                "BookPageInner.useEffect": (r)=>r.json()
            }["BookPageInner.useEffect"]).then({
                "BookPageInner.useEffect": (d)=>{
                    var _d_countries;
                    setHqCountries((_d_countries = d.countries) !== null && _d_countries !== void 0 ? _d_countries : []);
                    var _d_cities;
                    setHqCities((_d_cities = d.cities) !== null && _d_cities !== void 0 ? _d_cities : []);
                }
            }["BookPageInner.useEffect"]).catch({
                "BookPageInner.useEffect": ()=>{}
            }["BookPageInner.useEffect"]);
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["BookPageInner.useEffect"], []);
    const paymentSuccess = searchParams.get('payment') === 'success';
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookPageInner.useEffect": ()=>{
            async function loadProfile() {
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) return;
                const [{ data: profile }, { data: student }] = await Promise.all([
                    supabase.from('profiles').select('city').eq('id', user.id).single(),
                    supabase.from('students').select('id, school_id, city, country').eq('user_id', user.id).single()
                ]);
                var _profile_city, _ref;
                const c = (_ref = (_profile_city = profile === null || profile === void 0 ? void 0 : profile.city) !== null && _profile_city !== void 0 ? _profile_city : student === null || student === void 0 ? void 0 : student.city) !== null && _ref !== void 0 ? _ref : '';
                setUserCity(c);
                setCity(c);
                if (student === null || student === void 0 ? void 0 : student.country) setFilterCountry(student.country);
                var _student_school_id;
                const schoolId = (_student_school_id = student === null || student === void 0 ? void 0 : student.school_id) !== null && _student_school_id !== void 0 ? _student_school_id : null;
                setProfileSchoolId(schoolId);
                if (schoolId) setSelectedSchoolId(schoolId);
                const { data: pkgs } = await supabase.from('student_packages').select('school_id, credits_remaining').eq('student_id', user.id).eq('status', 'active').gt('credits_remaining', 0).gte('expires_at', new Date().toISOString());
                const { data: subs } = await supabase.from('student_subscriptions').select('school_id').eq('student_id', user.id).eq('status', 'active');
                const creditsMap = new Map();
                for (const p of pkgs !== null && pkgs !== void 0 ? pkgs : []){
                    var _creditsMap_get;
                    creditsMap.set(p.school_id, ((_creditsMap_get = creditsMap.get(p.school_id)) !== null && _creditsMap_get !== void 0 ? _creditsMap_get : 0) + p.credits_remaining);
                }
                for (const s of subs !== null && subs !== void 0 ? subs : []){
                    creditsMap.set(s.school_id, 99999);
                }
                setSchoolCredits(creditsMap);
                const { data: upcomingBookings } = await supabase.from('bookings').select('id, lesson_id, credits_deducted, access_source').eq('student_id', user.id).eq('status', 'confirmed');
                const map = {};
                for (const b of upcomingBookings !== null && upcomingBookings !== void 0 ? upcomingBookings : []){
                    map[b.lesson_id] = {
                        booking_id: b.id,
                        credits_deducted: b.credits_deducted,
                        access_source: b.access_source
                    };
                }
                setBookedMap(map);
            }
            loadProfile();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["BookPageInner.useEffect"], [
        paymentSuccess
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookPageInner.useEffect": ()=>{
            async function loadSchools() {
                if (!city) {
                    setSchoolsInCity([]);
                    return;
                }
                const { data } = await supabase.from('schools').select('id, name, city').ilike('city', "%".concat(city, "%")).eq('active', true).order('name');
                setSchoolsInCity(data !== null && data !== void 0 ? data : []);
            }
            loadSchools();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["BookPageInner.useEffect"], [
        city
    ]);
    const fetchLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "BookPageInner.useCallback[fetchLessons]": async ()=>{
            setLoading(true);
            const params = new URLSearchParams();
            if (selectedSchoolId) {
                params.set('school_id', selectedSchoolId);
            } else {
                if (city) params.set('city', city);
                if (filterCountry) params.set('country', filterCountry);
            }
            if (filterLanguage) params.set('language', filterLanguage);
            if (filterLessonTypeId) params.set('lesson_type_id', filterLessonTypeId);
            if (filterTeacherId) params.set('teacher_id', filterTeacherId);
            if (filterOnline) params.set('is_online', filterOnline);
            const res = await fetch("/api/student/lessons?".concat(params.toString()));
            if (res.ok) setLessons(await res.json());
            setLoading(false);
        }
    }["BookPageInner.useCallback[fetchLessons]"], [
        city,
        selectedSchoolId,
        filterLanguage,
        filterCountry,
        filterLessonTypeId,
        filterTeacherId,
        filterOnline
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BookPageInner.useEffect": ()=>{
            fetchLessons();
        }
    }["BookPageInner.useEffect"], [
        fetchLessons
    ]);
    async function confirmBook() {
        if (!confirmLesson) return;
        const lessonId = confirmLesson.id;
        setConfirmLesson(null);
        setBooking(lessonId);
        setBookingError((e)=>({
                ...e,
                [lessonId]: ''
            }));
        const res = await fetch('/api/bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                lesson_id: lessonId
            })
        });
        const data = await res.json();
        if (!res.ok) {
            setBookingError((e)=>{
                var _data_error;
                return {
                    ...e,
                    [lessonId]: (_data_error = data.error) !== null && _data_error !== void 0 ? _data_error : t('bookingFailed')
                };
            });
            setBooking(null);
        } else {
            setBookedMap((m)=>{
                var _confirmLesson_courses;
                var _confirmLesson_courses_credit_cost, _data_access_source;
                return {
                    ...m,
                    [lessonId]: {
                        booking_id: data.id,
                        credits_deducted: (_confirmLesson_courses_credit_cost = (_confirmLesson_courses = confirmLesson.courses) === null || _confirmLesson_courses === void 0 ? void 0 : _confirmLesson_courses.credit_cost) !== null && _confirmLesson_courses_credit_cost !== void 0 ? _confirmLesson_courses_credit_cost : 1,
                        access_source: (_data_access_source = data.access_source) !== null && _data_access_source !== void 0 ? _data_access_source : 'package'
                    }
                };
            });
            setLessons((prev)=>prev.map((l)=>l.id === lessonId ? {
                        ...l,
                        current_bookings: l.current_bookings + 1
                    } : l));
            setBooking(null);
        }
    }
    async function handleCancel() {
        if (!cancelTarget) return;
        const { lesson, info } = cancelTarget;
        setCancelling(info.booking_id);
        setCancelTarget(null);
        const res = await fetch("/api/bookings/".concat(info.booking_id), {
            method: 'DELETE'
        });
        if (res.ok) {
            setBookedMap((m)=>{
                const next = {
                    ...m
                };
                delete next[lesson.id];
                return next;
            });
            setLessons((prev)=>prev.map((l)=>l.id === lesson.id ? {
                        ...l,
                        current_bookings: Math.max(0, l.current_bookings - 1)
                    } : l));
        }
        setCancelling(null);
    }
    const uniqueLessonTypes = Array.from(new Map(lessons.filter((l)=>l.lesson_type_id && l.lesson_types).map((l)=>[
            l.lesson_type_id,
            {
                id: l.lesson_type_id,
                ...l.lesson_types
            }
        ])).values());
    const uniqueTeachers = Array.from(new Map(lessons.filter((l)=>l.teacher_id && l.teachers).map((l)=>[
            l.teacher_id,
            {
                id: l.teacher_id,
                ...l.teachers
            }
        ])).values());
    const grouped = {};
    for (const l of lessons){
        if (!grouped[l.date]) grouped[l.date] = [];
        grouped[l.date].push(l);
    }
    const sortedDates = Object.keys(grouped).sort();
    function formatDate(d) {
        return new Date(d + 'T12:00:00').toLocaleDateString('en-GB', {
            weekday: 'long',
            day: 'numeric',
            month: 'long'
        }).toUpperCase();
    }
    var _confirmLesson_courses_credit_cost;
    const creditCost = (_confirmLesson_courses_credit_cost = confirmLesson === null || confirmLesson === void 0 ? void 0 : (_confirmLesson_courses = confirmLesson.courses) === null || _confirmLesson_courses === void 0 ? void 0 : _confirmLesson_courses.credit_cost) !== null && _confirmLesson_courses_credit_cost !== void 0 ? _confirmLesson_courses_credit_cost : 1;
    var _schoolCredits_get;
    const confirmHasCredits = confirmLesson ? ((_schoolCredits_get = schoolCredits.get(confirmLesson.school_id)) !== null && _schoolCredits_get !== void 0 ? _schoolCredits_get : 0) >= creditCost : false;
    var _confirmLesson_courses_name, _cancelTarget_lesson_schools_cancellation_policy_hours;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            confirmLesson && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-6 pt-6 pb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "font-semibold text-gray-900 text-lg mb-1",
                                    children: t('confirmBookingTitle')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 352,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-500 mb-4",
                                    children: (_confirmLesson_courses_name = (_confirmLesson_courses1 = confirmLesson.courses) === null || _confirmLesson_courses1 === void 0 ? void 0 : _confirmLesson_courses1.name) !== null && _confirmLesson_courses_name !== void 0 ? _confirmLesson_courses_name : (_confirmLesson_lesson_types = confirmLesson.lesson_types) === null || _confirmLesson_lesson_types === void 0 ? void 0 : _confirmLesson_lesson_types.name_en
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 353,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-gray-50 rounded-xl p-4 space-y-2 text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-500",
                                                    children: t('dateLabel')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 358,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-medium text-gray-900",
                                                    children: new Date(confirmLesson.date + 'T12:00:00').toLocaleDateString('en-GB', {
                                                        weekday: 'long',
                                                        day: 'numeric',
                                                        month: 'long'
                                                    })
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 359,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 357,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-500",
                                                    children: t('timeLabel')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 362,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-medium text-gray-900",
                                                    children: [
                                                        confirmLesson.start_time.slice(0, 5),
                                                        " – ",
                                                        confirmLesson.end_time.slice(0, 5)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 363,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 361,
                                            columnNumber: 17
                                        }, this),
                                        confirmLesson.teachers && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-500",
                                                    children: t('teacherLabel')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 367,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-medium text-gray-900",
                                                    children: confirmLesson.teachers.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 368,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 366,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-500",
                                                    children: t('schoolLabel')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 372,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-medium text-gray-900",
                                                    children: (_confirmLesson_schools = confirmLesson.schools) === null || _confirmLesson_schools === void 0 ? void 0 : _confirmLesson_schools.name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 373,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 371,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "border-t border-gray-200 pt-2 flex justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-500",
                                                    children: t('creditsToDeduct')
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 376,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-bold text-[#6B1F3A] text-base",
                                                    children: [
                                                        creditCost,
                                                        " credit",
                                                        creditCost > 1 ? 's' : ''
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                    lineNumber: 377,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 375,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 356,
                                    columnNumber: 15
                                }, this),
                                !confirmHasCredits && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 p-3 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-700",
                                    children: t('notEnoughCredits')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 381,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 351,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-6 pb-6 flex gap-3",
                            children: [
                                confirmHasCredits ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: confirmBook,
                                    disabled: !!booking,
                                    className: "flex-1 py-2.5 bg-[#6B1F3A] text-white rounded-xl text-sm font-medium hover:bg-[#5a1930] transition disabled:opacity-50",
                                    children: booking ? t('bookingInProgress') : t('yesBookNow')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 388,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        setConfirmLesson(null);
                                        router.push('/student/buy?redirect=/student/book');
                                    },
                                    className: "flex-1 py-2.5 bg-[#6B1F3A] text-white rounded-xl text-sm font-medium hover:bg-[#5a1930] transition",
                                    children: t('buyCreditsButton')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 396,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setConfirmLesson(null),
                                    className: "px-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 transition",
                                    children: t('cancelButton')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 406,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 386,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                    lineNumber: 350,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                lineNumber: 349,
                columnNumber: 9
            }, this),
            cancelTarget && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CancelModal, {
                lesson: cancelTarget.lesson,
                bookingInfo: cancelTarget.info,
                policyHours: (_cancelTarget_lesson_schools_cancellation_policy_hours = (_cancelTarget_lesson_schools = cancelTarget.lesson.schools) === null || _cancelTarget_lesson_schools === void 0 ? void 0 : _cancelTarget_lesson_schools.cancellation_policy_hours) !== null && _cancelTarget_lesson_schools_cancellation_policy_hours !== void 0 ? _cancelTarget_lesson_schools_cancellation_policy_hours : 24,
                onConfirm: handleCancel,
                onClose: ()=>setCancelTarget(null),
                cancelling: !!cancelling
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                lineNumber: 419,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-2xl font-bold text-gray-900",
                        children: t('title')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 430,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-500 text-sm mt-0.5",
                        children: t('subtitle')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 431,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                lineNumber: 429,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-5 flex flex-wrap gap-3 items-center",
                children: [
                    hqCountries.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterCountry,
                        onChange: (e)=>{
                            setFilterCountry(e.target.value);
                            setCity('');
                            setSelectedSchoolId('');
                        },
                        className: "px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 bg-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: t('allCountries')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 443,
                                columnNumber: 13
                            }, this),
                            hqCountries.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: c.name,
                                    children: c.name
                                }, c.id, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 445,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 438,
                        columnNumber: 11
                    }, this) : null,
                    hqCountries.length > 0 ? (()=>{
                        const matchedCountry = hqCountries.find((c)=>c.name === filterCountry);
                        const citiesForCountry = matchedCountry ? hqCities.filter((c)=>c.country_id === matchedCountry.id) : [];
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: city,
                            onChange: (e)=>{
                                setCity(e.target.value);
                                setSelectedSchoolId('');
                            },
                            disabled: !filterCountry || citiesForCountry.length === 0,
                            className: "px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 bg-white disabled:opacity-50 disabled:cursor-not-allowed",
                            children: !filterCountry ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: t('selectCountryFirst')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 464,
                                columnNumber: 17
                            }, this) : citiesForCountry.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: t('noCitiesAvailable')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 466,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: "",
                                        children: t('allCities')
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                        lineNumber: 469,
                                        columnNumber: 19
                                    }, this),
                                    citiesForCountry.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: c.name,
                                            children: c.name
                                        }, c.id, false, {
                                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                            lineNumber: 471,
                                            columnNumber: 21
                                        }, this))
                                ]
                            }, void 0, true)
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 457,
                            columnNumber: 13
                        }, this);
                    })() : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        value: city,
                        onChange: (e)=>{
                            setCity(e.target.value);
                            setSelectedSchoolId('');
                        },
                        placeholder: t('filterByCity'),
                        className: "px-3 py-2 rounded-lg border border-gray-200 text-sm w-44 focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 478,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: selectedSchoolId,
                        onChange: (e)=>setSelectedSchoolId(e.target.value),
                        disabled: !city || schoolsInCity.length === 0,
                        className: "px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 bg-white disabled:opacity-50 disabled:cursor-not-allowed",
                        children: !city ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                            value: "",
                            children: t('selectCityFirst')
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 494,
                            columnNumber: 13
                        }, this) : schoolsInCity.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                            value: "",
                            children: t('noSchoolsFound')
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                            lineNumber: 496,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "",
                                    children: t('allSchools')
                                }, void 0, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 499,
                                    columnNumber: 15
                                }, this),
                                schoolsInCity.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: s.id,
                                        children: s.name
                                    }, s.id, false, {
                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                        lineNumber: 501,
                                        columnNumber: 17
                                    }, this))
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 487,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterLanguage,
                        onChange: (e)=>setFilterLanguage(e.target.value),
                        className: "px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 bg-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: t('allLanguages')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 513,
                                columnNumber: 11
                            }, this),
                            LANGUAGES.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: l.value,
                                    children: l.label
                                }, l.value, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 515,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 508,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterLessonTypeId,
                        onChange: (e)=>setFilterLessonTypeId(e.target.value),
                        className: "px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 bg-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: t('allTypes')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 525,
                                columnNumber: 11
                            }, this),
                            uniqueLessonTypes.map((lt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: lt.id,
                                    children: lt.name_en
                                }, lt.id, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 527,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 520,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterTeacherId,
                        onChange: (e)=>setFilterTeacherId(e.target.value),
                        className: "px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 bg-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: t('allTeachers')
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 537,
                                columnNumber: 11
                            }, this),
                            uniqueTeachers.map((teacher)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: teacher.id,
                                    children: teacher.name
                                }, teacher.id, false, {
                                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                    lineNumber: 539,
                                    columnNumber: 13
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 532,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: filterOnline,
                        onChange: (e)=>setFilterOnline(e.target.value),
                        className: "px-3 py-2 rounded-lg border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#6B1F3A]/20 bg-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "",
                                children: "All Formats"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 549,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "true",
                                children: "🌐 Online"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 550,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "false",
                                children: "📍 In-Person"
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 551,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 544,
                        columnNumber: 9
                    }, this),
                    userCity && city !== userCity && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setCity(userCity);
                            setSelectedSchoolId(profileSchoolId !== null && profileSchoolId !== void 0 ? profileSchoolId : '');
                        },
                        className: "text-xs text-[#6B1F3A] hover:underline",
                        children: t('resetToMyCity')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 555,
                        columnNumber: 11
                    }, this),
                    (city || filterCountry || filterLanguage || filterLessonTypeId || filterTeacherId || filterOnline) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setCity('');
                            setFilterCountry('');
                            setSelectedSchoolId('');
                            setFilterLanguage('');
                            setFilterLessonTypeId('');
                            setFilterTeacherId('');
                            setFilterOnline('');
                        },
                        className: "text-xs text-gray-400 hover:text-gray-600",
                        children: t('clearFilters')
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 560,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                lineNumber: 435,
                columnNumber: 7
            }, this),
            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm text-gray-400",
                children: t('loadingLessons')
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                lineNumber: 567,
                columnNumber: 9
            }, this) : lessons.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-xl border border-gray-100 p-10 text-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-400 text-sm",
                    children: city ? t('noLessonsFoundIn', {
                        city
                    }) : t('noLessonsFound')
                }, void 0, false, {
                    fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                    lineNumber: 570,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                lineNumber: 569,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: sortedDates.map((date)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3",
                                children: formatDate(date)
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 576,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-3",
                                children: grouped[date].map((lesson)=>{
                                    var _lesson_courses, _lesson_schools, _lesson_courses1, _lesson_courses2, _lesson_lesson_types, _lesson_lesson_types1, _lesson_schools1, _lesson_school_rooms_school_locations, _lesson_courses3, _lesson_courses4, _lesson_courses5, _LANGUAGES_find, _lesson_courses6, _lesson_courses7;
                                    const isFull = lesson.current_bookings >= lesson.max_capacity;
                                    const err = bookingError[lesson.id];
                                    const spotsLeft = lesson.max_capacity - lesson.current_bookings;
                                    var _schoolCredits_get, _lesson_courses_credit_cost;
                                    const hasCreditsHere = ((_schoolCredits_get = schoolCredits.get(lesson.school_id)) !== null && _schoolCredits_get !== void 0 ? _schoolCredits_get : 0) >= ((_lesson_courses_credit_cost = (_lesson_courses = lesson.courses) === null || _lesson_courses === void 0 ? void 0 : _lesson_courses.credit_cost) !== null && _lesson_courses_credit_cost !== void 0 ? _lesson_courses_credit_cost : 1);
                                    const isProfileSchool = profileSchoolId === lesson.school_id;
                                    const bookedInfo = bookedMap[lesson.id];
                                    const isBooked = !!bookedInfo;
                                    const isCancellingThis = cancelling === (bookedInfo === null || bookedInfo === void 0 ? void 0 : bookedInfo.booking_id);
                                    var _lesson_schools_cancellation_policy_hours;
                                    const policyHours = (_lesson_schools_cancellation_policy_hours = (_lesson_schools = lesson.schools) === null || _lesson_schools === void 0 ? void 0 : _lesson_schools.cancellation_policy_hours) !== null && _lesson_schools_cancellation_policy_hours !== void 0 ? _lesson_schools_cancellation_policy_hours : 24;
                                    const hoursLeft = hoursUntil(lesson.date, lesson.start_time);
                                    const willRefund = hoursLeft >= policyHours;
                                    var _lesson_courses_color, _lesson_courses_name, _lesson_school_rooms_school_locations_name, _lesson_courses_credit_cost1, _lesson_courses_credit_cost2, _LANG_FLAG_lesson_courses_language, _LANGUAGES_find_label;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-xl border p-4 flex gap-4 items-start transition ".concat(isBooked ? 'border-green-200 bg-green-50/30' : 'border-gray-100'),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-1 self-stretch rounded-full shrink-0",
                                                style: {
                                                    backgroundColor: (_lesson_courses_color = (_lesson_courses1 = lesson.courses) === null || _lesson_courses1 === void 0 ? void 0 : _lesson_courses1.color) !== null && _lesson_courses_color !== void 0 ? _lesson_courses_color : '#6B1F3A'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                lineNumber: 599,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex-1 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-start justify-between gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-center gap-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "font-semibold text-gray-900 text-sm",
                                                                                children: (_lesson_courses_name = (_lesson_courses2 = lesson.courses) === null || _lesson_courses2 === void 0 ? void 0 : _lesson_courses2.name) !== null && _lesson_courses_name !== void 0 ? _lesson_courses_name : (_lesson_lesson_types = lesson.lesson_types) === null || _lesson_lesson_types === void 0 ? void 0 : _lesson_lesson_types.name_en
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                                lineNumber: 604,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            isBooked && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-[10px] font-semibold text-green-700 bg-green-100 px-1.5 py-0.5 rounded-full",
                                                                                children: t('booked')
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                                lineNumber: 606,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                        lineNumber: 603,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-xs text-gray-400 mt-0.5",
                                                                        children: [
                                                                            (_lesson_lesson_types1 = lesson.lesson_types) === null || _lesson_lesson_types1 === void 0 ? void 0 : _lesson_lesson_types1.name_en,
                                                                            ((_lesson_schools1 = lesson.schools) === null || _lesson_schools1 === void 0 ? void 0 : _lesson_schools1.name) && " · ".concat(lesson.schools.name)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                        lineNumber: 609,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 602,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-right shrink-0",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-sm font-bold text-gray-900",
                                                                        children: lesson.start_time.slice(0, 5)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                        lineNumber: 615,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-xs text-gray-400",
                                                                        children: lesson.end_time.slice(0, 5)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                        lineNumber: 616,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 614,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 601,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4 mt-2 text-xs text-gray-500 flex-wrap",
                                                        children: [
                                                            lesson.is_online ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "inline-flex items-center gap-1 px-1.5 py-0.5 bg-teal-50 text-teal-700 rounded font-medium",
                                                                children: "🌐 Online"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 621,
                                                                columnNumber: 29
                                                            }, this) : lesson.school_rooms && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    "📍 ",
                                                                    (_lesson_school_rooms_school_locations_name = (_lesson_school_rooms_school_locations = lesson.school_rooms.school_locations) === null || _lesson_school_rooms_school_locations === void 0 ? void 0 : _lesson_school_rooms_school_locations.name) !== null && _lesson_school_rooms_school_locations_name !== void 0 ? _lesson_school_rooms_school_locations_name : '',
                                                                    " · ",
                                                                    lesson.school_rooms.name
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 624,
                                                                columnNumber: 31
                                                            }, this),
                                                            lesson.teachers && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    "👤 ",
                                                                    lesson.teachers.name
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 627,
                                                                columnNumber: 47
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    (_lesson_courses_credit_cost1 = (_lesson_courses3 = lesson.courses) === null || _lesson_courses3 === void 0 ? void 0 : _lesson_courses3.credit_cost) !== null && _lesson_courses_credit_cost1 !== void 0 ? _lesson_courses_credit_cost1 : 1,
                                                                    " credit",
                                                                    ((_lesson_courses_credit_cost2 = (_lesson_courses4 = lesson.courses) === null || _lesson_courses4 === void 0 ? void 0 : _lesson_courses4.credit_cost) !== null && _lesson_courses_credit_cost2 !== void 0 ? _lesson_courses_credit_cost2 : 1) > 1 ? 's' : ''
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 628,
                                                                columnNumber: 27
                                                            }, this),
                                                            ((_lesson_courses5 = lesson.courses) === null || _lesson_courses5 === void 0 ? void 0 : _lesson_courses5.language) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "inline-flex items-center gap-1 px-1.5 py-0.5 bg-gray-100 rounded text-gray-500",
                                                                children: [
                                                                    (_LANG_FLAG_lesson_courses_language = LANG_FLAG[lesson.courses.language]) !== null && _LANG_FLAG_lesson_courses_language !== void 0 ? _LANG_FLAG_lesson_courses_language : '',
                                                                    " ",
                                                                    (_LANGUAGES_find_label = (_LANGUAGES_find = LANGUAGES.find((l)=>l.value === lesson.courses.language)) === null || _LANGUAGES_find === void 0 ? void 0 : _LANGUAGES_find.label) !== null && _LANGUAGES_find_label !== void 0 ? _LANGUAGES_find_label : lesson.courses.language
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 630,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 619,
                                                        columnNumber: 25
                                                    }, this),
                                                    (((_lesson_courses6 = lesson.courses) === null || _lesson_courses6 === void 0 ? void 0 : _lesson_courses6.notes) || lesson.notes) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-2 space-y-0.5",
                                                        children: [
                                                            ((_lesson_courses7 = lesson.courses) === null || _lesson_courses7 === void 0 ? void 0 : _lesson_courses7.notes) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-gray-500",
                                                                children: lesson.courses.notes
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 637,
                                                                columnNumber: 55
                                                            }, this),
                                                            lesson.notes && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-xs text-gray-500",
                                                                children: lesson.notes
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 638,
                                                                columnNumber: 46
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 636,
                                                        columnNumber: 27
                                                    }, this),
                                                    err && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-red-500 mt-2",
                                                        children: err
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 641,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                lineNumber: 600,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "shrink-0 flex flex-col items-end gap-1.5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs px-2 py-0.5 rounded-full font-medium ".concat(isFull && !isBooked ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'),
                                                        children: isFull && !isBooked ? t('full') : t('spotsLeft', {
                                                            count: spotsLeft
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 645,
                                                        columnNumber: 25
                                                    }, this),
                                                    isBooked ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex flex-col items-end gap-1 mt-1",
                                                        children: [
                                                            lesson.is_online && lesson.online_link && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                href: lesson.online_link.startsWith('http') ? lesson.online_link : "https://".concat(lesson.online_link),
                                                                target: "_blank",
                                                                rel: "noopener noreferrer",
                                                                className: "px-3 py-1.5 bg-teal-600 text-white rounded-lg text-xs font-medium hover:bg-teal-700 transition",
                                                                children: "🌐 Join"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 652,
                                                                columnNumber: 31
                                                            }, this),
                                                            bookedInfo.credits_deducted > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[10px] font-medium ".concat(willRefund ? 'text-green-600' : 'text-amber-600'),
                                                                children: willRefund ? t('refundable') : t('willBurn')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 662,
                                                                columnNumber: 31
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>setCancelTarget({
                                                                        lesson,
                                                                        info: bookedInfo
                                                                    }),
                                                                disabled: isCancellingThis,
                                                                className: "px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-xs font-medium hover:bg-red-50 transition disabled:opacity-40",
                                                                children: isCancellingThis ? '...' : t('cancelBooking')
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                                lineNumber: 666,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 650,
                                                        columnNumber: 27
                                                    }, this) : booking === lesson.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-gray-400 mt-1",
                                                        children: t('bookingInProgress')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 675,
                                                        columnNumber: 27
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>{
                                                            if (isFull) return;
                                                            setConfirmLesson(lesson);
                                                        },
                                                        disabled: isFull || !!booking,
                                                        className: "mt-1 px-4 py-1.5 rounded-lg text-xs font-medium transition bg-[#6B1F3A] text-white hover:bg-[#5a1930] disabled:opacity-40",
                                                        children: t('bookButton')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                        lineNumber: 677,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                                lineNumber: 644,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, lesson.id, true, {
                                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                        lineNumber: 593,
                                        columnNumber: 21
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                                lineNumber: 577,
                                columnNumber: 15
                            }, this)
                        ]
                    }, date, true, {
                        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                        lineNumber: 575,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/student/book/page.tsx",
                lineNumber: 573,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
        lineNumber: 346,
        columnNumber: 5
    }, this);
}
_s1(BookPageInner, "eQvhik4hW1uvBihLnXi+allDMfk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c1 = BookPageInner;
function BookPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BookPageInner, {}, void 0, false, {
            fileName: "[project]/src/app/[locale]/student/book/page.tsx",
            lineNumber: 704,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/[locale]/student/book/page.tsx",
        lineNumber: 703,
        columnNumber: 5
    }, this);
}
_c2 = BookPage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "CancelModal");
__turbopack_context__.k.register(_c1, "BookPageInner");
__turbopack_context__.k.register(_c2, "BookPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_%5Blocale%5D_student_book_page_tsx_77b9bc35._.js.map