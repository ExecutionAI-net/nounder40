(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7e5ab332._.js",
  "static/chunks/src_d3bfa761._.js"
],
    source: "dynamic"
});
